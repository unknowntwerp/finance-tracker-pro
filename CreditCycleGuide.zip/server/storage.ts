import {
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  transactions, type Transaction, type InsertTransaction,
  budgetGoals, type BudgetGoal, type InsertBudgetGoal,
  savingsGoals, type SavingsGoal, type InsertSavingsGoal
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(userId: number): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Transaction methods
  getTransactions(userId: number): Promise<Transaction[]>;
  getTransactionsByCategory(categoryId: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: number): Promise<boolean>;
  
  // Budget Goal methods
  getBudgetGoals(userId: number): Promise<BudgetGoal[]>;
  getBudgetGoalsByCategory(categoryId: number): Promise<BudgetGoal[]>;
  getBudgetGoal(id: number): Promise<BudgetGoal | undefined>;
  createBudgetGoal(budgetGoal: InsertBudgetGoal): Promise<BudgetGoal>;
  updateBudgetGoal(id: number, budgetGoal: Partial<InsertBudgetGoal>): Promise<BudgetGoal | undefined>;
  deleteBudgetGoal(id: number): Promise<boolean>;
  
  // Savings Goal methods
  getSavingsGoals(userId: number): Promise<SavingsGoal[]>;
  getSavingsGoal(id: number): Promise<SavingsGoal | undefined>;
  createSavingsGoal(savingsGoal: InsertSavingsGoal): Promise<SavingsGoal>;
  updateSavingsGoal(id: number, savingsGoal: Partial<InsertSavingsGoal>): Promise<SavingsGoal | undefined>;
  deleteSavingsGoal(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private transactions: Map<number, Transaction>;
  private budgetGoals: Map<number, BudgetGoal>;
  private savingsGoals: Map<number, SavingsGoal>;
  
  private userId: number;
  private categoryId: number;
  private transactionId: number;
  private budgetGoalId: number;
  private savingsGoalId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.transactions = new Map();
    this.budgetGoals = new Map();
    this.savingsGoals = new Map();
    
    this.userId = 1;
    this.categoryId = 1;
    this.transactionId = 1;
    this.budgetGoalId = 1;
    this.savingsGoalId = 1;
    
    // Initialize with default data
    this.initializeDefaultData();
  }
  
  private initializeDefaultData() {
    // Add a default user
    const defaultUser: InsertUser = {
      username: "demo",
      password: "password",
      name: "Demo User",
      email: "demo@example.com"
    };
    
    this.createUser(defaultUser);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id,
      name: insertUser.name || null,
      email: insertUser.email || null 
    };
    this.users.set(id, user);
    return user;
  }
  
  // Category methods
  async getCategories(userId: number): Promise<Category[]> {
    return Array.from(this.categories.values()).filter(
      (category) => category.userId === userId,
    );
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { 
      ...category, 
      id,
      userId: category.userId || null,
      isExpense: category.isExpense === undefined ? true : category.isExpense 
    };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) return undefined;
    
    const updatedCategory = { ...existingCategory, ...category };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }
  
  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId,
    );
  }
  
  async getTransactionsByCategory(categoryId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.categoryId === categoryId,
    );
  }
  
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const newTransaction: Transaction = { 
      ...transaction, 
      id,
      userId: transaction.userId || null,
      categoryId: transaction.categoryId || null,
      description: transaction.description || null,
      date: transaction.date || new Date(),
      isExpense: transaction.isExpense === undefined ? true : transaction.isExpense
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }
  
  async updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const existingTransaction = this.transactions.get(id);
    if (!existingTransaction) return undefined;
    
    const updatedTransaction = { ...existingTransaction, ...transaction };
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }
  
  async deleteTransaction(id: number): Promise<boolean> {
    return this.transactions.delete(id);
  }
  
  // Budget Goal methods
  async getBudgetGoals(userId: number): Promise<BudgetGoal[]> {
    return Array.from(this.budgetGoals.values()).filter(
      (budgetGoal) => budgetGoal.userId === userId,
    );
  }
  
  async getBudgetGoalsByCategory(categoryId: number): Promise<BudgetGoal[]> {
    return Array.from(this.budgetGoals.values()).filter(
      (budgetGoal) => budgetGoal.categoryId === categoryId,
    );
  }
  
  async getBudgetGoal(id: number): Promise<BudgetGoal | undefined> {
    return this.budgetGoals.get(id);
  }
  
  async createBudgetGoal(budgetGoal: InsertBudgetGoal): Promise<BudgetGoal> {
    const id = this.budgetGoalId++;
    const newBudgetGoal: BudgetGoal = { 
      ...budgetGoal, 
      id,
      userId: budgetGoal.userId || null,
      categoryId: budgetGoal.categoryId || null,
      startDate: budgetGoal.startDate || new Date(),
      endDate: budgetGoal.endDate || null,
      isActive: budgetGoal.isActive === undefined ? true : budgetGoal.isActive
    };
    this.budgetGoals.set(id, newBudgetGoal);
    return newBudgetGoal;
  }
  
  async updateBudgetGoal(id: number, budgetGoal: Partial<InsertBudgetGoal>): Promise<BudgetGoal | undefined> {
    const existingBudgetGoal = this.budgetGoals.get(id);
    if (!existingBudgetGoal) return undefined;
    
    const updatedBudgetGoal = { ...existingBudgetGoal, ...budgetGoal };
    this.budgetGoals.set(id, updatedBudgetGoal);
    return updatedBudgetGoal;
  }
  
  async deleteBudgetGoal(id: number): Promise<boolean> {
    return this.budgetGoals.delete(id);
  }
  
  // Savings Goal methods
  async getSavingsGoals(userId: number): Promise<SavingsGoal[]> {
    return Array.from(this.savingsGoals.values()).filter(
      (savingsGoal) => savingsGoal.userId === userId,
    );
  }
  
  async getSavingsGoal(id: number): Promise<SavingsGoal | undefined> {
    return this.savingsGoals.get(id);
  }
  
  async createSavingsGoal(savingsGoal: InsertSavingsGoal): Promise<SavingsGoal> {
    const id = this.savingsGoalId++;
    const newSavingsGoal: SavingsGoal = { 
      ...savingsGoal, 
      id,
      userId: savingsGoal.userId || null,
      currentAmount: savingsGoal.currentAmount || "0",
      deadline: savingsGoal.deadline || null,
      isCompleted: savingsGoal.isCompleted === undefined ? false : savingsGoal.isCompleted
    };
    this.savingsGoals.set(id, newSavingsGoal);
    return newSavingsGoal;
  }
  
  async updateSavingsGoal(id: number, savingsGoal: Partial<InsertSavingsGoal>): Promise<SavingsGoal | undefined> {
    const existingSavingsGoal = this.savingsGoals.get(id);
    if (!existingSavingsGoal) return undefined;
    
    const updatedSavingsGoal = { ...existingSavingsGoal, ...savingsGoal };
    this.savingsGoals.set(id, updatedSavingsGoal);
    return updatedSavingsGoal;
  }
  
  async deleteSavingsGoal(id: number): Promise<boolean> {
    return this.savingsGoals.delete(id);
  }
}

export const storage = new MemStorage();
