import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCategorySchema, insertTransactionSchema, insertBudgetGoalSchema, insertSavingsGoalSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route to get environment information
  app.get("/api/environment", (req, res) => {
    res.json({
      environment: process.env.NODE_ENV || "development"
    });
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(Number(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    // Don't expose password
    const { password, ...safeUser } = user;
    res.json(safeUser);
  });

  // Category routes
  app.get("/api/categories", async (req, res) => {
    const userId = Number(req.query.userId);
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    const categories = await storage.getCategories(userId);
    res.json(categories);
  });

  app.get("/api/categories/:id", async (req, res) => {
    const category = await storage.getCategory(Number(req.params.id));
    if (!category) {
      return res.status(404).json({ error: "Category not found" });
    }
    res.json(category);
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/categories/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const validatedData = insertCategorySchema.partial().parse(req.body);
      const category = await storage.updateCategory(id, validatedData);
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    const id = Number(req.params.id);
    const deleted = await storage.deleteCategory(id);
    if (!deleted) {
      return res.status(404).json({ error: "Category not found" });
    }
    res.status(204).send();
  });

  // Transaction routes
  app.get("/api/transactions", async (req, res) => {
    const userId = Number(req.query.userId);
    const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    
    let transactions;
    if (categoryId) {
      transactions = await storage.getTransactionsByCategory(categoryId);
    } else {
      transactions = await storage.getTransactions(userId);
    }
    
    res.json(transactions);
  });

  app.get("/api/transactions/:id", async (req, res) => {
    const transaction = await storage.getTransaction(Number(req.params.id));
    if (!transaction) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    res.json(transaction);
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/transactions/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const validatedData = insertTransactionSchema.partial().parse(req.body);
      const transaction = await storage.updateTransaction(id, validatedData);
      if (!transaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/transactions/:id", async (req, res) => {
    const id = Number(req.params.id);
    const deleted = await storage.deleteTransaction(id);
    if (!deleted) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    res.status(204).send();
  });

  // Budget Goal routes
  app.get("/api/budget-goals", async (req, res) => {
    const userId = Number(req.query.userId);
    const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
    
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    
    let budgetGoals;
    if (categoryId) {
      budgetGoals = await storage.getBudgetGoalsByCategory(categoryId);
    } else {
      budgetGoals = await storage.getBudgetGoals(userId);
    }
    
    res.json(budgetGoals);
  });

  app.get("/api/budget-goals/:id", async (req, res) => {
    const budgetGoal = await storage.getBudgetGoal(Number(req.params.id));
    if (!budgetGoal) {
      return res.status(404).json({ error: "Budget goal not found" });
    }
    res.json(budgetGoal);
  });

  app.post("/api/budget-goals", async (req, res) => {
    try {
      const validatedData = insertBudgetGoalSchema.parse(req.body);
      const budgetGoal = await storage.createBudgetGoal(validatedData);
      res.status(201).json(budgetGoal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/budget-goals/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const validatedData = insertBudgetGoalSchema.partial().parse(req.body);
      const budgetGoal = await storage.updateBudgetGoal(id, validatedData);
      if (!budgetGoal) {
        return res.status(404).json({ error: "Budget goal not found" });
      }
      res.json(budgetGoal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/budget-goals/:id", async (req, res) => {
    const id = Number(req.params.id);
    const deleted = await storage.deleteBudgetGoal(id);
    if (!deleted) {
      return res.status(404).json({ error: "Budget goal not found" });
    }
    res.status(204).send();
  });

  // Savings Goal routes
  app.get("/api/savings-goals", async (req, res) => {
    const userId = Number(req.query.userId);
    
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    
    const savingsGoals = await storage.getSavingsGoals(userId);
    res.json(savingsGoals);
  });

  app.get("/api/savings-goals/:id", async (req, res) => {
    const savingsGoal = await storage.getSavingsGoal(Number(req.params.id));
    if (!savingsGoal) {
      return res.status(404).json({ error: "Savings goal not found" });
    }
    res.json(savingsGoal);
  });

  app.post("/api/savings-goals", async (req, res) => {
    try {
      const validatedData = insertSavingsGoalSchema.parse(req.body);
      const savingsGoal = await storage.createSavingsGoal(validatedData);
      res.status(201).json(savingsGoal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/savings-goals/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const validatedData = insertSavingsGoalSchema.partial().parse(req.body);
      const savingsGoal = await storage.updateSavingsGoal(id, validatedData);
      if (!savingsGoal) {
        return res.status(404).json({ error: "Savings goal not found" });
      }
      res.json(savingsGoal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/savings-goals/:id", async (req, res) => {
    const id = Number(req.params.id);
    const deleted = await storage.deleteSavingsGoal(id);
    if (!deleted) {
      return res.status(404).json({ error: "Savings goal not found" });
    }
    res.status(204).send();
  });

  // Dashboard summary endpoint
  app.get("/api/dashboard/summary", async (req, res) => {
    const userId = Number(req.query.userId);
    
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    
    try {
      // Get all user's transactions
      const transactions = await storage.getTransactions(userId);
      
      // Get income and expense totals
      const expenseTotal = transactions
        .filter(t => t.isExpense)
        .reduce((sum, t) => sum + Number(t.amount), 0);
      
      const incomeTotal = transactions
        .filter(t => !t.isExpense)
        .reduce((sum, t) => sum + Number(t.amount), 0);
      
      // Get budget and savings goals
      const budgetGoals = await storage.getBudgetGoals(userId);
      const savingsGoals = await storage.getSavingsGoals(userId);
      
      // Calculate budget progress
      const budgetProgress = budgetGoals.map(goal => {
        const goalTransactions = transactions.filter(
          t => t.categoryId === goal.categoryId && t.isExpense
        );
        const spent = goalTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
        const progress = Math.min(100, (spent / Number(goal.amount)) * 100);
        
        return {
          ...goal,
          spent,
          progress
        };
      });
      
      // Calculate savings progress
      const savingsProgress = savingsGoals.map(goal => {
        const progress = Math.min(100, (Number(goal.currentAmount) / Number(goal.targetAmount)) * 100);
        
        return {
          ...goal,
          progress
        };
      });
      
      res.json({
        totalBalance: incomeTotal - expenseTotal,
        incomeTotal,
        expenseTotal,
        budgetProgress,
        savingsProgress,
        recentTransactions: transactions
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .slice(0, 5)
      });
    } catch (error) {
      console.error("Error generating dashboard summary:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
