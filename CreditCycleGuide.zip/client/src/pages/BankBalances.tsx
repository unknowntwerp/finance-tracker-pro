import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useFinanceStore } from "@/lib/transactionStore";
import { Building, Plus, ArrowDown, ArrowUp, FileText } from "lucide-react";
import { formatCurrency } from "@/lib/formatters";

export default function BankBalances() {
  const { bankAccountsData, transactions } = useFinanceStore();

  // Calculate current balance and transactions for each bank account
  const bankBalances = useMemo(() => {
    const balances: Record<string, { 
      id: string;
      balance: number; 
      transactions: number;
      monthlyIncome: number;
      monthlyExpense: number;
    }> = {};

    // Initialize balances for all bank accounts
    bankAccountsData.forEach(accountData => {
      balances[accountData.name] = { 
        id: accountData.id,
        balance: 0, 
        transactions: 0,
        monthlyIncome: 0,
        monthlyExpense: 0
      };
    });

    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Calculate balances based on transactions
    transactions.forEach(transaction => {
      const { account, type, amount, date } = transaction;
      const txDate = new Date(date);

      if (balances[account]) {
        if (type === "income" || type === "payment") {
          balances[account].balance += amount;
          if (txDate >= firstDayOfMonth && amount > 0) {
            balances[account].monthlyIncome += amount;
          }
        } else if (type === "expense") {
          balances[account].balance -= amount;
          if (txDate >= firstDayOfMonth) {
            balances[account].monthlyExpense += amount;
          }
        } else if (type === "contra") {
          // For contra transactions, use the amount directly (can be positive or negative)
          // If amount is negative, it's an outgoing payment (expense)
          // If amount is positive, it's an incoming payment (income)
          balances[account].balance += amount; // This will correctly handle both positive and negative amounts
          
          if (txDate >= firstDayOfMonth) {
            if (amount > 0) {
              balances[account].monthlyIncome += amount;
            } else if (amount < 0) {
              balances[account].monthlyExpense += Math.abs(amount);
            }
          }
        } else if (type === "transfer") {
          // For transfers, respect the amount sign
          balances[account].balance += amount;
          
          if (txDate >= firstDayOfMonth) {
            if (amount > 0) {
              balances[account].monthlyIncome += amount;
            } else if (amount < 0) {
              balances[account].monthlyExpense += Math.abs(amount);
            }
          }
        }
        balances[account].transactions += 1;
      }
    });

    return balances;
  }, [bankAccountsData, transactions]);

  const totalBalance = useMemo(() => {
    return Object.values(bankBalances).reduce((sum, account) => sum + account.balance, 0);
  }, [bankBalances]);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Building className="h-6 w-6" /> Bank Accounts
        </h1>
        <Button variant="outline" asChild>
          <a href="/manage-lists" className="flex items-center gap-2">
            <Plus className="h-4 w-4" /> Add Bank Account
          </a>
        </Button>
      </div>

      {/* Total Balance Card */}
      <Card className="mb-6">
        <CardContent className="py-6">
          <div className="flex flex-col items-center">
            <h2 className="text-lg font-medium text-gray-500 mb-2">Total Balance</h2>
            <p className={`text-3xl font-bold ${totalBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalBalance)}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Across {bankAccountsData.length} bank {bankAccountsData.length === 1 ? 'account' : 'accounts'}
            </p>
          </div>
        </CardContent>
      </Card>

      {bankAccountsData.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <Building className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Bank Accounts Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-6">
              Add bank accounts to track their balances.
            </p>
            <Button variant="outline" className="flex items-center gap-2" asChild>
              <a href="/bank-accounts">
                <Plus className="h-4 w-4" /> Add Bank Account
              </a>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bankAccountsData.map((accountData) => {
            const account = accountData.name;
            const balanceData = bankBalances[account];
            return (
              <Card key={accountData.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <Building className="h-5 w-5 text-primary" />
                    {account}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex flex-col items-center mb-4">
                      <p className={`text-2xl font-bold ${balanceData?.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(balanceData?.balance || 0)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {balanceData?.transactions || 0} transactions
                      </p>
                    </div>

                    <div className="border-t pt-3">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Monthly Income:</span>
                        <span className="font-medium text-green-600">
                          {formatCurrency(balanceData?.monthlyIncome || 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Monthly Expense:</span>
                        <span className="font-medium text-red-600">
                          {formatCurrency(balanceData?.monthlyExpense || 0)}
                        </span>
                      </div>
                      <div className="flex justify-between font-semibold mt-2">
                        <span>Net Flow:</span>
                        <span className={(balanceData?.monthlyIncome || 0) - (balanceData?.monthlyExpense || 0) >= 0 ? 'text-green-600' : 'text-red-600'}>
                          {formatCurrency((balanceData?.monthlyIncome || 0) - (balanceData?.monthlyExpense || 0))}
                        </span>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-4"
                      onClick={() => window.location.href = '/?account=' + account}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      View Transactions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}