
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { useFinanceStore } from "@/lib/transactionStore";
import { formatCurrency } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  PlusCircle, Trash2, AlertCircle, FileText, Edit, 
  Users, ChevronRight, ArrowUpRight, TrendingUp, TrendingDown,
  DollarSign, CreditCard, ArrowRight, Wallet, ArrowDown,
  Plus
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { getDefaultCategoryIcon } from "@/lib/categoryIcons";

export default function Receivables() {
  const { transactions, people, addPerson, removePerson, updatePerson, addTransaction, bankAccountsData, expenseCategories, incomeCategories } = useFinanceStore();
  const { toast } = useToast();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [newPersonName, setNewPersonName] = useState("");
  const [editingPerson, setEditingPerson] = useState("");
  const [editPersonName, setEditPersonName] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  
  // Transaction form state
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<'expense' | 'income' | 'reimbursement'>('reimbursement');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState('');
  const [selectedCategoryIcon, setSelectedCategoryIcon] = useState<string>('');

  // Calculate balances from reimbursement transactions
  const balances = useMemo(() => {
    const balanceMap: Record<string, number> = {};

    transactions
      .filter(t => t.type === 'reimbursement')
      .forEach(transaction => {
        if (!transaction.person) return;

        // Positive amount means you paid on their behalf (they owe you)
        // So we negate the amount to represent debt to you
        // Negative amount means they paid on your behalf (you owe them)
        const balanceChange = -transaction.amount;

        balanceMap[transaction.person] = (balanceMap[transaction.person] || 0) + balanceChange;
      });

    return balanceMap;
  }, [transactions]);

  // Calculate summary stats
  const summary = useMemo(() => {
    const peopleWhoOweYou = Object.entries(balances)
      .filter(([_, balance]) => balance < 0)
      .reduce((acc, [_, balance]) => acc + Math.abs(balance), 0);
      
    const peopleYouOwe = Object.entries(balances)
      .filter(([_, balance]) => balance > 0)
      .reduce((acc, [_, balance]) => acc + balance, 0);
    
    const netBalance = peopleWhoOweYou - peopleYouOwe;
    
    return {
      peopleWhoOweYou,
      peopleYouOwe,
      netBalance,
      totalPeople: people.length,
      peopleWithBalances: Object.keys(balances).length
    };
  }, [balances, people]);

  const handleAddPerson = () => {
    if (!newPersonName.trim()) {
      setFormError("Person name is required");
      return;
    }

    if (people.includes(newPersonName.trim())) {
      setFormError("This person already exists");
      return;
    }

    addPerson(newPersonName.trim());
    setNewPersonName("");
    setIsAddModalOpen(false);
    setFormError(null);
  };

  const openEditModal = (person: string) => {
    setEditingPerson(person);
    setEditPersonName(person);
    setIsEditModalOpen(true);
    setFormError(null);
  };

  const handleEditPerson = () => {
    if (!editPersonName.trim()) {
      setFormError("Person name is required");
      return;
    }

    if (people.includes(editPersonName.trim()) && editPersonName.trim() !== editingPerson) {
      setFormError("This person already exists");
      return;
    }

    updatePerson(editingPerson, editPersonName.trim());
    setIsEditModalOpen(false);
    setFormError(null);
  };
  
  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('reimbursement');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount(bankAccountsData.length > 0 ? bankAccountsData[0].name : '');
    setTransactionCategory('');
    setTransactionPerson('');
    setSelectedCategoryIcon('');
    setFormError(null);
  };
  
  // Handle creating a new transaction
  const handleAddTransaction = () => {
    // Validate form fields
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }

    if (!transactionDescription.trim()) {
      setFormError("Description is required");
      return;
    }

    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }

    if (!transactionAccount) {
      setFormError("Account is required");
      return;
    }

    if (!transactionPerson.trim()) {
      setFormError("Person's name is required for reimbursements");
      return;
    }

    // Create and add the transaction
    addTransaction({
      date: transactionDate,
      type: transactionType,
      description: transactionDescription,
      amount: parseFloat(transactionAmount),
      account: transactionAccount,
      category: transactionCategory,
      categoryIcon: selectedCategoryIcon || getDefaultCategoryIcon(transactionType),
      person: transactionPerson
    });

    // Show success toast
    toast({
      title: "Transaction Added",
      description: "Your transaction has been successfully added.",
      duration: 3000,
    });

    // Close the modal and reset form
    setIsAddModalOpen(false);
    resetForm();
  };

  // Get color class based on balance status
  const getStatusColorClass = (balance: number) => {
    if (balance < 0) return "text-green-600"; // They owe you
    if (balance > 0) return "text-red-600";   // You owe them
    return "text-gray-500";                   // No balance
  };
  
  // Get background gradient for cards
  const getCardGradient = (index: number) => {
    const gradients = [
      "from-blue-50 to-blue-100 border-blue-200",
      "from-purple-50 to-purple-100 border-purple-200",
      "from-emerald-50 to-emerald-100 border-emerald-200",
      "from-amber-50 to-amber-100 border-amber-200",
      "from-cyan-50 to-cyan-100 border-cyan-200",
      "from-indigo-50 to-indigo-100 border-indigo-200"
    ];
    return gradients[index % gradients.length];
  };

  return (
    <div className="container mx-auto px-4 py-8 fade-in">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2.5">
            <Users className="h-7 w-7 text-primary" /> 
            <span className="primary-gradient-text">Receivables</span>
          </h1>
          <p className="text-gray-500 mt-1.5">
            Manage money owed to you and by you
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => setIsAddModalOpen(true)} 
                 className="h-10 px-4 shadow-sm bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white flex items-center gap-2">
            <PlusCircle className="h-4 w-4" /> Add Person
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* People Who Owe You Card */}
        <Card className="border border-green-200 shadow-sm bg-gradient-to-br from-green-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-green-700">They Owe You</h3>
              <div className="h-8 w-8 rounded-full bg-green-100 border border-green-200 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-green-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-3xl font-bold text-green-600">
                {formatCurrency(summary.peopleWhoOweYou)}
              </p>
              <p className="text-sm text-gray-500">
                Money others need to pay you
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* People You Owe Card */}
        <Card className="border border-red-200 shadow-sm bg-gradient-to-br from-red-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-red-700">You Owe Others</h3>
              <div className="h-8 w-8 rounded-full bg-red-100 border border-red-200 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-red-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-3xl font-bold text-red-600">
                {formatCurrency(summary.peopleYouOwe)}
              </p>
              <p className="text-sm text-gray-500">
                Money you need to pay back
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Net Balance Card */}
        <Card className={cn(
          "border shadow-sm bg-gradient-to-br",
          summary.netBalance >= 0 
            ? "from-blue-50 to-white border-blue-200" 
            : "from-amber-50 to-white border-amber-200"
        )}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-blue-700">Net Balance</h3>
              <div className="h-8 w-8 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center">
                <Wallet className="h-4 w-4 text-blue-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className={cn(
                "text-3xl font-bold", 
                summary.netBalance >= 0 ? "text-blue-600" : "text-amber-600"
              )}>
                {formatCurrency(Math.abs(summary.netBalance))}
              </p>
              <p className="text-sm text-gray-500">
                {summary.netBalance >= 0 ? "Net positive (you're owed)" : "Net negative (you owe)"}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {people.length === 0 ? (
        <Card className="border border-blue-200 shadow-sm overflow-hidden">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="rounded-full bg-blue-100 p-4 mb-4 border border-blue-200">
              <Users className="h-12 w-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No People Added</h3>
            <p className="text-gray-600 max-w-md mb-8">
              Add people to track reimbursements and money owed to or by you.
            </p>
            <Button onClick={() => setIsAddModalOpen(true)} 
                   className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white flex items-center gap-2">
              <PlusCircle className="h-4 w-4" /> Add Person
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {people.map((person, index) => {
            const balance = balances[person] || 0;
            const cardColorClass = getCardGradient(index);
            
            return (
              <Card key={person} className={cn(
                "group hover:shadow-md transition-all duration-300 border-2 overflow-hidden",
                balance < 0 
                  ? "border-green-300 bg-gradient-to-br from-green-50 to-white" 
                  : balance > 0
                  ? "border-red-300 bg-gradient-to-br from-red-50 to-white"
                  : "border-gray-300 bg-gradient-to-br from-gray-50 to-white"
              )}>
                {/* Header with Person's Name and Status - Redesigned to be more personal */}
                <div className="p-3 flex items-center justify-between border-b border-dashed border-current/20">
                  <div className="flex items-center space-x-3">
                    <div className={cn(
                      "h-10 w-10 rounded-lg flex items-center justify-center text-white shadow-sm flex-shrink-0",
                      balance < 0 ? "bg-gradient-to-br from-green-500 to-green-600" : 
                      balance > 0 ? "bg-gradient-to-br from-red-500 to-red-600" : 
                      "bg-gradient-to-br from-gray-500 to-gray-600"
                    )}>
                      <span className="text-lg font-bold">{person.charAt(0).toUpperCase()}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm leading-tight">{person}</h3>
                      <div className="flex items-center mt-0.5">
                        <FileText className="h-3 w-3 text-gray-400 mr-1" />
                        <p className="text-xs text-gray-500">
                          {transactions.filter(t => t.type === 'reimbursement' && t.person === person).length} transactions
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end space-y-1">
                    <Badge className={cn(
                      "px-2 py-0.5 text-xs font-medium",
                      balance < 0 
                        ? "bg-green-100 text-green-700 border-green-200" 
                        : balance > 0
                        ? "bg-red-100 text-red-700 border-red-200"
                        : "bg-gray-100 text-gray-700 border-gray-200"
                    )}>
                      {balance < 0 ? 'They Owe You' : balance > 0 ? 'You Owe Them' : 'No Balance'}
                    </Badge>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditModal(person)}
                        className="p-1 h-6 w-6 rounded-md text-blue-600 hover:bg-blue-100"
                        title="Edit Person"
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePerson(person)}
                        className="p-1 h-6 w-6 rounded-md text-red-600 hover:bg-red-100"
                        title="Delete Person"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Main content area - Redesigned with clearer hierarchy */}
                <div className="p-4">
                  {/* Balance display - Made larger and more prominent */}
                  <div className={cn(
                    "flex flex-col items-center mb-4 p-3 rounded-lg shadow-sm",
                    balance < 0 ? "bg-green-50 border border-green-200" : 
                    balance > 0 ? "bg-red-50 border border-red-200" : 
                    "bg-gray-50 border border-gray-200"
                  )}>
                    <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Current Balance</p>
                    <p className={cn(
                      "text-xl font-bold mt-1",
                      getStatusColorClass(balance)
                    )}>
                      {formatCurrency(Math.abs(balance || 0))}
                    </p>
                  </div>
                  
                  {/* Transaction types summary - Redesigned with icons */}
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    {/* Outgoing */}
                    <div className="rounded-lg p-3 border border-gray-200 bg-white shadow-sm">
                      <div className="flex items-center mb-1">
                        <ArrowUpRight className="h-3.5 w-3.5 text-green-600 mr-1.5" />
                        <p className="text-xs font-medium text-gray-700">You Paid</p>
                      </div>
                      <p className="font-semibold text-green-600 text-base">
                        {formatCurrency(
                          transactions
                            .filter(t => t.type === 'reimbursement' && t.person === person && t.amount > 0)
                            .reduce((sum, t) => sum + t.amount, 0)
                        )}
                      </p>
                    </div>
                    {/* Incoming */}
                    <div className="rounded-lg p-3 border border-gray-200 bg-white shadow-sm">
                      <div className="flex items-center mb-1">
                        <ArrowDown className="h-3.5 w-3.5 text-red-600 mr-1.5" />
                        <p className="text-xs font-medium text-gray-700">They Paid</p>
                      </div>
                      <p className="font-semibold text-red-600 text-base">
                        {formatCurrency(
                          transactions
                            .filter(t => t.type === 'reimbursement' && t.person === person && t.amount < 0)
                            .reduce((sum, t) => sum + Math.abs(t.amount), 0)
                        )}
                      </p>
                    </div>
                  </div>
                  
                  {/* Action Buttons - Redesigned with more visual distinction */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs py-2 border-gray-300 hover:bg-gray-50"
                      onClick={() => window.location.href = `/transactions?personFilter=${encodeURIComponent(person)}`}
                    >
                      <FileText className="h-3.5 w-3.5 mr-1.5" />
                      View Transactions
                    </Button>
                    
                    <Button
                        size="sm"
                        className={cn(
                          "text-xs py-2 text-white w-full",
                          balance < 0 ? "bg-green-600 hover:bg-green-700" :
                          balance > 0 ? "bg-red-600 hover:bg-red-700" :
                          "bg-blue-600 hover:bg-blue-700"
                        )}
                        onClick={() => {
                          resetForm();
                          setTransactionType('reimbursement');
                          setTransactionPerson(person);
                          if (bankAccountsData.length > 0) {
                            setTransactionAccount(bankAccountsData[0].name);
                          }
                          setIsAddModalOpen(true);
                        }}
                      >
                        <PlusCircle className="h-3.5 w-3.5 mr-1.5" />
                        Add Transaction
                      </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Person Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-md border border-blue-200 shadow-md">
          <DialogHeader className="pb-1">
            <DialogTitle className="text-xl flex items-center gap-2 text-blue-700">
              <Users className="h-5 w-5" /> Add Person
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700 border border-red-200">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Input
                placeholder="Enter person's name"
                value={newPersonName}
                onChange={(e) => setNewPersonName(e.target.value)}
                className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter the name of the person you want to track reimbursements with
              </p>
            </div>
          </div>
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsAddModalOpen(false);
                setFormError(null);
                setNewPersonName("");
              }}
              className="border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAddPerson}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <PlusCircle className="h-4 w-4 mr-2" /> Add Person
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Person Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-md border border-blue-200 shadow-md">
          <DialogHeader className="pb-1">
            <DialogTitle className="text-xl flex items-center gap-2 text-blue-700">
              <Edit className="h-5 w-5" /> Edit Person
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700 border border-red-200">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Input
                placeholder="Edit person's name"
                value={editPersonName}
                onChange={(e) => setEditPersonName(e.target.value)}
                className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                Updating this name will update all associated reimbursements
              </p>
            </div>
          </div>
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsEditModalOpen(false);
                setFormError(null);
              }}
              className="border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleEditPerson}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Edit className="h-4 w-4 mr-2" /> Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Transaction Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="modal-content p-0 sm:max-w-[550px]">
          <div className="modal-header">
            <DialogTitle className="modal-title">Add New Transaction</DialogTitle>
          </div>

          <div className="p-6 grid gap-4">
            {formError && (
              <div className="bg-red-50 text-red-800 p-3 rounded-md text-sm">
                {formError}
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select
                  value={transactionType}
                  onValueChange={(value: 'expense' | 'income' | 'reimbursement') => setTransactionType(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">Expense</SelectItem>
                    <SelectItem value="income">Income</SelectItem>
                    <SelectItem value="reimbursement">Reimbursement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (₹)</Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select
                value={transactionAccount}
                onValueChange={(value) => setTransactionAccount(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData.map((account) => (
                    <SelectItem key={account.id} value={account.name}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="person">Person</Label>
              <Select
                value={transactionPerson}
                onValueChange={(value) => setTransactionPerson(value)}
              >
                <SelectTrigger id="quick-person">
                  <SelectValue placeholder="Select person" />
                </SelectTrigger>
                <SelectContent>
                  {people.map((person) => (
                    <SelectItem key={person} value={person}>
                      {person}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="modal-footer">
            <Button 
              variant="outline" 
              onClick={() => setIsAddModalOpen(false)}
              className="modal-button-secondary"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAddTransaction}
              className="modal-button-primary"
            >
              Add Transaction
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
