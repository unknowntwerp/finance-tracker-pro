import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFinanceStore } from "@/lib/transactionStore";
import { formatCurrency } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusCircle, Trash2, AlertCircle, FileText, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function Receivables() {
  const { transactions, people, addPerson, removePerson, updatePerson } = useFinanceStore();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [newPersonName, setNewPersonName] = useState("");
  const [editingPerson, setEditingPerson] = useState("");
  const [editPersonName, setEditPersonName] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  // Calculate balances from reimbursement transactions
  const balances = useMemo(() => {
    const balanceMap: Record<string, number> = {};

    transactions
      .filter(t => t.type === 'reimbursement')
      .forEach(transaction => {
        if (!transaction.person) return;

        // Positive amount means you paid on their behalf (they owe you)
        // So we negate the amount to represent debt to you
        // Negative amount means they paid on your behalf (you owe them)
        const balanceChange = -transaction.amount;

        balanceMap[transaction.person] = (balanceMap[transaction.person] || 0) + balanceChange;
      });

    return balanceMap;
  }, [transactions]);

  const handleAddPerson = () => {
    if (!newPersonName.trim()) {
      setFormError("Person name is required");
      return;
    }

    if (people.includes(newPersonName.trim())) {
      setFormError("This person already exists");
      return;
    }

    addPerson(newPersonName.trim());
    setNewPersonName("");
    setIsAddModalOpen(false);
    setFormError(null);
  };

  const openEditModal = (person: string) => {
    setEditingPerson(person);
    setEditPersonName(person);
    setIsEditModalOpen(true);
    setFormError(null);
  };

  const handleEditPerson = () => {
    if (!editPersonName.trim()) {
      setFormError("Person name is required");
      return;
    }

    if (people.includes(editPersonName.trim()) && editPersonName.trim() !== editingPerson) {
      setFormError("This person already exists");
      return;
    }

    updatePerson(editingPerson, editPersonName.trim());
    setIsEditModalOpen(false);
    setFormError(null);
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">Receivables</h1>
        <Button onClick={() => setIsAddModalOpen(true)} className="flex items-center gap-2">
          <PlusCircle className="h-4 w-4" /> Add Person
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {people.length > 0 ? (
          people.map((person) => (
            <Card key={person}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">{person}</CardTitle>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => openEditModal(person)}
                    className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => removePerson(person)}
                    className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex flex-col items-center mb-4 p-3 bg-gray-50 rounded-lg">
                    <p className={balances[person] < 0 ? "text-2xl font-bold text-green-600" : balances[person] > 0 ? "text-2xl font-bold text-red-600" : "text-2xl font-bold text-gray-500"}>
                      {formatCurrency(Math.abs(balances[person] || 0))}
                    </p>
                    <p className="text-sm text-gray-500">
                      {balances[person] < 0 ? "They owe you" : balances[person] > 0 ? "You owe them" : "No balance"}
                    </p>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => window.location.href = `/?personFilter=${encodeURIComponent(person)}`}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    View Transactions
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-10">
            <p className="text-gray-500">No people added yet. Add someone to track reimbursements.</p>
          </div>
        )}
      </div>

      {/* Add Person Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Person</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Input
                placeholder="Enter person's name"
                value={newPersonName}
                onChange={(e) => setNewPersonName(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => {
              setIsAddModalOpen(false);
              setFormError(null);
              setNewPersonName("");
            }}>
              Cancel
            </Button>
            <Button onClick={handleAddPerson}>
              Add Person
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Person Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Person</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Input
                placeholder="Edit person's name"
                value={editPersonName}
                onChange={(e) => setEditPersonName(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => {
              setIsEditModalOpen(false);
              setFormError(null);
            }}>
              Cancel
            </Button>
            <Button onClick={handleEditPerson}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}