import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useFinanceStore } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, ListIcon, X, Building, CreditCard as CreditCardIcon, Tag } from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  renderCategoryIcon, 
  getCategoryIconsByType, 
  CategoryType, 
  getDefaultCategoryIcon 
} from "@/lib/categoryIcons";
import CategoryIconSelector from "@/components/CategoryIconSelector";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface CategoryWithIcon {
  name: string;
  iconId: string;
}

export default function ManageLists() {
  const { 
    expenseCategories, addExpenseCategory, removeExpenseCategory,
    incomeCategories, addIncomeCategory, removeIncomeCategory,
    categoryIcons, setCategoryIcons
  } = useFinanceStore();

  const [activeTab, setActiveTab] = useState("expense-categories");
  const [newExpenseCategory, setNewExpenseCategory] = useState("");
  const [newIncomeCategory, setNewIncomeCategory] = useState("");
  const [selectedExpenseIcon, setSelectedExpenseIcon] = useState(getDefaultCategoryIcon('expense'));
  const [selectedIncomeIcon, setSelectedIncomeIcon] = useState(getDefaultCategoryIcon('income'));
  const [iconDialogOpen, setIconDialogOpen] = useState(false);
  const [currentCategoryType, setCurrentCategoryType] = useState<'expense' | 'income'>('expense');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Get the icon ID for a category
  const getCategoryIcon = (category: string): string => {
    // First try to find exact match in the categoryIcons
    const iconInfo = categoryIcons.find(c => c.category === category);
    if (iconInfo?.iconId) {
      return iconInfo.iconId;
    }
    
    // Default fallback icons based on category type
    return activeTab === "expense-categories" ? 
      getDefaultCategoryIcon('expense') : 
      getDefaultCategoryIcon('income');
  };

  const handleAddExpenseCategory = () => {
    if (!newExpenseCategory.trim()) {
      setErrors(prev => ({ ...prev, expenseCategory: "Category name is required" }));
      return;
    }

    if (expenseCategories.includes(newExpenseCategory)) {
      setErrors(prev => ({ ...prev, expenseCategory: "Category already exists" }));
      return;
    }

    addExpenseCategory(newExpenseCategory);

    // Save the icon association
    const newCategoryIcons = [...categoryIcons, {
      category: newExpenseCategory,
      iconId: selectedExpenseIcon,
      type: "expense" as "expense" | "income" | "both"
    }];
    setCategoryIcons(newCategoryIcons);

    setNewExpenseCategory("");
    setSelectedExpenseIcon(getDefaultCategoryIcon('expense'));
    setErrors(prev => ({ ...prev, expenseCategory: "" }));
  };

  const handleAddIncomeCategory = () => {
    if (!newIncomeCategory.trim()) {
      setErrors(prev => ({ ...prev, incomeCategory: "Category name is required" }));
      return;
    }

    if (incomeCategories.includes(newIncomeCategory)) {
      setErrors(prev => ({ ...prev, incomeCategory: "Category already exists" }));
      return;
    }

    addIncomeCategory(newIncomeCategory);

    // Save the icon association
    const newCategoryIcons = [...categoryIcons, {
      category: newIncomeCategory,
      iconId: selectedIncomeIcon,
      type: "income" as "expense" | "income" | "both"
    }];
    setCategoryIcons(newCategoryIcons);

    setNewIncomeCategory("");
    setSelectedIncomeIcon(getDefaultCategoryIcon('income'));
    setErrors(prev => ({ ...prev, incomeCategory: "" }));
  };

  const handleRemoveExpenseCategory = (category: string) => {
    removeExpenseCategory(category);
    // Remove the icon association
    setCategoryIcons(categoryIcons.filter(c => c.category !== category));
  };

  const handleRemoveIncomeCategory = (category: string) => {
    removeIncomeCategory(category);
    // Remove the icon association
    setCategoryIcons(categoryIcons.filter(c => c.category !== category));
  };

  const openIconSelector = (type: 'expense' | 'income') => {
    setCurrentCategoryType(type);
    setIconDialogOpen(true);
  };

  const getEmptyMessage = (type: string) => {
    switch (type) {
      case "expense-categories":
        return "No expense categories added yet.";
      case "income-categories":
        return "No income categories added yet.";
      default:
        return "No items added yet.";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Tag className="h-6 w-6" /> Manage Categories
        </h1>
      </div>

      <Card>
        <CardContent className="py-6">
          <Tabs defaultValue="expense-categories" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="expense-categories" className="flex items-center gap-2">
                <Tag className="h-4 w-4" /> 
                <span className="hidden md:inline">Expense Categories</span>
                <span className="md:hidden">Expenses</span>
              </TabsTrigger>
              <TabsTrigger value="income-categories" className="flex items-center gap-2">
                <Tag className="h-4 w-4" /> 
                <span className="hidden md:inline">Income Categories</span>
                <span className="md:hidden">Income</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="expense-categories" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddExpenseCategory();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter expense category (e.g., Food, Transport)"
                    value={newExpenseCategory}
                    onChange={(e) => setNewExpenseCategory(e.target.value)}
                    className={cn(errors.expenseCategory && "border-red-500")}
                  />
                  {errors.expenseCategory && (
                    <p className="text-xs text-red-500 mt-1">{errors.expenseCategory}</p>
                  )}
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => openIconSelector('expense')}
                    >
                      {renderCategoryIcon(selectedExpenseIcon, 16)}
                      <span className="ml-1">Icon</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Select Category Icon</DialogTitle>
                    </DialogHeader>
                    <CategoryIconSelector 
                      selectedIcon={selectedExpenseIcon}
                      onSelectIcon={(iconId) => setSelectedExpenseIcon(iconId)} 
                      type="expense"
                    />
                  </DialogContent>
                </Dialog>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Expense Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {expenseCategories.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("expense-categories")}</p>
                  ) : (
                    expenseCategories.map((category, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3 bg-red-50"
                      >
                        {renderCategoryIcon(getCategoryIcon(category), 16, "mr-1")}
                        <span>{category}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveExpenseCategory(category)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="income-categories" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddIncomeCategory();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter income category (e.g., Salary, Bonus)"
                    value={newIncomeCategory}
                    onChange={(e) => setNewIncomeCategory(e.target.value)}
                    className={cn(errors.incomeCategory && "border-red-500")}
                  />
                  {errors.incomeCategory && (
                    <p className="text-xs text-red-500 mt-1">{errors.incomeCategory}</p>
                  )}
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => openIconSelector('income')}
                    >
                      {renderCategoryIcon(selectedIncomeIcon, 16)}
                      <span className="ml-1">Icon</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Select Category Icon</DialogTitle>
                    </DialogHeader>
                    <CategoryIconSelector 
                      selectedIcon={selectedIncomeIcon}
                      onSelectIcon={(iconId) => setSelectedIncomeIcon(iconId)} 
                      type="income"
                    />
                  </DialogContent>
                </Dialog>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Income Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {incomeCategories.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("income-categories")}</p>
                  ) : (
                    incomeCategories.map((category, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3 bg-green-50"
                      >
                        {renderCategoryIcon(getCategoryIcon(category), 16, "mr-1")}
                        <span>{category}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveIncomeCategory(category)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Icon Selection Dialog */}
      <Dialog open={iconDialogOpen} onOpenChange={setIconDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Select Category Icon</DialogTitle>
          </DialogHeader>
          <CategoryIconSelector 
            selectedIcon={currentCategoryType === 'expense' ? selectedExpenseIcon : selectedIncomeIcon}
            onSelectIcon={(iconId) => {
              if (currentCategoryType === 'expense') {
                setSelectedExpenseIcon(iconId);
              } else {
                setSelectedIncomeIcon(iconId);
              }
              setIconDialogOpen(false);
            }}
            type={currentCategoryType}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}