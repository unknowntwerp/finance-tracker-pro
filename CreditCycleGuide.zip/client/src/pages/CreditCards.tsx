import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, useFinanceStore } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Plus, CreditCard as CreditCardIcon, Calendar, Trash2, AlertCircle, DollarSign, Edit, FileText } from "lucide-react";
import { formatCurrency } from "@/lib/formatters";

// Generate a unique ID
const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};

export default function CreditCards() {
  const { creditCards, transactions, addCreditCard, updateCreditCard, removeCreditCard, bankAccountsData, addTransaction } = useFinanceStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CreditCard | null>(null);
  const [paymentBankAccount, setPaymentBankAccount] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [name, setName] = useState("");
  const [statementDay, setStatementDay] = useState("");
  const [daysAfter, setDaysAfter] = useState("");
  const [creditLimit, setCreditLimit] = useState("");
  const [merchantRules, setMerchantRules] = useState("");
  const [selectedCardForExport, setSelectedCardForExport] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editCardId, setEditCardId] = useState<string | null>(null);

  // Calculate total amount in the current cycle (between current and next statement dates)
  // This should also account for excess payments from statement balance
  const calculateCycleTotal = (card: CreditCard) => {
    // Current cycle transactions (excluding payments that are meant for statement balance)
    const currentCycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        // Only include transactions after the statement date (not including statement date)
        // and before the next statement date
        return txDate > cycleStart && txDate < cycleEnd && 
              !(t.type === "contra" && t.amount < 0 && t.metadata?.paymentFor === "statement_balance");
      });

    // Calculate raw current cycle amount from normal transactions
    const rawCycleTotal = currentCycleTransactions.reduce((sum, tx) => {
      // Income transactions should reduce the balance (negative amount for credit card)
      if (tx.type === 'income') {
        return sum - tx.amount; // Subtract income amounts (credit)
      } 
      // Expense transactions increase the balance (positive amount for credit card)
      else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
        return sum + tx.amount;
      }
      // Contra entries (payments) should be handled as is
      else {
        return sum + tx.amount;
      }
    }, 0);

    // Calculate statement balance and payments to determine excess
    const statementDate = new Date(card.currentStatementDate);
    const rawStatementBalance = transactions
      .filter(t => t.account === card.name)
      .filter(t => new Date(t.date) <= statementDate)
      .reduce((sum, tx) => {
        // Income transactions should reduce the balance (negative amount for credit card)
        if (tx.type === 'income') {
          return sum - tx.amount; // Subtract income amounts (credit)
        } 
        // Expense transactions increase the balance (positive amount for credit card)
        else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
          return sum + tx.amount;
        }
        // Contra entries (payments) should be handled as is
        else {
          return sum + tx.amount;
        }
      }, 0);

    // Find all payment transactions after statement date
    // Including both statement balance payments and explicit current cycle payments
    const allPaymentsAfterStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        return txDate > statementDate && 
               t.type === "contra" && 
               t.amount < 0;
      });
    
    // First, calculate excess from statement payments
    const statementPayments = allPaymentsAfterStatement.filter(t => 
      t.metadata?.paymentFor === "statement_balance"
    );
    
    // Calculate how much of each payment should go to statement vs. current cycle
    let remainingStatementBalance = Math.max(0, rawStatementBalance);
    let excessPaymentTotal = 0;

    for (const payment of statementPayments) {
      const paymentAmount = Math.abs(payment.amount);

      // If statement is already paid off, all goes to current cycle
      if (remainingStatementBalance <= 0) {
        excessPaymentTotal += paymentAmount;
        continue;
      }

      // Calculate how much of this payment is for statement vs excess
      const amountForStatement = Math.min(paymentAmount, remainingStatementBalance);
      const excess = paymentAmount - amountForStatement;

      // Apply to statement balance first
      remainingStatementBalance -= amountForStatement;

      // Any excess goes to current cycle
      if (excess > 0) {
        excessPaymentTotal += excess;
      }
    }
    
    // Next, add direct current cycle payments
    const currentCyclePayments = allPaymentsAfterStatement.filter(t => 
      t.metadata?.paymentFor === "current_cycle"
    );
    
    // Log for debugging
    console.log("DEBUGGING CARD:", card.name);
    console.log("Current Cycle Payments:", currentCyclePayments);
    console.log("All Payments After Statement:", allPaymentsAfterStatement);
    console.log("Raw Cycle Total before excess:", rawCycleTotal);
    console.log("Excess Payment Total before adding current cycle:", excessPaymentTotal);
    
    for (const payment of currentCyclePayments) {
      excessPaymentTotal += Math.abs(payment.amount);
      console.log("Added current cycle payment:", Math.abs(payment.amount));
      console.log("New excess total:", excessPaymentTotal);
    }
    
    console.log("Final Excess Payment Total:", excessPaymentTotal);
    console.log("Final Cycle Total:", rawCycleTotal - excessPaymentTotal);

    // Current cycle balance is raw charges minus excess payments
    return rawCycleTotal - excessPaymentTotal;
  };

  // Calculate statement balance (transactions before statement date)
  const calculateStatementBalance = (card: CreditCard) => {
    const statementDate = new Date(card.currentStatementDate);

    // Get all transactions on or before the statement date
    const allTransactionsBeforeStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        // Include transactions on the statement date (same day)
        return txDate <= statementDate;
      });

    // Calculate the raw statement balance, accounting for transaction types
    const rawStatementBalance = allTransactionsBeforeStatement.reduce((sum, tx) => {
      // Income transactions should reduce the balance (negative amount for credit card)
      if (tx.type === 'income') {
        return sum - tx.amount; // Subtract income amounts (credit)
      } 
      // Expense transactions increase the balance (positive amount for credit card)
      else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
        return sum + tx.amount;
      }
      // Contra entries (payments) should be handled as is
      else {
        return sum + tx.amount;
      }
    }, 0);

    console.log("RAW STATEMENT BALANCE FOR", card.name, ":", rawStatementBalance);

    // Find payments made after statement date that should reduce the statement balance
    // Only include payments explicitly marked for statement balance
    const paymentsAfterStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        return txDate > statementDate && 
               t.type === "contra" && 
               t.amount < 0 && 
               t.metadata?.paymentFor === "statement_balance";
      });

    // Calculate how much payment to apply
    let appliedPayments = 0;

    // Sort payments by date (oldest first)
    const sortedPayments = [...paymentsAfterStatement].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    console.log("PAYMENTS AFTER STATEMENT:", sortedPayments);

    // If statement balance is already negative (overpaid from previous cycle),
    // return the negative balance immediately
    if (rawStatementBalance < 0) {
      console.log("Returning negative statement balance:", rawStatementBalance);
      return rawStatementBalance;
    }

    // If there's no positive statement balance, return 0
    if (rawStatementBalance <= 0) {
      console.log("No statement balance");
      return 0;
    }

    // Process payments
    let remainingStatementBalance = rawStatementBalance;

    for (const payment of sortedPayments) {
      const paymentAmount = Math.abs(payment.amount);

      // If statement balance is already paid off, no need to apply more payments
      if (remainingStatementBalance <= 0) break;

      // Apply payment to statement balance (limited by remaining balance)
      const amountToApply = Math.min(paymentAmount, remainingStatementBalance);
      appliedPayments += amountToApply;
      remainingStatementBalance -= amountToApply;
    }

    const finalBalance = rawStatementBalance - appliedPayments;
    console.log("FINAL STATEMENT BALANCE:", finalBalance);
    return finalBalance;
  };

  const exportCardTransactions = (card: CreditCard) => {
    const cycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      });

    const csv = [
      ['Date', 'Description', 'Amount', 'Category'].join(','),
      ...cycleTransactions.map(t => 
        [t.date, t.description, t.amount, t.category].join(',')
      )
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}-statement.csv`;
    a.click();
  };

  const resetForm = () => {
    setName("");
    setStatementDay("");
    setDaysAfter("");
    setCreditLimit("");
    setFormError(null);
  };

  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const handlePayment = () => {
    if (!selectedCard || !paymentBankAccount || !paymentAmount || !paymentDate) return;

    const amount = parseFloat(paymentAmount);
    const date = paymentDate;

    // Get the current statement balance
    const statementBalance = calculateStatementBalance(selectedCard);

    // Add contra transaction pair for credit card payment
    // For bank account: negative amount (money goes out)
    addTransaction({
      date,
      type: "contra",
      description: `Payment to ${selectedCard.name}`,
      amount: -amount, // Negative amount for bank account (money going out)
      account: paymentBankAccount,
      category: "Credit Card Payment"
    });

    // Determine payment application:
    // If payment is less than or equal to statement balance, apply all to statement
    // If payment exceeds statement balance, split into two transactions
    if (amount <= statementBalance || statementBalance <= 0) {
      // Apply entire payment to statement balance (or current cycle if no statement balance)
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount}`,
        amount: -amount, // Negative amount for credit card (reduces outstanding debt)
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: statementBalance > 0 ? "statement_balance" : "current_cycle", 
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: amount
        }
      });
    } else {
      // Split payment: part for statement balance, part for current cycle
      // First transaction - pay off statement balance
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Statement)`,
        amount: -statementBalance, // Amount that covers statement balance
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "statement_balance",
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: statementBalance
        }
      });

      // Second transaction - excess payment for current cycle
      const excessAmount = amount - statementBalance;
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Current Cycle)`,
        amount: -excessAmount, // Excess amount
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "current_cycle",
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: excessAmount
        }
      });
    }

    // Reset payment form
    setIsPaymentDialogOpen(false);
    setSelectedCard(null);
    setPaymentBankAccount("");
    setPaymentAmount("");
    setPaymentDate(new Date().toISOString().split('T')[0]);
  };

  const getPaymentStatus = (card: CreditCard) => {
    const now = new Date();
    const dueDate = new Date(card.dueDate);

    // Get current statement balance after payments
    const currentStatementBalance = calculateStatementBalance(card);

    const statementDate = new Date(card.currentStatementDate);
    const rawStatementBalance = transactions
      .filter(t => t.account === card.name)
      .filter(t => new Date(t.date) < statementDate)
      .reduce((sum, tx) => {
        // Income transactions should reduce the balance (negative amount for credit card)
        if (tx.type === 'income') {
          return sum - tx.amount; // Subtract income amounts (credit)
        } 
        // Expense transactions increase the balance (positive amount for credit card)
        else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
          return sum + tx.amount;
        }
        // Contra entries (payments) should be handled as is
        else {
          return sum + tx.amount;
        }
      }, 0);

    // If there never was a statement balance or it's been fully paid off
    if (currentStatementBalance <= 0) {
      // If there was a real statement balance that's now paid off
      if (rawStatementBalance > 0) {
        return "fully paid";
      }
      // If there was never a statement balance to begin with
      return "no due";
    }

    // If statement balance exists and is partially paid
    if (currentStatementBalance > 0 && currentStatementBalance < rawStatementBalance) {
      return "partially paid";
    }

    // If statement is unpaid and overdue
    if (currentStatementBalance > 0 && now > dueDate) {
      return "overdue";
    }

    // If statement is unpaid but not yet due
    return "pending";
  };

  const handleAddOrUpdateCard = () => {
    // Form validation
    if (!name.trim()) {
      setFormError("Card name is required");
      return;
    }

    const statementDayNum = parseInt(statementDay);
    if (isNaN(statementDayNum) || statementDayNum < 1 || statementDayNum > 31) {
      setFormError("Statement day must be between 1 and 31");
      return;
    }

    const daysAfterNum = parseInt(daysAfter);
    if (isNaN(daysAfterNum) || daysAfterNum < 1 || daysAfterNum > 60) {
      setFormError("Days after must be between 1 and 60");
      return;
    }

    const creditLimitNum = parseFloat(creditLimit);
    if (isNaN(creditLimitNum) || creditLimitNum <= 0) {
      setFormError("Credit limit must be a positive number");
      return;
    }

    const cardData = {
      name,
      statementDay: statementDayNum,
      daysAfter: daysAfterNum,
      creditLimit: creditLimitNum,
      merchantRules: merchantRules.trim() ? merchantRules.split(',').map(rule => rule.trim()) : undefined
    };

    if (isEditMode && editCardId) {
      // Update existing card
      updateCreditCard(editCardId, cardData);
    } else {
      // Add new card
      addCreditCard(cardData);
    }

    // Close dialog and reset form
    setIsDialogOpen(false);
    resetForm();
  };

  const handleOpenDialog = () => {
    resetForm();
    setIsEditMode(false);
    setEditCardId(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditDialog = (card: CreditCard) => {
    resetForm();
    setName(card.name);
    setStatementDay(String(card.statementDay));
    setDaysAfter(String(card.daysAfter));
    setCreditLimit(String(card.creditLimit));
    setMerchantRules(card.merchantRules?.join(',') || '');
    setIsEditMode(true);
    setEditCardId(card.id);
    setIsDialogOpen(true);
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "no due":
      case "fully paid":
        return "bg-green-100 text-green-800";
      case "partially paid":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
    });
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <CreditCardIcon className="h-7 w-7" /> Credit Cards
        </h1>
        <Button onClick={handleOpenDialog} className="flex items-center gap-2 text-base px-4 py-2 h-auto">
          <Plus className="h-5 w-5" /> Add Card
        </Button>
      </div>

      {creditCards.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <CreditCardIcon className="h-8 w-8 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Credit Cards Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-4">
              Add your credit cards to track statement dates, payment due dates, and balances.
            </p>
            <Button onClick={handleOpenDialog}>
              <Plus className="h-4 w-4 mr-2" /> Add Credit Card
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-0 -mx-1">
          {creditCards.map((card) => {
            // Calculate payment status for each card
            const paymentStatus = getPaymentStatus(card);

            return (
            <Card 
              key={card.id} 
              className="overflow-hidden hover:shadow-md transition-shadow border-gray-200 m-1"
              style={{
                background: paymentStatus === "fully paid" || paymentStatus === "no due" 
                  ? "linear-gradient(to right, #e6f7ef, #ffffff)" 
                  : paymentStatus === "partially paid" 
                    ? "linear-gradient(to right, #e6f0fa, #ffffff)" 
                    : paymentStatus === "pending" 
                      ? "linear-gradient(to right, #fef5e7, #ffffff)" 
                      : "linear-gradient(to right, #feebeb, #ffffff)",
                borderLeft: paymentStatus === "fully paid" || paymentStatus === "no due" 
                  ? "4px solid rgb(34, 197, 94)" 
                  : paymentStatus === "partially paid" 
                    ? "4px solid rgb(59, 130, 246)" 
                    : paymentStatus === "pending" 
                      ? "4px solid rgb(234, 179, 8)" 
                      : "4px solid rgb(239, 68, 68)"
              }}
            >
              <CardHeader className="pb-1.5 px-3 pt-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-base font-bold tracking-tight truncate">{card.name}</CardTitle>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleOpenEditDialog(card)}
                      className="p-0.5 h-auto text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCreditCard(card.id)}
                      className="p-0.5 h-auto text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex justify-between mt-1.5">
                  <Badge variant="outline" className="px-2 py-0.5 text-xs bg-white border font-medium">
                    {formatCurrency(card.creditLimit)}
                  </Badge>
                  <Badge 
                    className={`px-2 py-0.5 text-xs font-medium ${
                      paymentStatus === "fully paid" || paymentStatus === "no due" ? "bg-green-100 text-green-800 border-green-200" :
                      paymentStatus === "partially paid" ? "bg-blue-100 text-blue-800 border-blue-200" :
                      paymentStatus === "pending" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                      "bg-red-100 text-red-800 border-red-200"
                    }`}
                  >
                    {paymentStatus === "no due" ? "No Due" : 
                     paymentStatus === "fully paid" ? "Fully Paid" :
                     paymentStatus === "partially paid" ? "Partially Paid" :
                     paymentStatus.charAt(0).toUpperCase() + paymentStatus.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="px-3 pb-3 pt-1">
                <div className="space-y-3">
                  <div className="grid grid-cols-3 gap-1 text-sm bg-gray-50 rounded-lg p-1.5 border border-gray-100">
                    <div className="text-center p-1.5 bg-white rounded shadow-sm">
                      <div className="uppercase font-semibold text-xs text-indigo-600 mb-0.5">Statement</div>
                      <div className="font-medium">{formatDate(card.currentStatementDate)}</div>
                    </div>
                    <div className="text-center p-1.5 bg-white rounded shadow-sm">
                      <div className="uppercase font-semibold text-xs text-purple-600 mb-0.5">Next</div>
                      <div className="font-medium">{formatDate(card.nextStatementDate)}</div>
                    </div>
                    <div className="text-center p-1.5 bg-white rounded shadow-sm">
                      <div className="uppercase font-semibold text-xs text-orange-600 mb-0.5">Due</div>
                      <div className={`font-medium ${
                        paymentStatus === "overdue" ? "text-red-600 font-bold" : 
                        new Date(card.dueDate) <= new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000) ? "text-amber-600" : "text-gray-800"
                      }`}>
                        {formatDate(card.dueDate)}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1 text-sm pt-1.5">
                    <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors">
                      <span className="text-gray-700 flex items-center gap-1">
                        <Badge variant="outline" className="h-2 w-2 p-0 bg-red-500 border-none rounded-full"/>
                        Statement Balance
                      </span>
                      <span className={`font-medium ${
                        calculateStatementBalance(card) > 0 
                          ? "text-red-600" 
                          : calculateStatementBalance(card) < 0 
                            ? "text-green-600" 
                            : "text-gray-500"
                      }`}>
                        {formatCurrency(calculateStatementBalance(card), false, true)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors">
                      <span className="text-gray-700 flex items-center gap-1">
                        <Badge variant="outline" className="h-2 w-2 p-0 bg-blue-500 border-none rounded-full"/>
                        Current Cycle
                      </span>
                      <span className={`font-medium ${
                        calculateCycleTotal(card) > 0
                          ? "text-blue-600"
                          : calculateCycleTotal(card) < 0
                            ? "text-green-600"
                            : "text-blue-600"
                      }`}>
                        {formatCurrency(calculateCycleTotal(card), false, true)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors font-medium">
                      <span className="text-gray-800 flex items-center gap-1">
                        <Badge variant="outline" className="h-2 w-2 p-0 bg-purple-500 border-none rounded-full"/>
                        Total Outstanding
                      </span>
                      {(() => {
                        // Debugging
                        const statementBalance = calculateStatementBalance(card);
                        const cycleTotal = calculateCycleTotal(card);
                        const totalOutstanding = statementBalance + cycleTotal;
                        
                        console.log("TOTAL CALCULATION FOR:", card.name);
                        console.log("Statement Balance:", statementBalance);
                        console.log("Cycle Total:", cycleTotal);
                        console.log("Total Outstanding:", totalOutstanding);
                        
                        return (
                          <span className={`font-medium ${
                            totalOutstanding > 0 
                              ? "text-red-600" 
                              : totalOutstanding < 0
                                ? "text-green-600"
                                : "text-gray-900"
                          }`}>
                            {formatCurrency(totalOutstanding, false, true)}
                          </span>
                        );
                      })()}
                    </div>
                    <div className="flex justify-between items-center p-1.5 mt-1 hover:bg-gray-50 rounded transition-colors">
                      <span className="text-gray-700 flex items-center gap-1">
                        <Badge variant="outline" className="h-2 w-2 p-0 bg-green-500 border-none rounded-full"/>
                        Available Credit
                      </span>
                      {(() => {
                        const statementBalance = calculateStatementBalance(card);
                        const cycleTotal = calculateCycleTotal(card);
                        const totalOutstanding = statementBalance + cycleTotal;
                        const availableCredit = card.creditLimit - totalOutstanding;
                        
                        console.log("AVAILABLE CREDIT FOR:", card.name);
                        console.log("Credit Limit:", card.creditLimit);
                        console.log("Total Outstanding:", totalOutstanding);
                        console.log("Available Credit:", availableCredit);
                        
                        return (
                          <span className="font-medium text-green-600">
                            {formatCurrency(availableCredit, false, true)}
                          </span>
                        );
                      })()}
                    </div>
                  </div>

                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs flex-1 h-7 px-1.5"
                      onClick={() => window.location.href = '/transactions?account=' + card.name}
                    >
                      <FileText className="h-3.5 w-3.5 mr-1" />
                      <span className="truncate">View Transactions</span>
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedCard(card);
                        setIsPaymentDialogOpen(true);
                      }}
                      variant="default"
                      size="sm"
                      className="text-xs flex-1 h-7 bg-indigo-600 hover:bg-indigo-700 px-1.5 whitespace-nowrap"
                    >
                      Pay Bill
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Make Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedCard && (
              <>
                <div className="space-y-2">
                  <Label>Card</Label>
                  <p className="text-sm font-medium">{selectedCard.name}</p>
                </div>
                <div className="space-y-2">
                  <Label>Statement Balance</Label>
                  <p className={`text-sm font-medium ${
                    calculateStatementBalance(selectedCard) < 0 ? "text-green-600" : ""
                  }`}>
                    {formatCurrency(calculateStatementBalance(selectedCard), false, true)}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentBankAccount">Pay From Account</Label>
                  <Select
                    value={paymentBankAccount}
                    onValueChange={setPaymentBankAccount}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccountsData.length > 0 ? 
                        bankAccountsData.map((account) => (
                          <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                        )) : 
                        <div className="text-xs text-gray-500 px-2 py-1.5">
                          No bank accounts added yet
                        </div>
                      }
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Payment Amount</Label>
                  <Input
                    id="paymentAmount"
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    placeholder="Enter amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentDate">Payment Date</Label>
                  <Input
                    id="paymentDate"
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePayment} disabled={!selectedCard || !paymentBankAccount || !paymentAmount}>
              Submit Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Edit Credit Card' : 'Add Credit Card'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="name">Card Name</Label>
              <Input
                id="name"
                placeholder="e.g., AMEX Gold, Chase Sapphire"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="statementDay">
                  Statement Day
                  <span className="ml-1 text-xs text-gray-500">(1-31)</span>
                </Label>
                <Input
                  id="statementDay"
                  type="number"
                  min="1"
                  max="31"
                  placeholder="e.g., 15"
                  value={statementDay}
                  onChange={(e) => setStatementDay(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="daysAfter">
                  Days Until Due
                  <span className="ml-1 text-xs text-gray-500">(after statement)</span>
                </Label>
                <Input
                  id="daysAfter"
                  type="number"
                  min="1"
                  max="60"
                  placeholder="e.g., 21"
                  value={daysAfter}
                  onChange={(e) => setDaysAfter(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="creditLimit">Credit Limit</Label>
              <Input
                id="creditLimit"
                type="number"
                min="0"
                step="0.01"
                placeholder="e.g., 10000"
                value={creditLimit}
                onChange={(e) => setCreditLimit(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="merchantRules">
                Merchant Keywords
                <span className="ml-1 text-xs text-gray-500">(comma-separated)</span>
              </Label>
              <Input
                id="merchantRules"
                placeholder="e.g., amazon, netflix, spotify"
                value={merchantRules}
                onChange={(e) => setMerchantRules(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Transactions containing these keywords will be automatically tagged to this card
              </p>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddOrUpdateCard}>
              {isEditMode ? 'Save Changes' : 'Add Card'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}