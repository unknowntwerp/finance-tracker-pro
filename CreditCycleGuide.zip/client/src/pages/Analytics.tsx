import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend, 
  LineChart, Line, CartesianGrid, AreaChart, Area
} from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useFinanceStore, Transaction } from "@/lib/transactionStore";
import { 
  BarChart3, PieChart as PieChartIcon, CalendarDays, ChevronDown, ArrowUpRight, ArrowDownRight, 
  Wallet, TrendingUp, BadgeDollarSign, ChevronRight, LineChart as LineChartIcon, 
  DollarSign, BarChart4, CircleSlash, CircleDot, Info, Filter, 
  Layers, Calendar, Download, Share2, List as ListIcon, TrendingDown, Tag, PiggyBank
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { renderCategoryIcon, getCategoryIconById, getDefaultCategoryIcon } from "@/lib/categoryIcons";

export default function Analytics() {
  const { transactions } = useFinanceStore();
  const [periodFilter, setPeriodFilter] = useState("thisMonth");
  const [typeFilter, setTypeFilter] = useState("all");
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [activeTimeframe, setActiveTimeframe] = useState("monthly");

  // State for category transaction modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryTransactions, setCategoryTransactions] = useState<Transaction[]>([]);

  // For date selection on month-to-month comparison
  useEffect(() => {
    if (periodFilter === "thisMonth") {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      setStartDate(firstDay.toISOString().split('T')[0]);
      setEndDate(now.toISOString().split('T')[0]);
    }
  }, [periodFilter]);

  // Define colors for charts
  const COLORS = [
    "#4f46e5", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", 
    "#8b5cf6", "#06b6d4", "#84cc16", "#f97316", "#ec4899"
  ];

  // Filter transactions based on user selections
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      // Type filter
      if (typeFilter !== "all" && transaction.type !== typeFilter) {
        return false;
      }

      // Period filter
      if (periodFilter !== "all" && periodFilter !== "customRange") {
        const txDate = new Date(transaction.date);
        const now = new Date();

        switch (periodFilter) {
          case "thisMonth":
            return txDate.getMonth() === now.getMonth() && 
                   txDate.getFullYear() === now.getFullYear();
          case "lastMonth":
            const lastMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
            const lastMonthYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
            return txDate.getMonth() === lastMonth && 
                   txDate.getFullYear() === lastMonthYear;
          case "thisYear":
            return txDate.getFullYear() === now.getFullYear();
          case "lastYear":
            return txDate.getFullYear() === now.getFullYear() - 1;
          default:
            return true;
        }
      }

      // Custom date range filter
      if (periodFilter === "customRange") {
        const txDate = new Date(transaction.date);

        if (startDate) {
          const filterStart = new Date(startDate);
          // Set to start of day
          filterStart.setHours(0, 0, 0, 0);
          if (txDate < filterStart) {
            return false;
          }
        }

        if (endDate) {
          const filterEnd = new Date(endDate);
          // Set to end of day
          filterEnd.setHours(23, 59, 59, 999);
          if (txDate > filterEnd) {
            return false;
          }
        }
      }

      return true;
    });
  }, [transactions, periodFilter, typeFilter, startDate, endDate]);

  // Calculate category data for pie chart
  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};

    filteredTransactions
      .filter(transaction => transaction.type === 'expense') // Only include expense transactions
      .forEach(transaction => {
        const { category, amount } = transaction;
        // Double-check to make sure no transfers get through
        if (category !== 'Transfer' && transaction.type !== 'transfer') {
          if (!categories[category]) {
            categories[category] = 0;
          }
          categories[category] += amount;
        }
      });

    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value); // Sort by amount desc
  }, [filteredTransactions]);

  // Calculate daily spending trend
  const dailySpendingTrend = useMemo(() => {
    const result: { date: string; amount: number }[] = [];

    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);

      // Create array of all dates in range
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        const dateStr = d.toISOString().split('T')[0];
        result.push({ date: dateStr, amount: 0 });
      }

      // Add transaction amounts to dates
      filteredTransactions
        .filter(t => t.type === 'expense')
        .forEach(transaction => {
          const dateStr = transaction.date.split('T')[0];
          const dayData = result.find(d => d.date === dateStr);
          if (dayData) {
            dayData.amount += transaction.amount;
          }
        });
    }

    return result;
  }, [filteredTransactions, startDate, endDate]);

  // Calculate monthly data for bar chart
  const monthlyData = useMemo(() => {
    const months: Record<string, { income: number; expense: number }> = {};

    // Initialize all months
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    // Create data for last 6 months
    for (let i = 0; i < 6; i++) {
      let monthIndex = currentMonth - i;
      let year = currentYear;

      if (monthIndex < 0) {
        monthIndex += 12;
        year -= 1;
      }

      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const monthKey = `${monthNames[monthIndex]} ${year}`;

      months[monthKey] = { income: 0, expense: 0 };
    }

    // Aggregate transaction data
    filteredTransactions.forEach(transaction => {
      const { date, type, amount } = transaction;
      const txDate = new Date(date);
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const monthKey = `${monthNames[txDate.getMonth()]} ${txDate.getFullYear()}`;

      if (months[monthKey]) {
        if (type === "income") {
          months[monthKey].income += amount;
        } else {
          months[monthKey].expense += amount;
        }
      }
    });

    // Convert to array and reverse to show oldest month first
    return Object.entries(months)
      .map(([name, data]) => ({ name, ...data, savings: data.income - data.expense }))
      .reverse();
  }, [filteredTransactions]);

  // Calculate top spending categories
  const topSpendingCategories = useMemo(() => {
    return categoryData.slice(0, 5).map(category => {
      const totalExpenses = filteredTransactions
        .filter(t => t.type === 'expense')
        .reduce((acc, curr) => acc + curr.amount, 0);

      return {
        ...category,
        percentage: totalExpenses > 0 ? (category.value / totalExpenses) * 100 : 0
      };
    });
  }, [categoryData, filteredTransactions]);

  // Calculate summary data
  const summaryData = useMemo(() => {
    let income = 0;
    let expense = 0;
    let prevPeriodIncome = 0;
    let prevPeriodExpense = 0;

    // Current period
    filteredTransactions.forEach(transaction => {
      if (transaction.type === "income") {
        income += transaction.amount;
      } else {
        expense += transaction.amount;
      }
    });

    // Calculate previous period for comparison
    // For simplicity, we're just using a different date range
    // In a real app, you'd need to determine the previous period based on current filter
    const now = new Date();
    const prevPeriodEnd = new Date(now.getFullYear(), now.getMonth(), 0);
    const prevPeriodStart = new Date(prevPeriodEnd.getFullYear(), prevPeriodEnd.getMonth(), 1);

    transactions.forEach(transaction => {
      const txDate = new Date(transaction.date);
      if (txDate >= prevPeriodStart && txDate <= prevPeriodEnd) {
        if (transaction.type === "income") {
          prevPeriodIncome += transaction.amount;
        } else {
          prevPeriodExpense += transaction.amount;
        }
      }
    });

    const incomeChange = prevPeriodIncome > 0 
      ? ((income - prevPeriodIncome) / prevPeriodIncome) * 100 
      : income > 0 ? 100 : 0;

    const expenseChange = prevPeriodExpense > 0 
      ? ((expense - prevPeriodExpense) / prevPeriodExpense) * 100 
      : expense > 0 ? 100 : 0;

    return {
      income,
      expense,
      balance: income - expense,
      incomeChange,
      expenseChange,
      balanceChange: prevPeriodIncome - prevPeriodExpense !== 0 
        ? (((income - expense) - (prevPeriodIncome - prevPeriodExpense)) / Math.abs(prevPeriodIncome - prevPeriodExpense)) * 100 
        : (income - expense) !== 0 ? 100 : 0
    };
  }, [filteredTransactions, transactions]);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Format percentage
  const formatPercentage = (value: number) => {
    return `${value > 0 ? "+" : ""}${value.toFixed(1)}%`;
  };

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border shadow-sm rounded-md">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const handleBarClick = (data: any) => {
    toast({ 
      title: "Month Details", 
      description: `${data.name}: Income - ${formatCurrency(data.income)}, Expenses - ${formatCurrency(data.expense)}` 
    });
  };

  const handlePieClick = (data: any) => {
    if (!data || !data.payload) return;

    const category = data.payload.name;
    const categoryAmount = data.payload.value;

    // Filter transactions for this category
    const transactions = filteredTransactions.filter(
      t => t.type === 'expense' && t.category === category
    );

    if (transactions.length === 0) {
      toast({ 
        title: "No Transactions Found", 
        description: `No transactions found for ${category}`
      });
      return;
    }

    // Set the selected category and its transactions
    setSelectedCategory(category);
    setCategoryTransactions(transactions);
    setIsModalOpen(true);
  };

  // Function to export analytics as CSV
  const exportAnalytics = () => {
    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";

    // Add headers
    csvContent += "Category,Amount\n";

    // Add data
    categoryData.forEach(({ name, value }) => {
      csvContent += `${name},${value}\n`;
    });

    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `finance_analytics_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);

    // Trigger download
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Export Complete",
      description: "Your analytics data has been exported to CSV"
    });
  };

  return (
    <div className="space-y-8 fade-in">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2.5">
            <BarChart3 className="h-7 w-7 text-primary" /> 
            <span className="primary-gradient-text">Financial Analytics</span>
          </h1>
          <p className="text-gray-500 mt-1.5">
            Track your income, expenses, and financial trends
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 self-end">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span>Filters</span>
                <ChevronDown className="h-4 w-4 opacity-70" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-4" align="end">
              <div className="space-y-4">
                <h4 className="font-medium text-sm">Filter Options</h4>

                <div className="space-y-2">
                  <Label htmlFor="periodFilter">Time Period</Label>
                  <Select 
                    value={periodFilter} 
                    onValueChange={(value) => {
                      setPeriodFilter(value);

                      if (value === "customRange") {
                        setDatePickerOpen(true);
                      } else {
                        // Reset date range when selecting other options
                        if (value !== "thisMonth") {
                          setStartDate(null);
                          setEndDate(null);
                        }
                      }
                    }}
                  >
                    <SelectTrigger id="periodFilter" className="w-full">
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Time</SelectItem>
                      <SelectItem value="thisMonth">This Month</SelectItem>
                      <SelectItem value="lastMonth">Last Month</SelectItem>
                      <SelectItem value="thisYear">This Year</SelectItem>
                      <SelectItem value="lastYear">Last Year</SelectItem>
                      <SelectItem value="customRange">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="typeFilter">Transaction Type</Label>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger id="typeFilter" className="w-full">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="income">Income Only</SelectItem>
                      <SelectItem value="expense">Expenses Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {periodFilter === "customRange" && (
                  <div className="space-y-2">
                    <Label>Date Range</Label>
                    <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
                      <PopoverTrigger asChild>
                        <Button 
                          variant="outline" 
                          className="w-full flex justify-between items-center text-sm"
                        >
                          <CalendarDays className="h-4 w-4 mr-2" />
                          {startDate && endDate ? (
                            `${format(new Date(startDate), "dd/MM/yyyy")} - ${format(new Date(endDate), "dd/MM/yyyy")}`
                          ) : (
                            "Select date range"
                          )}
                          <ChevronDown className="h-4 w-4 opacity-70" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <div className="flex flex-col p-4 gap-4">
                          <div>
                            <h4 className="font-medium mb-2">Start Date</h4>
                            <CalendarComponent
                              mode="single"
                              selected={startDate ? new Date(startDate) : undefined}
                              onSelect={(date) => date && setStartDate(date.toISOString().split('T')[0])}
                              initialFocus
                            />
                          </div>
                          <div>
                            <h4 className="font-medium mb-2">End Date</h4>
                            <CalendarComponent
                              mode="single"
                              selected={endDate ? new Date(endDate) : undefined}
                              onSelect={(date) => date && setEndDate(date.toISOString().split('T')[0])}
                              initialFocus
                            />
                          </div>
                          <Button 
                            className="w-full bg-gradient-to-r from-royal to-violet text-white"
                            onClick={() => setDatePickerOpen(false)}
                          >
                            Apply Range
                          </Button>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                )}
              </div>
            </PopoverContent>
          </Popover>

          <Button 
            variant="outline"
            onClick={exportAnalytics}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Analytics Tabs */}
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList className="bg-gray-100">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-royal data-[state=active]:to-violet data-[state=active]:text-white">
              Overview
            </TabsTrigger>
            <TabsTrigger value="income" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-royal data-[state=active]:to-violet data-[state=active]:text-white">
              Income Analysis
            </TabsTrigger>
            <TabsTrigger value="expenses" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-royal data-[state=active]:to-violet data-[state=active]:text-white">
              Expense Analysis
            </TabsTrigger>
            <TabsTrigger value="trends" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-royal data-[state=active]:to-violet data-[state=active]:text-white">
              Trends
            </TabsTrigger>
          </TabsList>

          <div className="hidden md:flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              className={activeTimeframe === "monthly" ? "bg-gray-100" : ""}
              onClick={() => setActiveTimeframe("monthly")}
            >
              Monthly
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              className={activeTimeframe === "quarterly" ? "bg-gray-100" : ""}
              onClick={() => setActiveTimeframe("quarterly")}
            >
              Quarterly
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              className={activeTimeframe === "yearly" ? "bg-gray-100" : ""}
              onClick={() => setActiveTimeframe("yearly")}
            >
              Yearly
            </Button>
          </div>
        </div>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Income</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-2xl font-bold text-blue-600">
                      ₹{summaryData.income.toLocaleString()}
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={summaryData.incomeChange >= 0 ? "default" : "destructive"}
                        className={`flex items-center gap-1 font-medium ${summaryData.incomeChange >= 0 ? 'bg-green-100 text-green-800' : ''}`}
                      >
                        {summaryData.incomeChange >= 0 ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3" />
                        )}
                        {formatPercentage(summaryData.incomeChange)}
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">vs last period</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-2xl font-bold text-red-600">
                      ₹{summaryData.expense.toLocaleString()}
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={summaryData.expenseChange <= 0 ? "default" : "destructive"}
                        className={`flex items-center gap-1 font-medium ${summaryData.expenseChange <= 0 ? 'bg-green-100 text-green-800' : ''}`}
                      >
                        {summaryData.expenseChange <= 0 ? (
                          <ArrowDownRight className="h-3 w-3" />
                        ) : (
                          <ArrowUpRight className="h-3 w-3" />
                        )}
                        {formatPercentage(Math.abs(summaryData.expenseChange))}
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">vs last period</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                    <BadgeDollarSign className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className={`text-2xl font-bold ${summaryData.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ₹{summaryData.balance.toLocaleString()}
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={summaryData.balanceChange >= 0 ? "default" : "destructive"}
                        className={`flex items-center gap-1 font-medium ${summaryData.balanceChange >= 0 ? 'bg-green-100 text-green-800' : ''}`}
                      >
                        {summaryData.balanceChange >= 0 ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3" />
                        )}
                        {formatPercentage(summaryData.balanceChange)}
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">vs last period</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                    <Wallet className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          {transactions.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <BarChart3 className="h-10 w-10 text-gray-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">No Transaction Data</h3>
                <p className="text-gray-500 text-center max-w-md">
                  Add transactions to see charts and analytics about your spending.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-5 grid-cols-1 lg:grid-cols-2">
              {/* Monthly Income/Expense */}
              <Card className="card-hover">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" /> Monthly Breakdown
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <Info className="h-4 w-4 text-gray-500" />
                    </Button>
                  </div>
                  <CardDescription>
                    Income, expenses, and savings comparison
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        data={monthlyData} 
                        margin={{ top: 10, right: 10, left: 10, bottom: 20 }} 
                        barGap={5}
                        barCategoryGap={20}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar 
                          name="Income" 
                          dataKey="income" 
                          fill="url(#incomeGradient)" 
                          barSize={20} 
                          radius={[4, 4, 0, 0]}
                          onClick={(data) => handleBarClick(data)}
                        />
                        <Bar 
                          name="Expenses" 
                          dataKey="expense" 
                          fill="url(#expenseGradient)" 
                          barSize={20} 
                          radius={[4, 4, 0, 0]}
                          onClick={(data) => handleBarClick(data)}
                        />
                        <Bar 
                          name="Savings" 
                          dataKey="savings" 
                          fill="url(#savingsGradient)" 
                          barSize={20} 
                          radius={[4, 4, 0, 0]}
                          onClick={(data) => handleBarClick(data)}
                        />
                        <defs>
                          <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#0063CC" />
                            <stop offset="100%" stopColor="#38B2AC" />
                          </linearGradient>
                          <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#F56565" />
                            <stop offset="100%" stopColor="#ED8936" />
                          </linearGradient>
                          <linearGradient id="savingsGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#38B2AC" />
                            <stop offset="100%" stopColor="#48BB78" />
                          </linearGradient>
                        </defs>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 border-t border-gray-100">
                  <div className="flex items-center justify-between w-full text-xs text-gray-500">
                    <span>Updated: {format(new Date(), 'dd MMM yyyy')}</span>
                    <Button variant="link" size="sm" className="flex items-center p-0 h-auto text-xs text-primary">
                      See detailed report <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>

              {/* Daily Spending Trend */}
              <Card className="card-hover">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <LineChartIcon className="h-5 w-5 text-primary" /> Spending Trends
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <Info className="h-4 w-4 text-gray-500" />
                    </Button>
                  </div>
                  <CardDescription>
                    Daily expense patterns over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={dailySpendingTrend}
                        margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
                      >
                        <defs>
                          <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#0063CC" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#0063CC" stopOpacity={0.1}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fontSize: 12 }} 
                          axisLine={false} 
                          tickLine={false}
                          tickFormatter={(value) => {
                            const date = new Date(value);
                            return format(date, 'dd MMM');
                          }}
                        />
                        <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                        <Tooltip 
                          formatter={(value: any) => formatCurrency(value)}
                          labelFormatter={(label) => format(new Date(label), 'dd MMM yyyy')}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="amount" 
                          stroke="#0063CC" 
                          fillOpacity={1} 
                          fill="url(#colorExpense)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 border-t border-gray-100">
                  <div className="flex items-center justify-between w-full text-xs text-gray-500">
                    <span>Updated: {format(new Date(), 'dd MMM yyyy')}</span>
                    <Button variant="link" size="sm" className="flex items-center p-0 h-auto text-xs text-primary">
                      See detailed report <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          )}

          {/* Category Breakdown + Top Spending */}
          {transactions.length > 0 && (
            <div className="grid gap-5 grid-cols-1 lg:grid-cols-2">
              {/* Category Breakdown */}
              <Card className="card-hover">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <PieChartIcon className="h-5 w-5 text-primary" /> Expense Categories
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <Info className="h-4 w-4 text-gray-500" />
                    </Button>
                  </div>
                  <CardDescription>
                    Spending distribution by category
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          fill="#8884d8"
                          paddingAngle={4}
                          dataKey="value"
                          labelLine={false}
                          onClick={handlePieClick}
                          label={({ name, percent }) => 
                            `${name}: ${(percent * 100).toFixed(0)}%`
                          }
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: any) => formatCurrency(value)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 border-t border-gray-100">
                  <div className="flex items-center justify-between w-full text-xs text-gray-500">
                    <span>Click on category for details</span>
                    <Button variant="link" size="sm" className="flex items-center p-0 h-auto text-xs text-primary">
                      Analyze categories <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>

              {/* Top Spending Categories */}
              <Card className="card-hover">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <BarChart4 className="h-5 w-5 text-primary" /> Top Expenses
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <Info className="h-4 w-4 text-gray-500" />
                    </Button>
                  </div>
                  <CardDescription>
                    Categories with highest spending
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-5">
                    {topSpendingCategories.length > 0 ? (
                      topSpendingCategories.map((category, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <CircleDot 
                                className="h-3 w-3"
                                style={{ color: COLORS[index % COLORS.length] }}
                              />
                              <div className="flex items-center gap-1.5">
                                {(() => {
                                  // Get proper icon ID from useFinanceStore
                                  const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                                    c.category === category.name && c.type === 'expense'
                                  );
                                  const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');
                                  return renderCategoryIcon(iconId, 16, "text-gray-600", false);
                                })()}
                                <span className="font-medium text-sm">{category.name}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm font-semibold">
                                {formatCurrency(category.value)}
                              </span>
                              <span className="text-xs text-gray-500">
                                ({category.percentage.toFixed(1)}%)
                              </span>
                            </div>
                          </div>
                          <Progress 
                            value={category.percentage} 
                            className="h-2.5"
                            style={{
                              background: 'rgba(0, 0, 0, 0.05)',
                            }}
                          >
                            <div 
                              className="h-full" 
                              style={{ 
                                background: COLORS[index % COLORS.length],
                                width: `${category.percentage}%`,
                                borderRadius: 'inherit'
                              }}
                            />
                          </Progress>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center py-10 text-center">
                        <CircleSlash className="h-12 w-12 text-gray-300 mb-4" />
                        <h3 className="text-base font-medium text-gray-700">No expense data</h3>
                        <p className="text-sm text-gray-500 max-w-xs mt-1">
                          Add some expense transactions to see your top spending categories
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="pt-0 border-t border-gray-100">
                  <div className="flex items-center justify-between w-full text-xs text-gray-500">
                    <span>Based on current period</span>
                    <Button variant="link" size="sm" className="flex items-center p-0 h-auto text-xs text-primary">
                      Set budget limits <ChevronRight className="h-3 w-3 ml-1" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Income Analysis Tab */}
        <TabsContent value="income" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Income Summary Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Total Income</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-2xl font-bold text-blue-600">
                      {formatCurrency(summaryData.income)}
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={summaryData.incomeChange >= 0 ? "default" : "destructive"}
                        className={`flex items-center gap-1 font-medium ${summaryData.incomeChange >= 0 ? 'bg-green-100 text-green-800' : ''}`}
                      >
                        {summaryData.incomeChange >= 0 ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3" />
                        )}
                        {formatPercentage(summaryData.incomeChange)}
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">vs last period</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Average Income Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Average Monthly</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    {/* Calculate average monthly income */}
                    <p className="text-2xl font-bold text-blue-600">
                      {formatCurrency(summaryData.income / 
                        Math.max(1, Math.ceil((new Date().getTime() - 
                          new Date(transactions[transactions.length - 1]?.date || new Date()).getTime()) / 
                          (30 * 24 * 60 * 60 * 1000))))}
                    </p>
                    <div className="flex items-center mt-2">
                      <span className="text-xs text-gray-500">Based on recorded history</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <CalendarDays className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Transactions Count Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    {/* Count income transactions */}
                    <p className="text-2xl font-bold text-blue-600">
                      {transactions.filter(t => t.type === 'income').length}
                    </p>
                    <div className="flex items-center mt-2">
                      <span className="text-xs text-gray-500">Total income transactions</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <ListIcon className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Income Sources and Trends */}
          <div className="grid gap-5 grid-cols-1 lg:grid-cols-2">
            {/* Income by Source */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <PieChartIcon className="h-5 w-5 text-primary" /> Income Sources
                  </CardTitle>
                  <Button variant="ghost" size="sm">
                    <Info className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
                <CardDescription>
                  Distribution of income by category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={transactions
                          .filter(t => t.type === 'income')
                          .reduce((acc, t) => {
                            const existing = acc.find(item => item.name === t.category);
                            if (existing) {
                              existing.value += t.amount;
                            } else {
                              acc.push({ name: t.category, value: t.amount });
                            }
                            return acc;
                          }, [] as { name: string, value: number }[])
                          .sort((a, b) => b.value - a.value)}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={4}
                        dataKey="value"
                        labelLine={false}
                        label={({ name, percent }) => 
                          `${name}: ${(percent * 100).toFixed(0)}%`
                        }
                      >
                        {transactions
                          .filter(t => t.type === 'income')
                          .reduce((acc, t) => {
                            const existing = acc.find(item => item.name === t.category);
                            if (existing) {
                              existing.value += t.amount;
                            } else {
                              acc.push({ name: t.category, value: t.amount });
                            }
                            return acc;
                          }, [] as { name: string, value: number }[])
                          .sort((a, b) => b.value - a.value)
                          .map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                      </Pie>
                      <Tooltip formatter={(value: any) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t border-gray-100">
                <div className="flex items-center justify-between w-full text-xs text-gray-500">
                  <span>Updated: {format(new Date(), 'dd MMM yyyy')}</span>
                </div>
              </CardFooter>
            </Card>

            {/* Monthly Income Trend */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <LineChartIcon className="h-5 w-5 text-primary" /> Income Trend
                  </CardTitle>
                  <Button variant="ghost" size="sm">
                    <Info className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
                <CardDescription>
                  Monthly income over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={(() => {
                        // Generate monthly income data
                        const monthlyData: Record<string, number> = {};

                        // Get range of dates in transactions
                        const dates = transactions
                          .filter(t => t.type === 'income')
                          .map(t => new Date(t.date));

                        if (dates.length === 0) return [];

                        const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                        const maxDate = new Date();

                        // Initialize all months in range
                        let currentDate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
                        while (currentDate <= maxDate) {
                          const key = format(currentDate, 'MMM yyyy');
                          monthlyData[key] = 0;
                          currentDate.setMonth(currentDate.getMonth() + 1);
                        }

                        // Sum income by month
                        transactions
                          .filter(t => t.type === 'income')
                          .forEach(t => {
                            const date = new Date(t.date);
                            const key = format(date, 'MMM yyyy');
                            monthlyData[key] = (monthlyData[key] || 0) + t.amount;
                          });

                        // Convert to array for chart
                        return Object.entries(monthlyData)
                          .map(([name, amount]) => ({ name, amount }));
                      })()}
                      margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fontSize: 12 }} 
                        axisLine={false} 
                        tickLine={false}
                      />
                      <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <Tooltip 
                        formatter={(value: any) => formatCurrency(value)}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#4f46e5" 
                        strokeWidth={2}
                        dot={{ r: 4, strokeWidth: 1 }}
                        activeDot={{ r: 6, stroke: '#4f46e5', strokeWidth: 1 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t border-gray-100">
                <div className="flex items-center justify-between w-full text-xs text-gray-500">
                  <span>Updated: {format(new Date(), 'dd MMM yyyy')}</span>
                </div>
              </CardFooter>
            </Card>
          </div>

          {/* Top Income Sources Table */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" /> Top Income Sources
                </CardTitle>
              </div>
              <CardDescription>
                Your highest income categories
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead>Transactions</TableHead>
                    <TableHead>Average</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions
                    .filter(t => t.type === 'income')
                    .reduce((acc, t) => {
                      const existing = acc.find(item => item.category === t.category);
                      if (existing) {
                        existing.total += t.amount;
                        existing.count += 1;
                      } else {
                        acc.push({ 
                          category: t.category, 
                          total: t.amount, 
                          count: 1 
                        });
                      }
                      return acc;
                    }, [] as { category: string, total: number, count: number }[])
                    .sort((a, b) => b.total - a.total)
                    .slice(0, 5)
                    .map((source, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {(() => {
                                // Get proper icon ID for this category
                                const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                                  c.category === source.category && c.type === 'income'
                                );
                                const iconId = iconInfo?.iconId || getDefaultCategoryIcon('income');
                                return (
                                  <>
                                    {renderCategoryIcon(iconId, 16, "text-gray-600", false)}
                                    <span className="ml-1.5">{source.category}</span>
                                  </>
                                );
                              })()}
                          </div>
                        </TableCell>
                        <TableCell>{source.count}</TableCell>
                        <TableCell>{formatCurrency(source.total / source.count)}</TableCell>
                        <TableCell className="text-right font-semibold text-blue-600">
                          {formatCurrency(source.total)}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Expense Analysis Tab */}
        <TabsContent value="expenses" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Expense Summary Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Total Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-2xl font-bold text-red-600">
                      {formatCurrency(summaryData.expense)}
                    </p>
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={summaryData.expenseChange <= 0 ? "default" : "destructive"}
                        className={`flex items-center gap-1 font-medium ${summaryData.expenseChange <= 0 ? 'bg-green-100 text-green-800' : ''}`}
                      >
                        {summaryData.expenseChange <= 0 ? (
                          <ArrowDownRight className="h-3 w-3" />
                        ) : (
                          <ArrowUpRight className="h-3 w-3" />
                        )}
                        {formatPercentage(Math.abs(summaryData.expenseChange))}
                      </Badge>
                      <span className="text-xs text-gray-500 ml-2">vs last period</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                    <TrendingDown className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Average Expense Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Average Monthly</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    {/* Calculate average monthly expense */}
                    <p className="text-2xl font-bold text-red-600">
                      {formatCurrency(summaryData.expense / 
                        Math.max(1, Math.ceil((new Date().getTime() - 
                          new Date(transactions[transactions.length - 1]?.date || new Date()).getTime()) / 
                          (30 * 24 * 60 * 60 * 1000))))}
                    </p>
                    <div className="flex items-center mt-2">
                      <span className="text-xs text-gray-500">Based on recorded history</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                    <CalendarDays className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Expense Transactions Count Card */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-gray-500">Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    {/* Count expense transactions */}
                    <p className="text-2xl font-bold text-red-600">
                      {transactions.filter(t => t.type === 'expense').length}
                    </p>
                    <div className="flex items-center mt-2">
                      <span className="text-xs text-gray-500">Total expense transactions</span>
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                    <ListIcon className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Expense Categories and Monthly Trend */}
          <div className="grid gap-5 grid-cols-1 lg:grid-cols-2">
            {/* Top Expense Categories */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <BarChart4 className="h-5 w-5 text-primary" /> Top Expenses
                  </CardTitle>
                </div>
                <CardDescription>
                  Categories with highest spending
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-5">
                  {categoryData.slice(0, 5).map((category, index) => {
                    const totalExpenses = filteredTransactions
                      .filter(t => t.type === 'expense')
                      .reduce((acc, curr) => acc + curr.amount, 0);

                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <CircleDot 
                              className="h-3 w-3"
                              style={{ color: COLORS[index % COLORS.length] }}
                            />
                            <div className="flex items-center gap-1.5">
                              {(() => {
                                // Get proper icon ID from useFinanceStore
                                const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                                  c.category === category.name && c.type === 'expense'
                                );
                                const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');
                                return (
                                  <>
                                    {renderCategoryIcon(iconId, 16, "text-gray-600", false)}
                                    <span className="ml-1.5">{category.name}</span>
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-semibold">
                              {formatCurrency(category.value)}
                            </span>
                            <span className="text-xs text-gray-500">
                              ({totalExpenses > 0 ? ((category.value / totalExpenses) * 100).toFixed(1) : 0}%)
                            </span>
                          </div>
                        </div>
                        <Progress 
                          value={totalExpenses > 0 ? (category.value / totalExpenses) * 100 : 0} 
                          className="h-2.5"
                          style={{
                            background: 'rgba(0, 0, 0, 0.05)',
                          }}
                        >
                          <div 
                            className="h-full" 
                            style={{ 
                              background: COLORS[index % COLORS.length],
                              width: `${totalExpenses > 0 ? (category.value / totalExpenses) * 100 : 0}%`,
                              borderRadius: 'inherit'
                            }}
                          />
                        </Progress>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t border-gray-100">
                <div className="flex items-center justify-between w-full text-xs text-gray-500">
                  <span>Based on current period</span>
                </div>
              </CardFooter>
            </Card>

            {/* Monthly Expense Trend */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <LineChartIcon className="h-5 w-5 text-primary" /> Expense Trend
                  </CardTitle>
                </div>
                <CardDescription>
                  Monthly expenses over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={(() => {
                        // Generate monthly expense data
                        const monthlyData: Record<string, number> = {};

                        // Get range of dates in transactions
                        const dates = transactions
                          .filter(t => t.type === 'expense')
                          .map(t => new Date(t.date));

                        if (dates.length === 0) return [];

                        const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                        const maxDate = new Date();

                        // Initialize all months in range
                        let currentDate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
                        while (currentDate <= maxDate) {
                          const key = format(currentDate, 'MMM yyyy');
                          monthlyData[key] = 0;
                          currentDate.setMonth(currentDate.getMonth() + 1);
                        }

                        // Sum expense by month
                        transactions
                          .filter(t => t.type === 'expense')
                          .forEach(t => {
                            const date = new Date(t.date);
                            const key = format(date, 'MMM yyyy');
                            monthlyData[key] = (monthlyData[key] || 0) + t.amount;
                          });

                        // Convert to array for chart
                        return Object.entries(monthlyData)
                          .map(([name, amount]) => ({ name, amount }));
                      })()}
                      margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
                    >
                      <defs>
                        <linearGradient id="colorExpenseTrend" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fontSize: 12 }} 
                        axisLine={false} 
                        tickLine={false}
                      />
                      <YAxis 
                        tick={{ fontSize: 12 }} 
                        axisLine={false} 
                        tickLine={false} 
                      />
                      <Tooltip 
                        formatter={(value: any) => formatCurrency(value)}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#ef4444" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorExpenseTrend)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t border-gray-100">
                <div className="flex items-center justify-between w-full text-xs text-gray-500">
                  <span>Updated: {format(new Date(), 'dd MMM yyyy')}</span>
                </div>
              </CardFooter>
            </Card>
          </div>

          {/* Expense by Day of Week & Time of Day */}
          <div className="grid gap-5 grid-cols-1 lg:grid-cols-2">
            {/* Day of Week Analysis */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <CalendarDays className="h-5 w-5 text-primary" /> Day of Week Analysis
                </CardTitle>
                <CardDescription>
                  When you spend the most during the week
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={(() => {
                        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        const dayData = days.map(day => ({ name: day, amount: 0 }));

                        transactions
                          .filter(t => t.type === 'expense')
                          .forEach(t => {
                            const date = new Date(t.date);
                            const dayIndex = date.getDay();
                            dayData[dayIndex].amount += t.amount;
                          });

                        return dayData;
                      })()}
                      margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fontSize: 12 }} 
                        axisLine={false} 
                        tickLine={false}
                        tickFormatter={(value) => value.substring(0, 3)} // Show only first 3 letters
                      />
                      <YAxis 
                        tick={{ fontSize: 12 }} 
                        axisLine={false} 
                        tickLine={false} 
                      />
                      <Tooltip 
                        formatter={(value: any) => formatCurrency(value)}
                      />
                      <Bar 
                        dataKey="amount" 
                        fill="url(#dayGradient)" 
                        radius={[4, 4, 0, 0]}
                      />
                      <defs>
                        <linearGradient id="dayGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#F56565" />
                          <stop offset="100%" stopColor="#ED8936" />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Average by Category */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Tag className="h-5 w-5 text-primary" /> Monthly Category Averages
                </CardTitle>
                <CardDescription>
                  Average monthly spending by category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead>Monthly Avg</TableHead>
                      <TableHead className="text-right">% of Expenses</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(() => {
                      // Calculate duration in months
                      const dates = transactions
                        .filter(t => t.type === 'expense')
                        .map(t => new Date(t.date));

                      if (dates.length === 0) return [];

                      const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                      const maxDate = new Date();

                      // Calculate months between min and max date (at least 1)
                      const months = Math.max(1, 
                        (maxDate.getFullYear() - minDate.getFullYear()) * 12 + 
                        maxDate.getMonth() - minDate.getMonth() + 1);

                      // Calculate category totals
                      const totals = transactions
                        .filter(t => t.type === 'expense')
                        .reduce((acc, t) => {
                          if (!acc[t.category]) acc[t.category] = 0;
                          acc[t.category] += t.amount;
                          return acc;
                        }, {} as Record<string, number>);

                      // Calculate total expenses
                      const totalExpenses = Object.values(totals).reduce((sum, val) => sum + val, 0);

                      // Convert to array with monthly averages
                      return Object.entries(totals)
                        .map(([category, total]) => ({
                          category,
                          monthlyAvg: total / months,
                          percentage: (total / totalExpenses) * 100
                        }))
                        .sort((a, b) => b.monthlyAvg - a.monthlyAvg)
                        .slice(0, 5);
                    })().map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {(() => {
                              // Get proper icon ID from useFinanceStore
                              const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                                c.category === item.category && c.type === 'expense'
                              );
                              const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');
                              return (
                                <>
                                  {renderCategoryIcon(iconId, 16, "text-gray-600", false)}
                                  <span className="ml-1.5">{item.category}</span>
                                </>
                              );
                            })()}
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(item.monthlyAvg)}</TableCell>
                        <TableCell className="text-right">{item.percentage.toFixed(1)}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="space-y-6">
          {/* Year Over Year Comparison */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <LineChartIcon className="h-5 w-5 text-primary" /> Income vs Expense Trends
              </CardTitle>
              <CardDescription>
                Compare your income and expenses over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={(() => {
                      // Generate monthly data for both income and expense
                      const monthlyData: Record<string, { name: string, income: number, expense: number }> = {};

                      // Get range of dates in transactions
                      const dates = transactions.map(t => new Date(t.date));

                      if (dates.length === 0) return [];

                      const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                      const maxDate = new Date();

                      // Initialize all months in range
                      let currentDate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
                      while (currentDate <= maxDate) {
                        const key = format(currentDate, 'MMM yyyy');
                        monthlyData[key] = { name: key, income: 0, expense: 0 };
                        currentDate.setMonth(currentDate.getMonth() + 1);
                      }

                      // Sum by month and type
                      transactions.forEach(t => {
                        const date = new Date(t.date);
                        const key = format(date, 'MMM yyyy');

                        if (t.type === 'income') {
                          monthlyData[key].income += t.amount;
                        } else if (t.type === 'expense') {
                          monthlyData[key].expense += t.amount;
                        }
                      });

                      // Convert to array and sort chronologically
                      return Object.values(monthlyData)
                        .sort((a, b) => {
                          const dateA = new Date(a.name);
                          const dateB = new Date(b.name);
                          return dateA.getTime() - dateB.getTime();
                        });
                    })()}
                    margin={{ top: 10, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="name" 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false} 
                    />
                    <Tooltip formatter={(value: any) => formatCurrency(value)} />
                    <Legend />
                    <Line 
                      name="Income" 
                      type="monotone" 
                      dataKey="income" 
                      stroke="#4f46e5" 
                      strokeWidth={2}
                      dot={{ r: 3 }}
                      activeDot={{ r: 5 }}
                    />
                    <Line 
                      name="Expenses" 
                      type="monotone" 
                      dataKey="expense" 
                      stroke="#ef4444" 
                      strokeWidth={2}
                      dot={{ r: 3 }}
                      activeDot={{ r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Savings Rate Trend */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <PiggyBank className="h-5 w-5 text-primary" /> Savings Rate
              </CardTitle>
              <CardDescription>
                Percentage of income saved each month
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={(() => {
                      // Generate monthly savings rate data
                      const monthlyData: Record<string, { name: string, income: number, expense: number }> = {};

                      // Get range of dates in transactions
                      const dates = transactions.map(t => new Date(t.date));

                      if (dates.length === 0) return [];

                      const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                      const maxDate = new Date();

                      // Initialize all months in range
                      let currentDate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
                      while (currentDate <= maxDate) {
                        const key = format(currentDate, 'MMM yyyy');
                        monthlyData[key] = { name: key, income: 0, expense: 0 };
                        currentDate.setMonth(currentDate.getMonth() + 1);
                      }

                      // Sum by month and type
                      transactions.forEach(t => {
                        const date = new Date(t.date);
                        const key = format(date, 'MMM yyyy');

                        if (t.type === 'income') {
                          monthlyData[key].income += t.amount;
                        } else if (t.type === 'expense') {
                          monthlyData[key].expense += t.amount;
                        }
                      });

                      // Calculate savings rate
                      return Object.values(monthlyData)
                        .sort((a, b) => {
                          const dateA = new Date(a.name);
                          const dateB = new Date(b.name);
                          return dateA.getTime() - dateB.getTime();
                        })
                        .map(month => ({
                          name: month.name,
                          rate: month.income > 0 
                            ? ((month.income - month.expense) / month.income) * 100 
                            : 0
                        }));
                    })()}
                    margin={{ top: 10, right: 30, left: 20, bottom: 20 }}
                  >
                    <defs>
                      <linearGradient id="colorSavings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="name" 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false}
                      tickFormatter={(value) => `${value}%`}
                    />
                    <Tooltip 
                      formatter={(value: any) => `${value.toFixed(1)}%`}
                      labelFormatter={(label) => `Savings Rate (${label})`}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="rate" 
                      stroke="#10b981" 
                      fillOpacity={1} 
                      fill="url(#colorSavings)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
            <CardFooter className="pt-0 border-t border-gray-100">
              <div className="flex items-center justify-between w-full text-xs text-gray-500">
                <span>Higher percentage indicates better saving habits</span>
              </div>
            </CardFooter>
          </Card>

          {/* Year over Year Comparison Table */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" /> Year over Year Comparison
              </CardTitle>
              <CardDescription>
                Compare financial metrics across years
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Year</TableHead>
                    <TableHead>Income</TableHead>
                    <TableHead>Expenses</TableHead>
                    <TableHead className="text-right">Net Savings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(() => {
                    // Get unique years from transactions
                    const years = [...new Set(
                      transactions.map(t => new Date(t.date).getFullYear())
                    )].sort((a, b) => b - a); // Sort descending

                    return years.map(year => {
                      // Filter transactions for this year
                      const yearTransactions = transactions.filter(t => 
                        new Date(t.date).getFullYear() === year
                      );

                      // Calculate totals
                      const income = yearTransactions
                        .filter(t => t.type === 'income')
                        .reduce((sum, t) => sum + t.amount, 0);

                      const expenses = yearTransactions
                        .filter(t => t.type === 'expense')
                        .reduce((sum, t) => sum + t.amount, 0);

                      const savings = income - expenses;

                      return { year, income, expenses, savings };
                    });
                  })().map((yearData) => (
                    <TableRow key={yearData.year}>
                      <TableCell className="font-medium">{yearData.year}</TableCell>
                      <TableCell>{formatCurrency(yearData.income)}</TableCell>
                      <TableCell>{formatCurrency(yearData.expenses)}</TableCell>
                      <TableCell className={`text-right font-semibold ${yearData.savings >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(yearData.savings)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Net Worth Trend */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" /> Cumulative Net Worth
              </CardTitle>
              <CardDescription>
                Track your growing net worth over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={(() => {
                      // Generate monthly cumulative data
                      const monthlyData: Record<string, { name: string, date: Date, balance: number }> = {};

                      // Get range of dates in transactions
                      const dates = transactions.map(t => new Date(t.date));

                      if (dates.length === 0) return [];

                      const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
                      const maxDate = new Date();

                      // Initialize all months in range
                      let currentDate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
                      while (currentDate <= maxDate) {
                        const key = format(currentDate, 'MMM yyyy');
                        monthlyData[key] = { 
                          name: key, 
                          date: new Date(currentDate),
                          balance: 0 
                        };
                        currentDate.setMonth(currentDate.getMonth() + 1);
                      }

                      // Sort transactions by date
                      const sortedTransactions = [...transactions].sort(
                        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
                      );

                      // Calculate running balance
                      let runningBalance = 0;

                      sortedTransactions.forEach(t => {
                        if (t.type === 'income') {
                          runningBalance += t.amount;
                        } else if (t.type === 'expense') {
                          runningBalance -= t.amount;
                        }

                        const date = new Date(t.date);
                        const key = format(date, 'MMM yyyy');

                        // Update the balance for this month and all future months
                        Object.values(monthlyData).forEach(month => {
                          if (month.date >= date) {
                            month.balance = runningBalance;
                          }
                        });
                      });

                      // Convert to array and sort chronologically
                      return Object.values(monthlyData)
                        .sort((a, b) => a.date.getTime() - b.date.getTime());
                    })()}
                    margin={{ top: 10, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="name" 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false} 
                    />
                    <Tooltip 
                      formatter={(value: any) => formatCurrency(value)}
                      labelFormatter={(label) => `Net Worth (${label})`}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="balance" 
                      stroke="#8b5cf6" 
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#8b5cf6' }}
                      activeDot={{ r: 6, stroke: '#8b5cf6', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Category Transactions Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-xl">
              <PieChartIcon className="h-5 w-5 text-primary" /> 
              {selectedCategory} Transactions
            </DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Account</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categoryTransactions.map((tx) => (
                  <TableRow key={tx.id} className="data-table-row-clickable">
                    <TableCell>
                      {format(new Date(tx.date), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell>{tx.description}</TableCell>
                    <TableCell>
                      {tx.account}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(tx.amount)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <DialogFooter className="flex items-center justify-between gap-4 sm:justify-between mt-4">
            <span className="text-sm text-gray-500">
              Total: {formatCurrency(categoryTransactions.reduce((acc, curr) => acc + curr.amount, 0))}
            </span>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsModalOpen(false)}>
                Close
              </Button>
              <Button 
                className="bg-gradient-to-r from-royal to-violet text-white"
                onClick={() => {
                  toast({
                    title: "Export Complete",
                    description: `${selectedCategory} transactions exported to CSV`
                  });
                  setIsModalOpen(false);
                }}
              >
                <Download className="h-4 w-4 mr-2" /> Export
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}