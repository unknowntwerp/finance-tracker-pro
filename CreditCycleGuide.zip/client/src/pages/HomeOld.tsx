import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileUp, Plus, Clipboard, Trash2, AlertCircle } from "lucide-react";
import { useFinanceStore, Transaction, ImportTransaction } from "@/lib/transactionStore";
import { formatDate } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { 
    transactions, 
    removeTransaction, 
    addTransaction,
    creditCards, 
    bankAccountsData, 
    expenseCategories,
    incomeCategories,
    people 
  } = useFinanceStore();
  const { toast } = useToast();

  // Transaction modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<string>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState(''); // Added state for person in reimbursement
  const [formError, setFormError] = useState<string | null>(null);
  const [editingIndex, setEditingIndex] = useState<number>(-1);

  //Sort and filter states
  const [sortField, setSortField] = useState<'date' | 'amount' | 'category'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filterText, setFilterText] = useState('');
  const [cycleFilter, setCycleFilter] = useState<string | null>(null);
  const [periodFilter, setPeriodFilter] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);
  const [personFilter, setPersonFilter] = useState<string | null>(null); // Added person filter state


  // Get filters from URL query parameters
  const queryParams = new URLSearchParams(window.location.search);
  const accountFilter = queryParams.get('account');
  const personFilterParam = queryParams.get('personFilter');

  // Initialize personFilter state with URL parameter if present
  useEffect(() => {
    if (personFilterParam) {
      setPersonFilter(personFilterParam);
    }
  }, [personFilterParam]);


  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('expense');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setTransactionPerson(''); // Reset person field
    setFormError(null);
  };

  // Handle opening the add transaction modal
  const handleOpenAddModal = () => {
    resetForm();

    // Set default values
    if (bankAccountsData.length > 0) {
      setTransactionAccount(bankAccountsData[0].name);
    }
    if (expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    }

    setIsAddModalOpen(true);
  };

  // Handle creating a new transaction
  const handleAddTransaction = () => {
    // Validate form fields
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }

    if (!transactionDescription.trim()) {
      setFormError("Description is required");
      return;
    }

    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }

    if (!transactionAccount) {
      setFormError("Account is required");
      return;
    }

    if (!transactionCategory && transactionType !== 'reimbursement') { // Added condition for reimbursement
      setFormError("Category is required");
      return;
    }

    if (transactionType === 'reimbursement' && !transactionPerson.trim()) { // Added validation for person
      setFormError("Person's name is required for reimbursements");
      return;
    }


    // Validate that expense categories are used for expense transactions
    // and income categories are used for income transactions
    if (transactionType === 'expense' && !expenseCategories.includes(transactionCategory)) {
      setFormError("Please select an expense category for expense transactions");
      return;
    }

    if (transactionType === 'income' && !incomeCategories.includes(transactionCategory)) {
      setFormError("Please select an income category for income transactions");
      return;
    }

    // Create and add the transaction
    const newTransaction: ImportTransaction = {
      date: transactionDate,
      type: transactionType,
      description: transactionDescription,
      amount: parseFloat(transactionAmount),
      account: transactionAccount,
      category: transactionCategory,
      person: transactionPerson // Added person field to the transaction
    };

    if (editingIndex === -1) {
      addTransaction(newTransaction);
    } else {
      transactions[editingIndex] = newTransaction;
    }

    // Show success toast
    toast({
      title: "Transaction Added",
      description: "Your transaction has been successfully added.",
      duration: 3000,
    });

    // Close the modal and reset form
    setIsAddModalOpen(false);
    resetForm();
    setEditingIndex(-1);
  };

  // Update available category options based on transaction type
  const handleTypeChange = (type: string) => {
    setTransactionType(type);
    setTransactionCategory('');
    setTransactionPerson(''); // Clear person field on type change

    if (type === 'expense' && expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    } else if (type === 'income' && incomeCategories.length > 0) {
      setTransactionCategory(incomeCategories[0]);
    }
  };

  const handleAccountChange = (account: string) => {
    setTransactionAccount(account);
    // Auto-label as credit card expense if account is a credit card
    if (creditCards.map(card => card.name).includes(account)) {
      setTransactionType('expense');
      setTransactionCategory('Credit Card Expense');
    }
  };

  // Format amount for display
  const formatAmount = (amount: number, type: string) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  // Generate statement cycle options for the selected credit card
  const cycleOptions = useMemo(() => {
    if (!accountFilter) return [];

    // Find if the account is a credit card
    const selectedCard = creditCards.find(card => card.name === accountFilter);
    if (!selectedCard) return [];

    // Generate last 6 statement cycles
    const cycles = [];
    let cycleEndDate = new Date(selectedCard.nextStatementDate);
    let cycleStartDate = new Date(selectedCard.currentStatementDate);

    // Add current cycle
    cycles.push({
      label: `Current cycle (${new Date(cycleStartDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })} - ${new Date(cycleEndDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })})`,
      start: cycleStartDate.toISOString().split('T')[0],
      end: cycleEndDate.toISOString().split('T')[0]
    });

    // Add previous cycles
    for (let i = 0; i < 5; i++) {
      // Move to previous cycle
      cycleEndDate = new Date(cycleStartDate);
      cycleEndDate.setDate(cycleEndDate.getDate() - 1);

      // Calculate start of previous cycle
      cycleStartDate = new Date(cycleEndDate);
      const month = cycleStartDate.getMonth() - 1;
      const year = month < 0 ? cycleStartDate.getFullYear() - 1 : cycleStartDate.getFullYear();
      cycleStartDate = new Date(year, month < 0 ? 11 : month, selectedCard.statementDay);

      cycles.push({
        label: `${new Date(cycleStartDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })} - ${new Date(cycleEndDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}`,
        start: cycleStartDate.toISOString().split('T')[0],
        end: cycleEndDate.toISOString().split('T')[0]
      });
    }

    return cycles;
  }, [accountFilter, creditCards]);

  // State for limiting the number of displayed transactions
const [transactionsToShow, setTransactionsToShow] = useState<number>(5);

const filteredTransactions = transactions
    .filter((transaction) => {
      // Text filter
      if (!transaction.description.toLowerCase().includes(filterText.toLowerCase())) {
        return false;
      }

      // Account filter
      if (accountFilter && transaction.account !== accountFilter) {
        return false;
      }

      // Person filter
      if (personFilter && personFilter !== 'all' && transaction.person !== personFilter) {
        return false;
      }

      // Date range filter
      if (startDate) {
        const txDate = new Date(transaction.date);
        const filterStart = new Date(startDate);
        // Set to start of day
        filterStart.setHours(0, 0, 0, 0);
        if (txDate < filterStart) {
          return false;
        }
      }

      if (endDate) {
        const txDate = new Date(transaction.date);
        const filterEnd = new Date(endDate);
        // Set to end of day
        filterEnd.setHours(23, 59, 59, 999);
        if (txDate > filterEnd) {
          return false;
        }
      }

      // Cycle filter (only apply if it's a credit card and cycle is selected)
      if (cycleFilter && cycleFilter !== 'all' && accountFilter && creditCards.some(card => card.name === accountFilter)) {
        const selectedCycle = cycleOptions.find(cycle => cycle.label === cycleFilter);
        if (selectedCycle) {
          const txDate = new Date(transaction.date);
          const cycleStart = new Date(selectedCycle.start);
          const cycleEnd = new Date(selectedCycle.end);
          return txDate >= cycleStart && txDate < cycleEnd;
        }
      }

      return true;
    })
    .sort((a, b) => {
      if (sortField === 'date') {
        return sortOrder === 'asc' 
          ? new Date(a.date).getTime() - new Date(b.date).getTime()
          : new Date(b.date).getTime() - new Date(a.date).getTime()
      }
      if (sortField === 'amount') {
        return sortOrder === 'asc' ? a.amount - b.amount : b.amount - a.amount
      }
      return sortOrder === 'asc' 
        ? a.category.localeCompare(b.category)
        : b.category.localeCompare(a.category)
    });

// Create a limited list to display
const displayedTransactions = filteredTransactions.slice(0, transactionsToShow);
const hasMoreTransactions = filteredTransactions.length > transactionsToShow;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Clipboard className="h-6 w-6" /> Finance Tracker Pro
        </h1>
        <div className="flex gap-2">
          <Link href="/bulk-import">
            <Button variant="default" className="flex items-center gap-2">
              <FileUp className="h-4 w-4" /> Bulk Import
            </Button>
          </Link>
          <Link href="/transactions">
            <Button variant="default" className="flex items-center gap-2">
              View All Transactions
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" /> Quick Add Transaction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 items-center md:justify-between">
              <div>
                <p className="text-gray-500 mb-2">
                  Add individual transactions to track your expenses and income.
                </p>
              </div>
              <div>
                <Button 
                  variant="default" 
                  className="flex items-center gap-2"
                  onClick={handleOpenAddModal}
                >
                  <Plus className="h-4 w-4" />
                  Add Transaction
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
          <p className="text-sm text-gray-500">Showing the most recent transactions</p>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4 gap-3">
            <Input 
              type="text" 
              placeholder="Filter transactions..." 
              value={filterText} 
              onChange={(e) => setFilterText(e.target.value)}
              className="w-full md:w-auto"
            />
            <div className="flex flex-wrap gap-2 w-full md:w-auto">
              <div className="flex items-center gap-2">
                <Select 
                  value={periodFilter || "all"} 
                  onValueChange={(value) => {
                    // Set periodFilter
                    setPeriodFilter(value);

                    const now = new Date();
                    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

                    // Reset dates first
                    setStartDate(null);
                    setEndDate(null);

                    switch(value) {
                      case "thisMonth":
                        // First day of current month
                        setStartDate(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]);
                        // Last day of current month
                        setEndDate(new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0]);
                        break;
                      case "lastMonth":
                        // First day of last month
                        setStartDate(new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0]);
                        // Last day of last month
                        setEndDate(new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0]);
                        break;
                      case "thisYear":
                        // First day of current year
                        setStartDate(new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0]);
                        // Last day of current year
                        setEndDate(new Date(now.getFullYear(), 11, 31).toISOString().split('T')[0]);
                        break;
                      case "custom":
                        // Keep dates empty for custom selection
                        break;
                      default:
                        // All time - no date filtering
                        break;
                    }
                  }}
                >
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Date Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="thisMonth">This Month</SelectItem>
                    <SelectItem value="lastMonth">Last Month</SelectItem>
                    <SelectItem value="thisYear">This Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>

                {periodFilter === "custom" && (
                  <div className="flex items-center gap-2">
                    <div className="flex items-center">
                      <Input
                        type="date"
                        value={startDate || ""}
                        onChange={(e) => setStartDate(e.target.value || null)}
                        className="w-32 h-10"
                        placeholder="From"
                      />
                    </div>
                    <span>to</span>
                    <div className="flex items-center">
                      <Input
                        type="date"
                        value={endDate || ""}
                        onChange={(e) => setEndDate(e.target.value || null)}
                        className="w-32 h-10"
                        placeholder="To"
                      />
                    </div>
                  </div>
                )}
              </div>
              {accountFilter && creditCards.some(card => card.name === accountFilter) && (
                <Select value={cycleFilter || ""} onValueChange={setCycleFilter}>
                  <SelectTrigger className="w-full md:w-auto">
                    <SelectValue placeholder="Billing Cycle" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cycles</SelectItem>
                    {cycleOptions.map((cycle, index) => (
                      <SelectItem key={index} value={cycle.label}>
                        {cycle.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <Select value={sortField} onValueChange={setSortField}>
                <SelectTrigger className="w-full md:w-auto">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="amount">Amount</SelectItem>
                  <SelectItem value="category">Category</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortOrder} onValueChange={setSortOrder}>
                <SelectTrigger className="w-full md:w-auto">
                  <SelectValue placeholder="Order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">Ascending</SelectItem>
                  <SelectItem value="desc">Descending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Date</th>
                  <th className="text-left p-3">Type</th>
                  <th className="text-left p-3">Category/Person</th>
                  <th className="text-left p-3">Description</th>
                  <th className="text-left p-3">Account</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.length === 0 ? (
                  <tr className="border-b">
                    <td className="p-3 text-sm" colSpan={7}>
                      No transactions found. Add a transaction or import from Excel.
                    </td>
                  </tr>
                ) : (
                  displayedTransactions.map((transaction: Transaction) => (
                    <tr key={transaction.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">{new Date(transaction.date).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                      }).replace(/\//g, '-')}</td>
                      <td className="p-3 capitalize">{transaction.type}</td>
                      <td className="p-3">
                        {transaction.type === 'reimbursement' 
                          ? transaction.person
                          : transaction.category}
                      </td>
                      <td className="p-3 font-medium">{transaction.description}</td>
                      <td className="p-3">{transaction.account}</td>
                      <td className={`p-3 ${
                        transaction.type === 'transfer' || transaction.type === 'contra'
                          ? transaction.description.includes("Payment to")
                            ? 'text-red-600'
                            : 'text-green-600'
                          : transaction.type === 'income' 
                            ? 'text-green-600' 
                            : 'text-red-600'
                      }`}>
                        {formatAmount(Math.abs(transaction.amount), transaction.type)}
                      </td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setTransactionDate(transaction.date);
                              setTransactionType(transaction.type);
                              setTransactionDescription(transaction.description);
                              setTransactionAmount(transaction.amount.toString());
                              setTransactionAccount(transaction.account);
                              setTransactionCategory(transaction.category);
                              setTransactionPerson(transaction.person); // Set person field
                              setEditingIndex(transactions.indexOf(transaction));
                              setIsAddModalOpen(true);
                            }}
                            className="p-1 h-auto text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeTransaction(transaction.id)}
                            className="p-1 h-auto text-red-600 hover:text-red-800 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {hasMoreTransactions && (
              <div className="flex justify-center mt-4 mb-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransactionsToShow(prev => prev + 5)}
                  className="text-sm"
                >
                  Show 5 more
                </Button>
                <Button 
                  variant="link" 
                  size="sm"
                  onClick={() => window.location.href = '/transactions'}
                  className="text-sm"
                >
                  View all transactions
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Add Transaction Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Transaction</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Transaction Type</Label>
              <Select 
                value={transactionType}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select transaction type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                  <SelectItem value="reimbursement">Reimbursement</SelectItem> {/* Added Reimbursement option */}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter transaction description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                min="0.01"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select 
                value={transactionAccount}
                onValueChange={handleAccountChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select an account</div>
                  {bankAccountsData.length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Bank Accounts</div>
                      {bankAccountsData.map((account) => (
                        <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                      ))}
                    </>
                  )}
                  {creditCards.map(card => card.name).length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Credit Cards</div>
                      {creditCards.map(card => (
                        <SelectItem key={card.name} value={card.name}>{card.name}</SelectItem>
                      ))}
                    </>
                  )}
                  {bankAccountsData.length === 0 && creditCards.length === 0 && (
                    <div className="text-xs text-gray-500 px-2 py-1.5">
                      No accounts added yet. Add them from Bank Accounts or Credit Cards page.
                    </div>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">
                {transactionType === 'reimbursement' ? 'Person' : 'Category'}
              </Label>
              {transactionType === 'reimbursement' ? (
                <>
                  <Select 
                    value={transactionPerson}
                    onValueChange={setTransactionPerson}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select person" />
                    </SelectTrigger>
                    <SelectContent>
                      <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select a person</div>
                      {people.length > 0 ? (
                        people.map((person) => (
                          <SelectItem key={person} value={person || "unknown"}>{person}</SelectItem>
                        ))
                      ) : (
                        <div className="text-xs px-2 py-1.5 text-gray-500">
                          No people added yet. Add them in the Receivables page.
                        </div>
                      )}
                    </SelectContent>
                  </Select>
                  <div className="mt-1">
                    <Link to="/receivables" onClick={() => setIsAddModalOpen(false)} className="text-xs text-blue-600 hover:underline">
                      Manage people
                    </Link>
                  </div>
                </>
              ) : (
                <Select 
                  value={transactionCategory}
                  onValueChange={setTransactionCategory}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select a category</div>
                    {transactionType === 'expense' ? (
                      expenseCategories.map((category) => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))
                    ) : (
                      incomeCategories.map((category) => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddTransaction}>
              Add Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}