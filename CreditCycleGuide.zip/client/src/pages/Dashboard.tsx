import { useEffect, useState } from "react";
import { Link } from "wouter";
import { 
  ArrowDownToLine, 
  ArrowUpRight, 
  BarChart3, 
  CreditCard, 
  DollarSign, 
  LineChart, 
  Plus, 
  Wallet,
  PiggyBank,
  TrendingDown,
  TrendingUp,
  Calendar,
  Building,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useFinanceStore, Transaction, ImportTransaction } from "@/lib/transactionStore";
import { formatCurrency } from "@/lib/formatters";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import CategoryIconSelector from "@/components/CategoryIconSelector";
import { getDefaultCategoryIcon, renderCategoryIcon } from "@/lib/categoryIcons";

export default function Dashboard() {
  const { 
    transactions, 
    addTransaction,
    bankAccountsData, 
    creditCards,
    expenseCategories, 
    incomeCategories,
    people
  } = useFinanceStore();
  const { toast } = useToast();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedCardForPayment, setSelectedCardForPayment] = useState<CreditCard | null>(null);
  const [paymentBankAccount, setPaymentBankAccount] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [transferSource, setTransferSource] = useState(""); 
  const [transferDestination, setTransferDestination] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferDate, setTransferDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<'expense' | 'income' | 'reimbursement'>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState('');
  const [selectedCategoryIcon, setSelectedCategoryIcon] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  // Prepare data for the dashboard
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [netBalance, setNetBalance] = useState(0);
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [topExpenseCategories, setTopExpenseCategories] = useState<{category: string, amount: number}[]>([]);
  const [bankBalance, setBankBalance] = useState(0);
  const [creditCardDebt, setCreditCardDebt] = useState(0);

  // Calculate statement balance (transactions before statement date)
  const calculateStatementBalance = (card: any) => {
    const statementDate = new Date(card.currentStatementDate);

    // Get all transactions on or before the statement date
    const allTransactionsBeforeStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        // Include transactions on the statement date (same day)
        return txDate <= statementDate;
      });

    // Calculate the raw statement balance, accounting for transaction types
    const rawStatementBalance = allTransactionsBeforeStatement.reduce((sum, tx) => {
      // Income transactions should reduce the balance (negative amount for credit card)
      if (tx.type === 'income') {
        return sum - tx.amount; // Subtract income amounts (credit)
      } 
      // Expense transactions increase the balance (positive amount for credit card)
      else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
        return sum + tx.amount;
      }
      // Contra entries (payments) should be handled as is
      else {
        return sum + tx.amount;
      }
    }, 0);

    // Find payments made after statement date that should reduce the statement balance
    // Only include payments explicitly marked for statement balance
    const paymentsAfterStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        return txDate >= statementDate && 
               t.type === "contra" && 
               t.amount < 0 && 
               t.metadata?.paymentFor === "statement_balance";
      });

    // Calculate how much payment to apply
    let appliedPayments = 0;

    // Sort payments by date (oldest first)
    const sortedPayments = [...paymentsAfterStatement].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // If statement balance is already negative (overpaid from previous cycle),
    // return the negative balance immediately
    if (rawStatementBalance < 0) {
      return rawStatementBalance;
    }

    // If there's no positive statement balance, return 0
    if (rawStatementBalance <= 0) {
      return 0;
    }

    // Process payments
    let remainingStatementBalance = rawStatementBalance;

    for (const payment of sortedPayments) {
      const paymentAmount = Math.abs(payment.amount);

      // If statement balance is already paid off, no need to apply more payments
      if (remainingStatementBalance <= 0) break;

      // Apply payment to statement balance (limited by remaining balance)
      const amountToApply = Math.min(paymentAmount, remainingStatementBalance);
      appliedPayments += amountToApply;
      remainingStatementBalance -= amountToApply;
    }

    return rawStatementBalance - appliedPayments;
  };

  useEffect(() => {
    // Calculate financial summaries
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    // Filter transactions for current month
    const thisMonthTransactions = transactions.filter(t => {
      const date = new Date(t.date);
      return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
    });

    // Calculate income and expenses
    let income = 0;
    let expense = 0;

    thisMonthTransactions.forEach(t => {
      if (t.type === 'income') {
        income += t.amount;
      } else if (t.type === 'expense') {
        expense += t.amount;
      }
    });

    setTotalIncome(income);
    setTotalExpenses(expense);
    setNetBalance(income - expense);

    // Get recent transactions (last 5)
    setRecentTransactions(
      [...transactions]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 5)
    );

    // Calculate top expense categories
    const categoryExpenses = new Map<string, number>();
    transactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        categoryExpenses.set(t.category, (categoryExpenses.get(t.category) || 0) + t.amount);
      });

    // Convert to array and sort
    const sortedCategories = Array.from(categoryExpenses.entries())
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);

    setTopExpenseCategories(sortedCategories);

    // Calculate bank balance
    const bankAccountNames = bankAccountsData.map(a => a.name);
    const bankTransactions = transactions.filter(t => bankAccountNames.includes(t.account));
    let balance = 0;

    bankTransactions.forEach(t => {
      if (t.type === 'income' || t.type === 'payment') {
        balance += t.amount;
      } else if (t.type === 'expense') {
        balance -= t.amount;
      } else if (t.type === 'contra') {
        balance += t.amount; // Handle contra transactions correctly
      }
    });

    console.log('Dashboard bank balance calculation:', balance);
    setBankBalance(balance);

    // Calculate credit card debt
    const creditCardNames = creditCards.map(c => c.name);
    let totalDebt = 0;

    creditCards.forEach(card => {
      // Calculate total outstanding (statement balance + current cycle)
      const statementBalance = calculateStatementBalance(card);

      // Calculate current cycle balance from transactions
      const cycleTransactions = transactions
        .filter(t => t.account === card.name)
        .filter(t => {
          const txDate = new Date(t.date);
          const cycleStart = new Date(card.currentStatementDate);
          // Only include transactions after the statement date
          return txDate > cycleStart;
        });

      const cycleTotal = cycleTransactions.reduce((sum, tx) => {
        // Income transactions should reduce the balance (negative amount for credit card)
        if (tx.type === 'income') {
          return sum - tx.amount; // Subtract income amounts (credit)
        } 
        // Expense transactions increase the balance (positive amount for credit card)
        else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
          return sum + tx.amount;
        }
        // Contra entries (payments) should be handled as is
        else {
          return sum + tx.amount;
        }
      }, 0);

      totalDebt += statementBalance + cycleTotal;
    });

    setCreditCardDebt(totalDebt);
  }, [transactions, bankAccountsData, creditCards]);

  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('expense');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setTransactionPerson('');
    setSelectedCategoryIcon('');
    setFormError(null);
  };

  // Reset transfer form
  const resetTransferForm = () => {
    setTransferAmount("");
    setTransferSource("");
    setTransferDestination("");
    setTransferDate(new Date().toISOString().split('T')[0]);
  };

  // Reset payment form
  const resetPaymentForm = () => {
    setPaymentBankAccount("");
    setPaymentAmount("");
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setSelectedCardForPayment(null);
  };

  // Handle transfer between accounts
  const handleTransfer = () => {
    if (!transferSource || !transferDestination || !transferAmount || !transferDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        duration: 3000,
      });
      return;
    }

    const amount = parseFloat(transferAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than zero.",
        duration: 3000,
      });
      return;
    }

    // Add outgoing transaction from source account
    addTransaction({
      date: transferDate,
      type: "expense",
      description: `Transfer to ${transferDestination}`,
      amount: amount,
      account: transferSource,
      category: "Transfer"
    });

    // Add incoming transaction to destination account
    addTransaction({
      date: transferDate,
      type: "income",
      description: `Transfer from ${transferSource}`,
      amount: amount,
      account: transferDestination,
      category: "Transfer"
    });

    toast({
      title: "Transfer Complete",
      description: `Successfully transferred ${formatCurrency(amount)} between accounts.`,
      duration: 3000,
    });

    resetTransferForm();
    setIsTransferDialogOpen(false);
  };

  // Note: Using the calculateStatementBalance function defined above

  // Handle credit card payment
  const handlePayment = () => {
    if (!selectedCardForPayment || !paymentBankAccount || !paymentAmount || !paymentDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        duration: 3000,
      });
      return;
    }

    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than zero.",
        duration: 3000,
      });
      return;
    }

    // Get the current statement balance
    const statementBalance = calculateStatementBalance(selectedCardForPayment);

    // Add contra transaction pair for credit card payment
    // For bank account: negative amount (money goes out)
    addTransaction({
      date: paymentDate,
      type: "contra",
      description: `Payment to ${selectedCardForPayment.name}`,
      amount: -amount, // Negative for bank account (money going out)
      account: paymentBankAccount,
      category: "Credit Card Payment"
    });

    // Determine payment application
    if (amount <= statementBalance || statementBalance <= 0) {
      // Apply entire payment
      addTransaction({
        date: paymentDate, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount}`,
        amount: -amount, // Negative for credit card (reduces outstanding debt)
        account: selectedCardForPayment.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: statementBalance > 0 ? "statement_balance" : "current_cycle", 
          statementDate: selectedCardForPayment.currentStatementDate,
          paymentAmount: amount
        }
      });
    } else {
      // Split payment: part for statement balance, part for current cycle
      // First transaction - pay off statement balance
      addTransaction({
        date: paymentDate, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Statement)`,
        amount: -statementBalance,
        account: selectedCardForPayment.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "statement_balance",
          statementDate: selectedCardForPayment.currentStatementDate,
          paymentAmount: statementBalance
        }
      });

      // Second transaction - excess payment for current cycle
      const excessAmount = amount - statementBalance;
      addTransaction({
        date: paymentDate, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Current Cycle)`,
        amount: -excessAmount,
        account: selectedCardForPayment.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "current_cycle",
          statementDate: selectedCardForPayment.currentStatementDate,
          paymentAmount: excessAmount
        }
      });
    }

    toast({
      title: "Payment Complete",
      description: `Successfully paid ${formatCurrency(amount)} to ${selectedCardForPayment.name}.`,
      duration: 3000,
    });

    resetPaymentForm();
    setIsPaymentDialogOpen(false);
  };

  // Handle opening the add transaction modal
  const handleOpenAddModal = () => {
    resetForm();

    // Set default values
    if (bankAccountsData.length > 0) {
      setTransactionAccount(bankAccountsData[0].name);
    }
    if (expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    }

    setIsAddModalOpen(true);
  };

  // Handle creating a new transaction
  const handleAddTransaction = () => {
    // Validate form fields
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }

    if (!transactionDescription.trim()) {
      setFormError("Description is required");
      return;
    }

    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }

    if (!transactionAccount) {
      setFormError("Account is required");
      return;
    }

    if (!transactionCategory && transactionType !== 'reimbursement') {
      setFormError("Category is required");
      return;
    }

    if (transactionType === 'reimbursement' && !transactionPerson.trim()) {
      setFormError("Person's name is required for reimbursements");
      return;
    }

    // Validate category type
    if (transactionType === 'expense' && !expenseCategories.includes(transactionCategory)) {
      setFormError("Please select an expense category for expense transactions");
      return;
    }

    if (transactionType === 'income' && !incomeCategories.includes(transactionCategory)) {
      setFormError("Please select an income category for income transactions");
      return;
    }

    // Create and add the transaction
    const newTransaction: ImportTransaction = {
      date: transactionDate,
      type: transactionType,
      description: transactionDescription,
      amount: parseFloat(transactionAmount),
      account: transactionAccount,
      category: transactionCategory,
      categoryIcon: selectedCategoryIcon || getDefaultCategoryIcon(transactionType),
      person: transactionPerson
    };

    addTransaction(newTransaction);

    // Show success toast
    toast({
      title: "Transaction Added",
      description: "Your transaction has been successfully added.",
      duration: 3000,
    });

    // Close the modal and reset form
    setIsAddModalOpen(false);
    resetForm();
  };

  // Update available category options based on transaction type
  const handleTypeChange = (type: string) => {
    // Validate type is one of the allowed values
    const validType = (type === 'expense' || type === 'income' || type === 'reimbursement') 
      ? type as 'expense' | 'income' | 'reimbursement'
      : 'expense';

    setTransactionType(validType);
    setTransactionCategory('');
    setTransactionPerson('');
    setSelectedCategoryIcon('');

    if (validType === 'expense' && expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    } else if (validType === 'income' && incomeCategories.length > 0) {
      setTransactionCategory(incomeCategories[0]);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Hero section */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-2">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text">
              Financial Dashboard
            </h1>
            <p className="text-gray-600 max-w-xl">
              Track your finances, set goals, and make informed decisions with your personal finance tracker.
            </p>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={handleOpenAddModal}
              className="btn-gradient"
            >
              <Plus className="mr-2 h-4 w-4" /> Add Transaction
            </Button>
            <Link href="/transactions">
              <Button variant="outline">
                View All Transactions
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-6">
        <Card 
          className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200"
          onClick={() => {
            setTransactionType('expense');
            handleOpenAddModal();
          }}
        >
          <CardContent className="p-4">
            <div className="flex flex-col items-center text-center">
              <div className="h-10 w-10 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center mb-2">
                <TrendingDown className="h-5 w-5 text-blue-600" />
              </div>
              <CardTitle className="text-sm">Add Expense</CardTitle>
              <CardDescription className="text-xs">Record a new expense transaction</CardDescription>
            </div>
          </CardContent>
        </Card>

        <Card 
          className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-green-50 to-green-100 border-green-200"
          onClick={() => {
            resetForm();
            setTransactionType('income');
            // Set default income category if available
            if (incomeCategories.length > 0) {
              setTransactionCategory(incomeCategories[0]);
            }
            // Set default account if available
            if (bankAccountsData.length > 0) {
              setTransactionAccount(bankAccountsData[0].name);
            }
            setIsAddModalOpen(true);
          }}
        >
          <CardContent className="p-4">
            <div className="flex flex-col items-center text-center">
              <div className="h-10 w-10 rounded-full bg-green-100 border border-green-200 flex items-center justify-center mb-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <CardTitle className="text-sm">Add Income</CardTitle>
              <CardDescription className="text-xs">Record a new income transaction</CardDescription>
            </div>
          </CardContent>
        </Card>

        <Card 
          className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200"
          onClick={() => {
            resetForm();
            setTransactionType('reimbursement');
            // Set default account if available
            if (bankAccountsData.length > 0) {
              setTransactionAccount(bankAccountsData[0].name);
            }
            // Set default person if available
            if (people.length > 0) {
              setTransactionPerson(people[0]);
            }
            setIsAddModalOpen(true);
          }}
        >
          <CardContent className="p-4">
            <div className="flex flex-col items-center text-center">
              <div className="h-10 w-10 rounded-full bg-purple-100 border border-purple-200 flex items-center justify-center mb-2">
                <Users className="h-5 w-5 text-purple-600" />
              </div>
              <CardTitle className="text-sm">Reimbursement</CardTitle>
              <CardDescription className="text-xs">Record money owed to/by others</CardDescription>
            </div>
          </CardContent>
        </Card>

        <Card 
          className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-red-50 to-red-100 border-red-200"
          onClick={() => {
            // Open CC payment dialog (similar to the one in CreditCards.tsx)
            if (creditCards.length === 0) {
              toast({
                title: "No Credit Cards",
                description: "Please add a credit card first.",
                duration: 3000,
              });
              return;
            }
            setSelectedCardForPayment(creditCards[0]);
            setIsPaymentDialogOpen(true);
          }}
        >
          <CardContent className="p-4">
            <div className="flex flex-col items-center text-center">
              <div className="h-10 w-10 rounded-full bg-red-100 border border-red-200 flex items-center justify-center mb-2">
                <CreditCard className="h-5 w-5 text-red-600" />
              </div>
              <CardTitle className="text-sm">CC Payment</CardTitle>
              <CardDescription className="text-xs">Make a credit card payment</CardDescription>
            </div>
          </CardContent>
        </Card>

        <Card 
          className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200"
          onClick={() => {
            // Open transfer funds dialog (similar to the one in BankAccounts.tsx)
            if (bankAccountsData.length < 2) {
              toast({
                title: "Not Enough Accounts",
                description: "You need at least two bank accounts to make a transfer.",
                duration: 3000,
              });
              return;
            }
            setIsTransferDialogOpen(true);
          }}
        >
          <CardContent className="p-4">
            <div className="flex flex-col items-center text-center">
              <div className="h-10 w-10 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center mb-2">
                <ArrowDownToLine className="h-5 w-5 text-blue-600" />
              </div>
              <CardTitle className="text-sm">Self Transfer</CardTitle>
              <CardDescription className="text-xs">Transfer between your accounts</CardDescription>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card hover:shadow-lg transition-all duration-300 cursor-pointer bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <Link href="/analytics">
            <CardContent className="p-4">
              <div className="flex flex-col items-center text-center">
                <div className="h-10 w-10 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center mb-2">
                  <BarChart3 className="h-5 w-5 text-amber-600" />
                </div>
                <CardTitle className="text-sm">View Analytics</CardTitle>
                <CardDescription className="text-xs">See detailed financial reports</CardDescription>
              </div>
            </CardContent>
          </Link>
        </Card>
      </div>

      {/* Financial Data Visualization */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs defaultValue="accounts" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="recent">Recent Transactions</TabsTrigger>
              <TabsTrigger value="accounts">Account Balances</TabsTrigger>
              <TabsTrigger value="spending">Spending Categories</TabsTrigger>
            </TabsList>

            <TabsContent value="recent" className="bg-white rounded-xl shadow-md p-5">
              <h3 className="font-bold text-lg mb-4">Recent Transactions</h3>

              {recentTransactions.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-2">Date</th>
                        <th className="text-left py-2 px-2">Description</th>
                        <th className="text-left py-2 px-2">Category</th>
                        <th className="text-right py-2 px-2">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentTransactions.map((transaction) => {
                        const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                          c.category === (transaction.category || transaction.person)
                        );
                        const iconId = iconInfo?.iconId || 
                                        (transaction.type === 'expense' ? 
                                        getDefaultCategoryIcon('expense') : 
                                        getDefaultCategoryIcon('income'));
                        return (
                        <tr key={transaction.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-2 text-gray-600">
                            {formatDate(transaction.date)}
                          </td>
                          <td className="py-3 px-2">{transaction.description}</td>
                          <td className="py-3 px-2">
                            {renderCategoryIcon(iconId, 16, "", true, transaction.category || transaction.person)}
                          </td>
                          <td className={cn(
                            "py-3 px-2 text-right font-medium",
                            transaction.type === 'income' || 
                            (transaction.type === 'contra' && transaction.description.toLowerCase().includes("payment received"))
                            ? "text-green-600" : "text-red-600"
                          )}>
                            {transaction.type === 'income' || 
                             (transaction.type === 'contra' && transaction.description.toLowerCase().includes("payment received"))
                             ? '+' : '-'}
                            {formatCurrency(Math.abs(transaction.amount))}
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No transactions found. Add your first transaction to get started!
                </div>
              )}

              <div className="mt-4 text-center">
                <Link href="/transactions">
                  <Button variant="ghost" className="text-royal">
                    View All Transactions <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="accounts" className="bg-white rounded-xl shadow-md p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-none shadow-none">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <Building className="mr-2 h-5 w-5 text-royal" />
                      <span>Bank Accounts</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold savings-gradient text-white px-4 py-2 rounded-lg inline-block">
                      {formatCurrency(bankBalance)}
                    </div>
                    <div className="mt-4">
                      {bankAccountsData.map((account) => {
                        // Calculate individual bank account balance
                        const accountTransactions = transactions.filter(t => t.account === account.name);
                        let accountBalance = 0;
                        
                        // Using the same calculation method as in BankAccounts.tsx
                        accountTransactions.forEach(t => {
                          if (t.type === "income" || t.type === "payment") {
                            accountBalance += t.amount;
                          } else if (t.type === "expense") {
                            accountBalance -= t.amount; // Subtract expense amount
                          } else if (t.type === "contra") {
                            accountBalance += t.amount; // Always add contra transactions
                          }
                        });
                        
                        console.log(`Dashboard: ${account.name} balance:`, accountBalance);

                        return (
                          <div key={account.id} className="flex justify-between items-center py-2 border-b">
                            <div className="font-medium">{account.name}</div>
                            <div>{formatCurrency(accountBalance)}</div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-4">
                      <Link href="/bank-accounts">
                        <Button variant="outline" size="sm" className="w-full">
                          Manage Bank Accounts
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-none">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <CreditCard className="mr-2 h-5 w-5 text-coral" />
                      <span>Credit Cards</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-3xl font-bold px-4 py-2 rounded-lg inline-block ${
                      creditCardDebt > 0 
                        ? "expense-gradient text-white" 
                        : creditCardDebt < 0 
                          ? "bg-green-500 text-white" 
                          : "bg-gray-100 text-gray-700"
                    }`}>
                      {formatCurrency(creditCardDebt)}
                      {creditCardDebt < 0 && <span className="text-sm ml-1">(credit)</span>}
                    </div>
                    <div className="mt-4">
                      {creditCards.map((card) => {
                        // Calculate statement balance
                        const statementBalance = calculateStatementBalance(card);

                        // Calculate current cycle balance from transactions
                        const cycleTransactions = transactions
                          .filter(t => t.account === card.name)
                          .filter(t => {
                            const txDate = new Date(t.date);
                            const cycleStart = new Date(card.currentStatementDate);
                            // Only include transactions after the statement date (not statement balance payments)
                            return txDate > cycleStart && 
                                  !(t.type === "contra" && t.amount < 0 && t.metadata?.paymentFor === "statement_balance");
                          });

                        // Calculate raw current cycle total
                        const rawCycleTotal = cycleTransactions.reduce((sum, tx) => {
                          // Income transactions should reduce the balance (negative amount for credit card)
                          if (tx.type === 'income') {
                            return sum - tx.amount; // Subtract income amounts (credit)
                          } 
                          // Expense transactions increase the balance (positive amount for credit card)
                          else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
                            return sum + tx.amount;
                          }
                          // Contra entries (payments) should be handled as is
                          else {
                            return sum + tx.amount;
                          }
                        }, 0);
                        
                        // Find excess payments from statement balance payments
                        const statementDate = new Date(card.currentStatementDate);
                        const allPaymentsAfterStatement = transactions
                          .filter(t => t.account === card.name)
                          .filter(t => {
                            const txDate = new Date(t.date);
                            return txDate > statementDate && 
                                  t.type === "contra" && 
                                  t.amount < 0;
                          });
                        
                        // First handle statement balance payments and calculate excess
                        const statementPayments = allPaymentsAfterStatement.filter(t => 
                          t.metadata?.paymentFor === "statement_balance"
                        );
                        
                        // Calculate statement balance to determine excess payment amounts
                        const rawStatementBalance = transactions
                          .filter(t => t.account === card.name)
                          .filter(t => new Date(t.date) <= statementDate)
                          .reduce((sum, tx) => {
                            // Income transactions should reduce the balance (negative amount for credit card)
                            if (tx.type === 'income') {
                              return sum - tx.amount; // Subtract income amounts (credit)
                            } 
                            // Expense transactions increase the balance (positive amount for credit card)
                            else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
                              return sum + tx.amount;
                            }
                            // Contra entries (payments) should be handled as is
                            else {
                              return sum + tx.amount;
                            }
                          }, 0);
                          
                        // Process statement payments and calculate excess
                        let remainingStatementBalance = Math.max(0, rawStatementBalance);
                        let excessPaymentTotal = 0;
                        
                        for (const payment of statementPayments) {
                          const paymentAmount = Math.abs(payment.amount);
                          
                          // If statement already paid off, all goes to current cycle
                          if (remainingStatementBalance <= 0) {
                            excessPaymentTotal += paymentAmount;
                            continue;
                          }
                          
                          // Calculate how much of this payment is for statement vs excess
                          const amountForStatement = Math.min(paymentAmount, remainingStatementBalance);
                          const excess = paymentAmount - amountForStatement;
                          
                          // Apply to statement balance first
                          remainingStatementBalance -= amountForStatement;
                          
                          // Any excess goes to current cycle
                          if (excess > 0) {
                            excessPaymentTotal += excess;
                          }
                        }
                        
                        // Next, add direct current cycle payments
                        const currentCyclePayments = allPaymentsAfterStatement.filter(t => 
                          t.metadata?.paymentFor === "current_cycle"
                        );
                        
                        for (const payment of currentCyclePayments) {
                          excessPaymentTotal += Math.abs(payment.amount);
                        }
                        
                        // Final cycle total is raw charges minus excess payments
                        const cycleTotal = rawCycleTotal - excessPaymentTotal;
                        const totalOutstanding = statementBalance + cycleTotal;

                        return (
                          <div key={card.id} className="flex justify-between items-center py-2 border-b">
                            <div className="font-medium">{card.name}</div>
                            <div className={`${
                              totalOutstanding > 0 
                                ? "text-red-600" 
                                : totalOutstanding < 0
                                  ? "text-green-600"
                                  : ""
                            }`}>
                              {formatCurrency(totalOutstanding)}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-4">
                      <Link href="/credit-cards">
                        <Button variant="outline" size="sm" className="w-full">
                          Manage Credit Cards
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="spending" className="bg-white rounded-xl shadow-md p-5">
              <h3 className="text-xl font-bold flex items-center gap-2 mb-6">
                <BarChart3 className="h-5 w-5 text-primary" /> 
                <span className="primary-gradient-text">Top Spending Categories</span>
              </h3>

              {topExpenseCategories.length > 0 ? (
                <div className="space-y-5">
                  {topExpenseCategories.map((category, index) => {
                    // Generate a color based on index for progress bars
                    const COLORS = [
                      "#4f46e5", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", 
                      "#8b5cf6", "#06b6d4", "#84cc16", "#f97316", "#ec4899"
                    ];
                    const color = COLORS[index % COLORS.length];
                    const percentage = ((category.amount / totalExpenses) * 100);
                    
                    return (
                      <div key={index} className="card-hover p-3 rounded-lg border border-gray-100">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2.5">
                            <div className="h-7 w-7 rounded-full flex items-center justify-center text-white font-semibold text-sm"
                                 style={{ background: `linear-gradient(to bottom right, ${color}, ${color}cc)` }}>
                              {index + 1}
                            </div>
                            <div className="flex items-center gap-2">
                              {(() => {
                                // Get proper icon ID for this category
                                const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                                  c.category === category.category && c.type === 'expense'
                                );
                                const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');
                                return renderCategoryIcon(iconId, 18, "", true, category.category);
                              })()}
                            </div>
                          </div>
                          <div className="font-semibold">
                            {formatCurrency(category.amount)}
                            <Badge variant="outline" className="ml-2 bg-gray-50 text-xs">
                              {percentage.toFixed(1)}%
                            </Badge>
                          </div>
                        </div>
                        <div className="h-2.5 w-full bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full rounded-full" 
                            style={{ 
                              width: `${percentage}%`, 
                              background: `linear-gradient(to right, ${color}aa, ${color})`,
                            }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-10 rounded-lg border border-dashed border-gray-200 bg-gray-50">
                  <BarChart3 className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <h4 className="text-base font-medium text-gray-700">No Expense Data Yet</h4>
                  <p className="text-sm text-gray-500 mt-1 mb-4">Start tracking your expenses to see analytics</p>
                  <Button onClick={handleOpenAddModal} variant="outline" size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add First Expense
                  </Button>
                </div>
              )}

              {topExpenseCategories.length > 0 && (
                <div className="mt-6 text-center">
                  <Link href="/analytics">
                    <Button className="bg-gradient-to-r from-royal to-violet hover:opacity-90 text-white">
                      View Detailed Analytics <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <Card className="h-full overflow-hidden">
            <CardHeader className="pb-0 pt-3 px-3">
              <CardTitle className="flex items-center text-sm">
                <Calendar className="mr-1.5 h-4 w-4 text-royal" />
                <span>Financial Calendar</span>
              </CardTitle>
              <CardDescription className="text-xs">
                Upcoming payments and due dates
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-2 px-2">
              {creditCards.length > 0 ? (
                <div className="space-y-2">
                  {creditCards
                    .filter(card => {
                      // Only display cards with actual outstanding statement balance
                      const statementBalance = calculateStatementBalance ? calculateStatementBalance(card) : card.statementBalance;
                      return statementBalance > 0;
                    })
                    // Sort by days until due (ascending order)
                    .sort((a, b) => {
                      const dueDateA = new Date(a.dueDate);
                      const dueDateB = new Date(b.dueDate);
                      const today = new Date();
                      const daysUntilDueA = Math.ceil((dueDateA.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                      const daysUntilDueB = Math.ceil((dueDateB.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                      return daysUntilDueA - daysUntilDueB;
                    })
                    .map(card => {
                      const dueDate = new Date(card.dueDate);
                      const today = new Date();
                      const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

                      // Format date as DD-MMM
                      const formattedDueDate = dueDate.toLocaleDateString('en-GB', { 
                        day: '2-digit', 
                        month: 'short'
                      });

                      // Get statement balance (either from function or direct property)
                      const statementBalance = calculateStatementBalance ? calculateStatementBalance(card) : card.statementBalance;

                      // Get payment status similar to CreditCards page
                      let paymentStatus = "pending";
                      if (daysUntilDue < 0) paymentStatus = "overdue";

                      // Calculate the fill percentage based on days until due
                      const calculateFillPercentage = () => {
                        if (paymentStatus === "overdue") {
                          return 100; // Full fill for overdue
                        }
                        
                        if (paymentStatus === "fully paid" || paymentStatus === "no due") {
                          return 0; // No fill for paid
                        }
                        
                        // For pending payments, calculate percentage based on days left
                        // We'll consider 30 days as the maximum window
                        const maxDaysToShow = 30;
                        return Math.max(0, Math.min(100, 100 - (daysUntilDue / maxDaysToShow * 100)));
                      };
                      
                      // Get color scheme based on due date/status
                      const getColorScheme = () => {
                        if (paymentStatus === "overdue") {
                          return {
                            border: "border-l-red-600",
                            background: "linear-gradient(to right, rgba(254, 202, 202, 0.95), rgba(220, 38, 38, 0.6))",
                            badge: "text-white bg-red-600"
                          };
                        }
                        
                        if (paymentStatus === "partially paid") {
                          return {
                            border: "border-l-blue-500",
                            background: "linear-gradient(to right, rgba(219, 234, 254, 0.8), rgba(59, 130, 246, 0.2))",
                            badge: "text-blue-800 bg-blue-100"
                          };
                        }
                        
                        if (paymentStatus === "fully paid" || paymentStatus === "no due") {
                          return {
                            border: "border-l-green-500",
                            background: "linear-gradient(to right, rgba(220, 252, 231, 0.8), rgba(34, 197, 94, 0.2))",
                            badge: "text-green-800 bg-green-100"
                          };
                        }
                        
                        // For pending payments, colors based on due date ranges
                        if (daysUntilDue > 14) {
                          // Pale yellow for cards due in more than 14 days
                          return {
                            border: "border-l-yellow-200",
                            background: "linear-gradient(to right, rgba(254, 252, 232, 0.7), rgba(254, 249, 195, 0.2))",
                            badge: "text-yellow-800 bg-yellow-100"
                          };
                        } else if (daysUntilDue > 7) {
                          // Yellow-amber for cards due in 8-14 days
                          return {
                            border: "border-l-yellow-400",
                            background: "linear-gradient(to right, rgba(254, 249, 195, 0.8), rgba(250, 204, 21, 0.2))",
                            badge: "text-yellow-800 bg-yellow-200"
                          };
                        } else if (daysUntilDue > 3) {
                          // Orange for cards due in 4-7 days
                          return {
                            border: "border-l-orange-400",
                            background: "linear-gradient(to right, rgba(254, 240, 138, 0.8), rgba(251, 146, 60, 0.3))",
                            badge: "text-orange-800 bg-orange-200"
                          };
                        } else {
                          // Glaring red for cards due in 3 days or less
                          return {
                            border: "border-l-red-500",
                            background: "linear-gradient(to right, rgba(254, 226, 226, 0.9), rgba(239, 68, 68, 0.5))",
                            badge: "text-white bg-red-500"
                          };
                        }
                      };
                      
                      const colorScheme = getColorScheme();
                      
                      // Get border style
                      const getBorderStyle = () => {
                        return colorScheme.border;
                      };

                      const getStatusColor = () => {
                        return colorScheme.badge;
                      };

                      const getStatusText = () => {
                        if (paymentStatus === "overdue") return "Overdue!";
                        if (daysUntilDue === 0) return "Due today!";
                        return `Due in ${daysUntilDue} days`;
                      };

                      return (
                        <div 
                          key={card.id} 
                          className={cn(
                            "relative p-3 rounded-xl border-l-4 shadow-sm",
                            getBorderStyle()
                          )}
                          style={{
                            // Setting border color based on color scheme
                            borderLeft: (() => {
                              if (colorScheme.border.includes("red")) {
                                return "4px solid rgb(220, 38, 38)"; // Red
                              } else if (colorScheme.border.includes("orange")) {
                                return "4px solid rgb(251, 146, 60)"; // Orange-400
                              } else if (colorScheme.border.includes("yellow-200")) {
                                return "4px solid rgb(254, 240, 138)"; // Pale yellow (yellow-200)
                              } else if (colorScheme.border.includes("yellow-400")) {
                                return "4px solid rgb(250, 204, 21)"; // Medium yellow (yellow-400)
                              } else if (colorScheme.border.includes("yellow")) {
                                return "4px solid rgb(234, 179, 8)"; // Yellow (yellow-500)
                              } else if (colorScheme.border.includes("amber")) {
                                return "4px solid rgb(217, 119, 6)"; // Amber-600
                              } else if (colorScheme.border.includes("lime")) {
                                return "4px solid rgb(132, 204, 22)"; // Lime
                              } else if (colorScheme.border.includes("green")) {
                                return "4px solid rgb(34, 197, 94)"; // Green
                              } else if (colorScheme.border.includes("blue")) {
                                return "4px solid rgb(59, 130, 246)"; // Blue
                              } else {
                                return "4px solid rgb(156, 163, 175)"; // Default gray
                              }
                            })(),
                            // Apply the background gradient based on color scheme
                            background: colorScheme.background
                          }}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium text-gray-900 text-sm">{card.name}</h4>
                              <p className="text-xs text-gray-600 mt-0.5">
                                Due: {formattedDueDate}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold text-gray-900 text-sm">
                                {formatCurrency(statementBalance)}
                              </div>
                              <div className={`text-xs font-normal inline-block px-2 py-0.5 rounded-full mt-0.5 ${getStatusColor()}`}>
                                {getStatusText()}
                              </div>
                            </div>
                          </div>
                          
                          {/* No separate progress bar anymore - using background gradient instead */}
                        </div>
                      );
                    })}

                  {creditCards.filter(card => {
                    const statementBalance = calculateStatementBalance ? calculateStatementBalance(card) : card.statementBalance;
                    return statementBalance > 0;
                  }).length === 0 && (
                    <div className="text-center py-3 text-gray-500 text-xs">
                      <p>No outstanding payments due.</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500 text-xs">
                  <p>No credit cards added yet.</p>
                  <Link href="/credit-cards">
                    <Button variant="outline" size="sm" className="mt-1.5 text-xs py-1 h-auto">
                      Add Credit Card
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Transaction Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="modal-content p-0 sm:max-w-[550px]">
          <div className="modal-header">
            <DialogTitle className="modal-title">Add New Transaction</DialogTitle>
          </div>

          <div className="p-6 grid gap-4">
            {formError && (
              <div className="bg-red-50 text-red-800 p-3 rounded-md text-sm">
                {formError}
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select
                  value={transactionType}
                  onValueChange={handleTypeChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">Expense</SelectItem>
                    <SelectItem value="income">Income</SelectItem>
                    <SelectItem value="reimbursement">Reimbursement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (₹)</Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select
                value={transactionAccount}
                onValueChange={(value) => setTransactionAccount(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData.map((account) => (
                    <SelectItem key={account.id} value={account.name}>
                      {account.name}
                    </SelectItem>
                  ))}
                  {creditCards.map((card) => (
                    <SelectItem key={card.id} value={card.name}>
                      {card.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">
                {transactionType === 'reimbursement' ? 'Person' : 'Category'}
              </Label>
              {transactionType === 'reimbursement' ? (
                <Select
                  value={transactionPerson}
                  onValueChange={(value) => setTransactionPerson(value)}
                >
                  <SelectTrigger id="quick-person">
                    <SelectValue placeholder="Select person" />
                  </SelectTrigger>
                  <SelectContent>
                    {people.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Select
                  value={transactionCategory}
                  onValueChange={(value) => setTransactionCategory(value)}
                >
                  <SelectTrigger id="quick-category">
                    <SelectValue placeholder={`Select ${transactionType === 'expense' ? 'expense' : 'income'} category`} />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionType === 'expense' ? (
                      expenseCategories.map((category) => {
                        // Get icon ID for this category
                        const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                          c.category === category && c.type === 'expense'
                        );
                        const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');

                        return (
                          <SelectItem key={category} value={category}>
                            <div className="flex items-center gap-2">
                              {renderCategoryIcon(iconId, 16)}
                              <span>{category}</span>
                            </div>
                          </SelectItem>
                        );
                      })
                    ) : (
                      incomeCategories.map((category) => {
                        // Get icon ID for this category
                        const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                          c.category === category && c.type === 'income'
                        );
                        const iconId = iconInfo?.iconId || getDefaultCategoryIcon('income');

                        return (
                          <SelectItem key={category} value={category}>
                            <div className="flex items-center gap-2">
                              {renderCategoryIcon(iconId, 16)}
                              <span>{category}</span>
                            </div>
                          </SelectItem>
                        );
                      })
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>

            {transactionType === 'reimbursement' && (
              <div className="space-y-2">
                <Label htmlFor="person">Person</Label>
                <Select
                  value={transactionPerson}
                  onValueChange={(value) => setTransactionPerson(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select person" />
                  </SelectTrigger>
                  <SelectContent>
                    {people.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="modal-footer">
            <Button 
              variant="outline" 
              onClick={() => setIsAddModalOpen(false)}
              className="modal-button-secondary"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAddTransaction}
              className="modal-button-primary"
            >
              Add Transaction
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Credit Card Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Make Credit Card Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedCardForPayment && (
              <>
                <div className="space-y-2">
                  <Label>Card</Label>
                  <Select 
                    value={selectedCardForPayment.id} 
                    onValueChange={(value) => {
                      const card = creditCards.find(c => c.id === value);
                      if (card) setSelectedCardForPayment(card);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue>{selectedCardForPayment.name}</SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {creditCards.map((card) => (
                        <SelectItem key={card.id} value={card.id}>{card.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Statement Balance</Label>
                  <p className="text-sm font-medium">{formatCurrency(calculateStatementBalance(selectedCardForPayment))}</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentBankAccount">Pay From Account</Label>
                  <Select
                    value={paymentBankAccount}
                    onValueChange={setPaymentBankAccount}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccountsData.length > 0 ? 
                        bankAccountsData.map((account) => (
                          <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                        )) : 
                        <div className="text-xs text-gray-500 px-2 py-1.5">
                          No bank accounts added yet
                        </div>
                      }
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Payment Amount</Label>
                  <Input
                    id="paymentAmount"
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    placeholder="Enter amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentDate">Payment Date</Label>
                  <Input
                    id="paymentDate"
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePayment} disabled={!selectedCardForPayment || !paymentBankAccount || !paymentAmount}>
              Submit Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Funds Dialog */}
      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Transfer Funds</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="transferSource">Paid From</Label>
              <Select value={transferSource} onValueChange={setTransferSource}>
                <SelectTrigger>
                  <SelectValue placeholder="Select account to pay from" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData.map((account) => (
                    <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferDestination">Received In</Label>
              <Select value={transferDestination} onValueChange={setTransferDestination}>
                <SelectTrigger>
                  <SelectValue placeholder="Select account to receive in" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData
                    .filter(account => account.name !== transferSource)
                    .map((account) => (
                      <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferAmount">Amount</Label>
              <Input
                id="transferAmount"
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferDate">Transfer Date</Label>
              <Input
                id="transferDate"
                type="date"
                value={transferDate}
                onChange={(e) => setTransferDate(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsTransferDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleTransfer} disabled={!transferSource || !transferDestination || !transferAmount}>
              Transfer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}