import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add ExcelJS and FileSaver dependencies
import "exceljs";
import "file-saver";

createRoot(document.getElementById("root")!).render(<App />);
