import { useState, useEffect } from "react";
import { useFinanceStore, Transaction } from "@/lib/transactionStore";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { v4 as uuidv4 } from "uuid";
import SplitTransactionModal from "./SplitTransactionModal";

import { 
  CategoryType, 
  categoryIcons, 
  getCategoryIconsByType as getIconsByType,
  renderCategoryIcon as renderIcon
} from "@/lib/categoryIcons";

export default function QuickAddTransaction() {
  const { transactions, addTransaction } = useFinanceStore();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  // Split transaction state
  const [splitAfterSave, setSplitAfterSave] = useState(false);
  const [isSplitModalOpen, setIsSplitModalOpen] = useState(false);
  const [newTransaction, setNewTransaction] = useState<Transaction | null>(null);

  // Transaction form state
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<string>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState('');

  // Reset form values
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('expense');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setTransactionPerson('');
    setSplitAfterSave(false);
  };

  // Handle closing the split modal
  const handleSplitModalClose = () => {
    setIsSplitModalOpen(false);
    setNewTransaction(null);
    resetForm();
  };

  // Save transaction
  const handleSave = () => {
    // Basic validation
    if (!transactionDescription || !transactionAmount || !transactionAccount || 
        (transactionType !== 'reimbursement' && !transactionCategory) ||
        (transactionType === 'reimbursement' && !transactionPerson)) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      // Create transaction object
      const transaction: Transaction = {
        id: uuidv4(),
        date: transactionDate,
        type: transactionType,
        description: transactionDescription,
        amount: parseFloat(transactionAmount),
        account: transactionAccount,
        category: transactionCategory,
        person: transactionPerson,
      };

      // Check if we need to split this transaction
      if (splitAfterSave) {
        // Set the new transaction for the split modal
        setNewTransaction(transaction);
        // Close this modal and open the split modal
        setIsOpen(false);
        setIsSplitModalOpen(true);
      } else {
        // Add to store directly
        addTransaction(transaction);

        // Success message
        toast({
          title: "Transaction added",
          description: `${transactionType.charAt(0).toUpperCase() + transactionType.slice(1)} of ${transactionAmount} added successfully`,
          variant: "default"
        });

        // Reset and close
        resetForm();
        setIsOpen(false);
      }
    } catch (error) {
      toast({
        title: "Error adding transaction",
        description: "Please check the transaction details and try again",
        variant: "destructive"
      });
    }
  };

  // Keyboard listener for quick add shortcut
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Listen for Alt+A keyboard combination
      if (e.altKey && e.key === 'a') {
        e.preventDefault();
        setIsOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, []);

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className="p-1 rounded-full bg-blue-100 text-blue-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 11a1 1 0 0 1 0 2h-4v4a1 1 0 0 1-2 0v-4H7a1 1 0 0 1 0-2h4V7a1 1 0 1 1 2 0v4h4Z"/><path d="M5 18v2"/><path d="M19 18v2"/><path d="M5 4v2"/><path d="M19 4v2"/><rect width="18" height="12" x="3" y="6" rx="2"/></svg>
              </span>
              Quick Add Transaction
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quick-date">Date</Label>
                <Input
                  id="quick-date"
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quick-type">Type</Label>
                <Select
                  value={transactionType}
                  onValueChange={(value) => {
                    setTransactionType(value);
                    setTransactionCategory('');
                    setTransactionPerson('');
                  }}
                >
                  <SelectTrigger id="quick-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">Expense</SelectItem>
                    <SelectItem value="income">Income</SelectItem>
                    <SelectItem value="reimbursement">Reimbursement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-description">Description</Label>
              <Input
                id="quick-description"
                placeholder="Enter description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-amount">Amount</Label>
              <Input
                id="quick-amount"
                type="number"
                min="0.01"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-account">Account</Label>
              <Select
                value={transactionAccount}
                onValueChange={(value) => setTransactionAccount(value)}
              >
                <SelectTrigger id="quick-account">
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from(new Set(transactions.map(t => t.account))).filter(Boolean).map(account => (
                    <SelectItem key={account} value={account}>{account}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-category">
                {transactionType === 'reimbursement' ? 'Person' : 'Category'}
              </Label>
              {transactionType === 'reimbursement' ? (
                <Input
                  id="quick-person"
                  placeholder="Enter person name"
                  value={transactionPerson}
                  onChange={(e) => setTransactionPerson(e.target.value)}
                />
              ) : (
                <Select
                  value={transactionCategory}
                  onValueChange={(value) => setTransactionCategory(value)}
                >
                  <SelectTrigger id="quick-category">
                    <SelectValue placeholder={`Select ${transactionType === 'expense' ? 'expense' : 'income'} category`} />
                  </SelectTrigger>
                  <SelectContent>
                    {(transactionType === 'expense' ? 
                        useFinanceStore.getState().expenseCategories : 
                        useFinanceStore.getState().incomeCategories
                      ).map((category) => {
                        // Get icon ID for this category
                        const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                          c.category === category && 
                          c.type === (transactionType === 'expense' ? 'expense' : 'income')
                        );
                        const iconId = iconInfo?.iconId || 
                          (transactionType === 'expense' ? 
                            getDefaultCategoryIcon('expense') : 
                            getDefaultCategoryIcon('income'));

                        return (
                          <SelectItem key={category} value={category}>
                            <div className="flex items-center gap-2">
                              {renderIcon(iconId, 16)}
                              <span>{category}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox 
                id="split-transaction" 
                checked={splitAfterSave}
                onCheckedChange={(checked) => setSplitAfterSave(checked === true)}
              />
              <Label 
                htmlFor="split-transaction" 
                className="cursor-pointer text-sm font-medium"
              >
                Split this transaction into multiple categories after saving
              </Label>
            </div>

            <div className="bg-blue-50 p-3 rounded-md text-sm text-blue-700 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
              <span>Press <kbd className="px-2 py-0.5 rounded bg-white border shadow-sm mx-1 text-xs font-mono">Alt + A</kbd> anywhere in the app to open this quick add form</span>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              resetForm();
              setIsOpen(false);
            }}>
              Cancel
            </Button>
            <Button type="submit" onClick={handleSave}>
              Save Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Split Transaction Modal */}
      <SplitTransactionModal
        isOpen={isSplitModalOpen}
        onClose={handleSplitModalClose}
        transaction={newTransaction}
      />
    </>
  );
}