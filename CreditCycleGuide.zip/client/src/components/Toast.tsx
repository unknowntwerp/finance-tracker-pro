
import { useToast } from "@/hooks/use-toast"
import { useEffect } from "react"

type ToastProps = {
  message: string
  type?: "success" | "error" | "info"
  duration?: number
}

export function Toast({ message, type = "info", duration = 3000 }: ToastProps) {
  const { toast } = useToast()

  useEffect(() => {
    if (message) {
      toast({
        description: message,
        variant: type === "error" ? "destructive" : "default",
        className: type === "success" ? "bg-green-500 text-white" : undefined,
        duration: duration,
      })
    }
  }, [message, type, duration, toast])

  return null
}
