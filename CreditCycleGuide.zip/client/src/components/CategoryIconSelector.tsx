import React, { useState, useEffect } from 'react';
import { 
  categoryIcons, 
  getCategoryIconsByType, 
  CategoryType, 
  renderCategoryIcon, 
  CategoryIcon
} from '@/lib/categoryIcons';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Search } from 'lucide-react';

interface CategoryIconSelectorProps {
  selectedIcon: string;
  onSelectIcon: (iconId: string) => void;
  type?: 'expense' | 'income' | 'both';
}

export default function CategoryIconSelector({
  selectedIcon,
  onSelectIcon,
  type = 'expense'
}: CategoryIconSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredIcons, setFilteredIcons] = useState<CategoryIcon[]>([]);
  
  // Set category type based on transaction type
  const categoryType = type === 'expense' 
    ? CategoryType.EXPENSE 
    : type === 'income' 
      ? CategoryType.INCOME 
      : CategoryType.BOTH;
  
  useEffect(() => {
    const icons = getCategoryIconsByType(categoryType);
    
    if (searchTerm.trim() === '') {
      setFilteredIcons(icons);
    } else {
      setFilteredIcons(
        icons.filter(icon => 
          icon.name.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }
  }, [searchTerm, categoryType]);
  
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
        <Input
          placeholder="Search icons..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-8"
        />
      </div>
      
      <ScrollArea className="h-56 rounded-md border">
        <div className="category-icon-grid">
          {filteredIcons.map((icon) => (
            <div
              key={icon.id}
              className={cn(
                "category-icon-item",
                selectedIcon === icon.id && "selected"
              )}
              onClick={() => onSelectIcon(icon.id)}
              title={icon.name}
            >
              {renderCategoryIcon(icon.id, 24)}
              <span className="mt-1 text-xs text-center truncate w-full">
                {icon.name}
              </span>
            </div>
          ))}
          
          {filteredIcons.length === 0 && (
            <div className="col-span-6 py-8 text-center text-gray-500">
              No icons found matching "{searchTerm}"
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}