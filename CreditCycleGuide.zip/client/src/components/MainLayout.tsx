import { Link, useLocation } from "wouter";
import { 
  FileText, 
  CreditCard, 
  BarChart2, 
  Database, 
  Settings, 
  Building, 
  FileUp, 
  Menu,
  X,
  Users,
  Home,
  DollarSign,
  PieChart,
  Wallet,
  ArrowDownToLine,
  LineChart
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import QuickAddTransaction from "@/components/QuickAddTransaction";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Add scroll position state for parallax effect
  const [scrollPosition, setScrollPosition] = useState(0);
  
  // Handle scroll for parallax effect
  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navigation = [
    { name: "Dashboard", href: "/", icon: Home },
    { name: "Transactions", href: "/transactions", icon: FileText },
    { name: "Credit Cards", href: "/credit-cards", icon: CreditCard },
    { name: "Bank Accounts", href: "/bank-accounts", icon: Building }, 
    { name: "Receivables", href: "/receivables", icon: Users },
    { name: "Analytics", href: "/analytics", icon: LineChart },
    { name: "Reconciliations", href: "/reconciliations", icon: PieChart }, 
    { name: "Backup", href: "/backup", icon: Database },
    { name: "Manage Lists", href: "/manage-lists", icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Quick Add Transaction Component (Available Globally) */}
      <QuickAddTransaction />
      
      {/* Mobile menu button */}
      <button 
        className="md:hidden p-3.5 fixed top-5 right-5 z-20 text-white bg-gradient-to-r from-royal to-violet 
                  rounded-full shadow-md hover:shadow-lg transition-all duration-300 btn-scale-hover"
        onClick={toggleMobileMenu}
      >
        {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
      </button>

      {/* Sidebar */}
      <div 
        className={cn(
          "bg-white shadow-xl w-72 flex-shrink-0 md:flex flex-col",
          isMobileMenuOpen ? "fixed inset-y-0 left-0 z-10 flex" : "hidden"
        )}
      >
        <div className="p-6 flex items-center">
          <div className="bg-gradient-to-r from-royal to-violet p-2.5 rounded-xl mr-4 shadow-sm">
            <Wallet className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-xl font-bold primary-gradient-text tracking-tight">Finance Tracker Pro</h1>
        </div>

        <nav className="flex-1 py-5">
          <ul className="space-y-1 px-3">
            {navigation.map((item) => (
              <li key={item.name}>
                <Link href={item.href}>
                  <div className={cn(
                    "flex items-center px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300",
                    location === item.href 
                      ? "bg-gradient-to-r from-royal to-violet text-white shadow-sm hover:shadow-md transform hover:-translate-y-0.5 btn-scale-hover" 
                      : "text-gray-700 hover:bg-gray-50 hover:text-royal"
                  )}>
                    <item.icon className={cn(
                      "mr-3.5 h-5 w-5",
                      location === item.href ? "text-white" : "text-gray-500"
                    )} />
                    {item.name}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Total Balance component removed as requested */}
      </div>

      {/* Main content */}
      <main 
        className="flex-1 overflow-auto"
        style={{ 
          background: `linear-gradient(180deg, rgba(0, 99, 204, 0.04) 0%, rgba(255, 255, 255, 0) 25%)`,
        }}
      >
        <div 
          className="container mx-auto px-4 py-8 md:px-6 lg:px-10"
          style={{ 
            transform: `translateY(${scrollPosition * 0.1}px)`,
            transition: 'transform 0.1s ease-out'
          }}
        >
          <div className="fade-in">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}


function ReconciliationsPage() {
  return (
    <div>
      <h1>Reconciliations</h1>
      <table>
        <thead>
          <tr>
            <th>Account</th>
            <th>Current Balance</th>
            <th>Entered Balance</th>
            <th>Difference</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Credit Card 1</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
          <tr>
            <td>Credit Card 2</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
          <tr>
            <td>Bank Account 1</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

function ReceivablesPage() {
  return (
    <div>
      <h1>Receivables</h1>
      {/* Add your Receivables content here */}
      <p>This page will manage individual balances for reimbursements.</p>
    </div>
  );
}

export {ReconciliationsPage, ReceivablesPage};