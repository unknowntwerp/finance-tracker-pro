import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Transaction, TransactionSplit, useFinanceStore } from '@/lib/transactionStore';
import { formatCurrency } from '@/lib/formatters';
import { Plus, Trash2, Save } from 'lucide-react';
import { generateUUID } from '@/lib/utils';

interface SplitTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
}

export default function SplitTransactionModal({
  isOpen,
  onClose,
  transaction
}: SplitTransactionModalProps) {
  const { 
    expenseCategories, 
    incomeCategories, 
    people, 
    updateTransaction 
  } = useFinanceStore();
  
  const [splits, setSplits] = useState<TransactionSplit[]>([]);
  const [totalSplitAmount, setTotalSplitAmount] = useState(0);
  const [remainingAmount, setRemainingAmount] = useState(0);
  const [isValidSplit, setIsValidSplit] = useState(false);

  // Initialize splits when transaction changes
  useEffect(() => {
    if (transaction) {
      // If transaction already has splits, use them; otherwise create an initial split
      if (transaction.splits && transaction.splits.length > 0) {
        setSplits(transaction.splits);
      } else {
        const initialSplit: TransactionSplit = {
          id: generateUUID(),
          amount: transaction.amount,
          category: transaction.category,
          person: transaction.person
        };
        setSplits([initialSplit]);
      }
    }
  }, [transaction]);

  // Calculate totals and validate 
  useEffect(() => {
    if (!transaction) return;

    const calculatedTotal = splits.reduce((sum, split) => sum + split.amount, 0);
    setTotalSplitAmount(calculatedTotal);
    setRemainingAmount(transaction.amount - calculatedTotal);
    
    // Split is valid if the total equals the transaction amount (within rounding error)
    setIsValidSplit(Math.abs(transaction.amount - calculatedTotal) < 0.01);
  }, [splits, transaction]);

  // Handle adding a new split
  const addSplit = () => {
    if (!transaction) return;
    
    // Get default category based on transaction type
    let defaultCategory = 'Other';
    if (transaction.type === 'expense' && expenseCategories.length > 0) {
      defaultCategory = expenseCategories[0];
    } else if (transaction.type === 'income' && incomeCategories.length > 0) {
      defaultCategory = incomeCategories[0];
    } else if (transaction.type === 'expense') {
      defaultCategory = 'General Expense';
    } else if (transaction.type === 'income') {
      defaultCategory = 'General Income';
    }
    
    const newSplit: TransactionSplit = {
      id: generateUUID(),
      amount: remainingAmount > 0 ? remainingAmount : 0,
      category: defaultCategory,
      person: transaction.type === 'reimbursement' ? (people.length > 0 ? people[0] : undefined) : undefined
    };
    
    setSplits([...splits, newSplit]);
  };

  // Handle removing a split
  const removeSplit = (id: string) => {
    if (splits.length <= 1) return; // Keep at least one split
    setSplits(splits.filter(split => split.id !== id));
  };

  // Update a split
  const updateSplit = (id: string, field: keyof TransactionSplit, value: any) => {
    setSplits(splits.map(split => 
      split.id === id 
        ? { ...split, [field]: field === 'amount' ? parseFloat(value) || 0 : value }
        : split
    ));
  };

  // Get categories based on transaction type
  const categories = transaction?.type === 'expense' 
    ? (expenseCategories.length > 0 ? expenseCategories : ['General Expense']) 
    : (transaction?.type === 'income' 
        ? (incomeCategories.length > 0 ? incomeCategories : ['General Income']) 
        : ['Other']);

  // Save the split transaction
  const saveSplitTransaction = () => {
    if (!transaction || !isValidSplit) return;
    
    updateTransaction(transaction.id, {
      isSplit: true,
      splits: splits
    });
    
    onClose();
  };

  if (!transaction) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Split Transaction</DialogTitle>
          <DialogDescription>
            Split "{transaction.description}" (${formatCurrency(transaction.amount)}) 
            into multiple categories or between people.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-md font-medium">Split Details</h3>
            <div className="flex gap-2 items-center">
              <span className={`text-sm ${!isValidSplit ? 'text-red-500' : 'text-green-500'}`}>
                Remaining: ${formatCurrency(remainingAmount)}
              </span>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={addSplit}
                disabled={remainingAmount <= 0}
              >
                <Plus className="h-4 w-4 mr-1" /> Add Split
              </Button>
            </div>
          </div>

          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
            {splits.map((split, index) => (
              <div 
                key={split.id} 
                className="grid grid-cols-[2fr_2fr_1fr_auto] gap-2 items-center border p-2 rounded-md"
              >
                <div>
                  <Label htmlFor={`category-${split.id}`} className="text-xs">Category</Label>
                  <Select 
                    value={split.category}
                    onValueChange={(value) => updateSplit(split.id, 'category', value)}
                  >
                    <SelectTrigger id={`category-${split.id}`}>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {transaction.type === 'expense' && (
                  <div>
                    <Label htmlFor={`person-${split.id}`} className="text-xs">Person (Optional)</Label>
                    <Select 
                      value={split.person || 'none'}
                      onValueChange={(value) => updateSplit(split.id, 'person', value === 'none' ? undefined : value)}
                    >
                      <SelectTrigger id={`person-${split.id}`}>
                        <SelectValue placeholder="Select person" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {people.map((person) => (
                          <SelectItem key={person} value={person}>
                            {person}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <Label htmlFor={`amount-${split.id}`} className="text-xs">Amount</Label>
                  <Input
                    id={`amount-${split.id}`}
                    type="number"
                    value={split.amount}
                    onChange={(e) => updateSplit(split.id, 'amount', e.target.value)}
                    step="0.01"
                    min="0"
                  />
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="mt-4"
                  onClick={() => removeSplit(split.id)}
                  disabled={splits.length <= 1}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
            ))}
          </div>

          {!isValidSplit && (
            <p className="text-red-500 text-sm mt-2">
              Total split amount must equal the transaction amount.
            </p>
          )}
        </div>

        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button 
            onClick={saveSplitTransaction}
            disabled={!isValidSplit}
            className="gap-2"
          >
            <Save className="h-4 w-4" /> Save Split
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}