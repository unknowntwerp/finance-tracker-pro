import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileUp, Download, Upload, File as FileIcon } from "lucide-react";
import { generateExcelTemplate } from "@/lib/excelUtils";

interface BulkImportFormProps {
  onFileSelected?: (file: File | null) => void;
}

export default function BulkImportForm({ onFileSelected }: BulkImportFormProps) {
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleDownloadTemplate = async () => {
    try {
      await generateExcelTemplate();
    } catch (error) {
      console.error("Failed to download template:", error);
    }
  };

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const uploadedFile = e.dataTransfer.files[0];
      setFile(uploadedFile);
      if (onFileSelected) {
        onFileSelected(uploadedFile);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const uploadedFile = e.target.files[0];
      setFile(uploadedFile);
      if (onFileSelected) {
        onFileSelected(uploadedFile);
      }
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
    if (onFileSelected) {
      onFileSelected(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-medium">Import transactions from Excel</h3>
          <p className="text-sm text-gray-500 mt-1">
            Upload your transaction data in Excel format
          </p>
        </div>
        <Button 
          variant="outline"
          size="sm"
          className="flex items-center gap-1 text-sm"
          onClick={handleDownloadTemplate}
        >
          <Download className="h-4 w-4" />
          <span>Get Template</span>
        </Button>
      </div>

      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          dragActive ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-gray-400"
        } transition-all cursor-pointer relative`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => document.getElementById("file-upload")?.click()}
      >
        <input
          type="file"
          id="file-upload"
          className="hidden"
          accept=".xlsx,.xls"
          onChange={handleFileChange}
        />
        
        {!file ? (
          <div className="flex flex-col items-center">
            <div className="mb-3 p-3 rounded-full bg-gray-100">
              <FileUp className="h-6 w-6 text-gray-500" />
            </div>
            <p className="text-sm font-medium">
              Drag & drop your Excel file here
            </p>
            <p className="text-xs text-gray-500 mt-1">
              or click to browse files (.xlsx or .xls)
            </p>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-4">
            <FileIcon className="h-10 w-10 text-blue-500" />
            <div className="text-left">
              <p className="text-sm font-medium truncate max-w-[200px]">
                {file.name}
              </p>
              <p className="text-xs text-gray-500">
                {(file.size / 1024).toFixed(1)} KB
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-2 text-gray-400 hover:text-red-500"
              onClick={(e) => {
                e.stopPropagation();
                handleRemoveFile();
              }}
            >
              &times;
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}