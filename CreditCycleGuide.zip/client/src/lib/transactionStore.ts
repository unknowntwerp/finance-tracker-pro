import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { formatCurrency } from './formatters';
import { getDefaultCategoryIcon } from './categoryIcons';
import { generateUUID, generateId } from './utils';

// Define split transaction part
export interface TransactionSplit {
  id: string;
  amount: number;
  category: string;
  person?: string; // For shared expenses or reimbursements
}

// Define the transaction interface directly here
export interface Transaction {
  id: string;
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
  categoryIcon?: string; // Icon ID for the category
  person?: string; // Person for reimbursement transactions
  isSplit?: boolean; // Flag to indicate if this transaction is split
  splits?: TransactionSplit[]; // Array of split parts for this transaction
}

// Define source transaction without ID
export interface ImportTransaction {
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
  categoryIcon?: string; // Icon ID for the category
  person?: string; // Person for reimbursement transactions
}

// Credit Card interfaces
export interface CreditCard {
  id: string;
  name: string;
  statementDay: number;
  daysAfter: number;
  creditLimit: number;
  currentStatementDate: string;
  nextStatementDate: string;
  dueDate: string;
  statementBalance: number;
  totalOutstanding: number;
  paymentStatus: "pending" | "paid" | "overdue";
}

// Bank Account and Categories
export type BankAccountString = string;
export type CreditAccount = string;
export type ExpenseCategory = string;
export type IncomeCategory = string;

interface BankAccount {
  id: string;
  name: string;
  createdAt: string;
}

interface CategoryIconMapping {
  category: string;
  iconId: string;
  type: 'expense' | 'income' | 'both';
}

interface FinanceStore {
  // Transactions
  transactions: Transaction[];
  addTransaction: (transaction: ImportTransaction) => void;
  addTransactions: (transactions: ImportTransaction[]) => void;
  removeTransaction: (id: string) => void;
  getTransactions: () => Transaction[];

  // Credit Cards
  creditCards: CreditCard[];
  addCreditCard: (card: Omit<CreditCard, "id" | "currentStatementDate" | "nextStatementDate" | "dueDate" | "statementBalance" | "totalOutstanding" | "paymentStatus">) => void;
  updateCreditCard: (id: string, card: Partial<CreditCard>) => void;
  removeCreditCard: (id: string) => void;

  // Bank Accounts
  bankAccounts: BankAccountString[];
  addBankAccount: (account: BankAccountString) => void;
  removeBankAccount: (account: BankAccountString) => void;

  bankAccountsData: BankAccount[];
  addBankAccountData: (account: { name: string }) => void;
  removeBankAccountData: (id: string) => void;
  getBankAccountById: (id: string) => BankAccount | undefined;
  getBankAccountByName: (name: string) => BankAccount | undefined;

  // Credit Accounts
  creditAccounts: CreditAccount[];
  addCreditAccount: (account: CreditAccount) => void;
  removeCreditAccount: (account: CreditAccount) => void;

  // Categories
  expenseCategories: ExpenseCategory[];
  addExpenseCategory: (category: ExpenseCategory) => void;
  removeExpenseCategory: (category: ExpenseCategory) => void;

  incomeCategories: IncomeCategory[];
  addIncomeCategory: (category: IncomeCategory) => void;
  removeIncomeCategory: (category: IncomeCategory) => void;

  // People for reimbursements
  people: string[];
  addPerson: (person: string) => void;
  removePerson: (person: string) => void;

  clearAllData: () => void;
  //Category Icons
  categoryIcons: CategoryIconMapping[];
  setCategoryIcons: (icons: CategoryIconMapping[]) => void;
}

// Define default data - empty arrays since accounts will be added via their respective pages
const DEFAULT_BANK_ACCOUNTS: BankAccountString[] = [];
const DEFAULT_CREDIT_ACCOUNTS: CreditAccount[] = [];

const DEFAULT_EXPENSE_CATEGORIES: ExpenseCategory[] = [
  "Food", "Rent", "Shopping", "Transport", "Bills", "Entertainment", "Others"
];

const DEFAULT_INCOME_CATEGORIES: IncomeCategory[] = [
  "Salary", "Bonus", "Interest", "Others"
];

const DEFAULT_PEOPLE: string[] = [];

// Default icon mappings for the default categories
const DEFAULT_CATEGORY_ICONS: CategoryIconMapping[] = [
  // Expense categories
  { category: "Food", iconId: "food", type: "expense" },
  { category: "Rent", iconId: "rent", type: "expense" },
  { category: "Shopping", iconId: "shopping", type: "expense" },
  { category: "Transport", iconId: "transport", type: "expense" },
  { category: "Bills", iconId: "bills", type: "expense" },
  { category: "Entertainment", iconId: "entertainment", type: "expense" },
  { category: "Others", iconId: "miscellaneous", type: "expense" },

  // Income categories
  { category: "Salary", iconId: "salary", type: "income" },
  { category: "Bonus", iconId: "bonus", type: "income" },
  { category: "Interest", iconId: "interest", type: "income" },
  { category: "Others", iconId: "miscellaneous", type: "income" },

  // Added default mapping for any categories created later
  { category: "Cashback", iconId: "refunds", type: "income" }
];

// Helper functions for local storage
const loadFromLocalStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch (error) {
    console.error(`Failed to load ${key} from localStorage:`, error);
    return defaultValue;
  }
};

const saveToLocalStorage = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Failed to save ${key} to localStorage:`, error);
  }
};

// Date utilities
const toISODate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const adjustToLastDay = (year: number, month: number, day: number): number => {
  const testDate = new Date(year, month, day);
  return testDate.getMonth() !== month ? new Date(year, month + 1, 0).getDate() : day;
};

// Calculate statement dates and balances for credit cards
const calculateStatementDates = (statementDay: number) => {
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth();

  const adjustedDay = adjustToLastDay(currentYear, currentMonth, statementDay);
  let currentStatementDate = new Date(currentYear, currentMonth, adjustedDay);

  if (today < currentStatementDate) {
    currentStatementDate = new Date(currentYear, currentMonth - 1, adjustToLastDay(currentYear, currentMonth - 1, statementDay));
  }

  const nextMonth = currentStatementDate.getMonth() + 1;
  const nextYear = currentStatementDate.getFullYear() + (nextMonth === 12 ? 1 : 0);
  const nextAdjustedDay = adjustToLastDay(nextYear, nextMonth % 12, statementDay);

  return {
    current: toISODate(currentStatementDate),
    next: toISODate(new Date(nextYear, nextMonth % 12, nextAdjustedDay))
  };
};

interface FinanceState {
  transactions: Transaction[];
  bankAccounts: BankAccountString[];
  bankAccountsData: BankAccount[];
  creditAccounts: CreditAccount[];
  creditCards: CreditCard[];
  expenseCategories: ExpenseCategory[];
  incomeCategories: IncomeCategory[];
  people: string[];
  addTransaction: (transaction: ImportTransaction) => void;
  addTransactions: (transactions: ImportTransaction[]) => void;
  removeTransaction: (id: string) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  getTransactions: () => Transaction[];
  addBankAccount: (name: string) => void;
  removeBankAccount: (id: string) => void;
  updateBankAccount: (id: string, name: string) => void;
  // Bank account data methods
  addBankAccountData: (account: { name: string }) => void;
  removeBankAccountData: (id: string) => void;
  getBankAccountById: (id: string) => BankAccount | undefined;
  getBankAccountByName: (name: string) => BankAccount | undefined;
  // Credit accounts
  addCreditAccount: (name: string) => void;
  removeCreditAccount: (id: string) => void;
  addCreditCard: (card: Omit<CreditCard, 'id' | 'currentStatementDate' | 'nextStatementDate' | 'dueDate' | 'statementBalance' | 'totalOutstanding' | 'paymentStatus'>) => void;
  updateCreditCard: (id: string, card: Partial<CreditCard>) => void;
  removeCreditCard: (id: string) => void;
  addPerson: (person: string) => void;
  removePerson: (person: string) => void;
  updatePerson: (oldName: string, newName: string) => void;
  categoryIcons: CategoryIconMapping[];
  setCategoryIcons: (icons: CategoryIconMapping[]) => void;
  removeTransactions: (ids: string[]) => void;
}

export const useFinanceStore = create<FinanceState>()(
  persist(
    (set, get) => ({
      // Transactions
      transactions: loadFromLocalStorage<Transaction[]>('transactions', []),

      addTransaction: (transaction: ImportTransaction) => {
        const storedTransaction: Transaction = {
          ...transaction,
          id: generateId()
        };

        set((state: FinanceState) => {
          const updatedTransactions = [...state.transactions, storedTransaction];
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },

      addTransactions: (transactions: ImportTransaction[]) => {
        const storedTransactions: Transaction[] = transactions.map(transaction => ({
          ...transaction,
          id: generateId()
        }));

        set((state: FinanceState) => {
          const updatedTransactions = [...state.transactions, ...storedTransactions];
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },

      removeTransaction: (id: string) => {
        set((state: FinanceState) => {
          const updatedTransactions = state.transactions.filter((t: Transaction) => t.id !== id);
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },

      getTransactions: () => {
        return get().transactions;
      },

      updateTransaction: (id: string, transaction: Partial<Transaction>) => {
        set((state: FinanceState) => {
          const updatedTransactions = state.transactions.map((t: Transaction) => 
            t.id === id ? { ...t, ...transaction } : t
          );
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },

      deleteTransaction: (id: string) => {
        set((state: FinanceState) => {
          const updatedTransactions = state.transactions.filter((t: Transaction) => t.id !== id);
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },

      // Credit Cards
      creditCards: loadFromLocalStorage<CreditCard[]>('creditCards', []),

      addCreditCard: (card) => {
        const dates = calculateStatementDates(card.statementDay);
        let dueDate = new Date(dates.current);
        dueDate.setDate(dueDate.getDate() + card.daysAfter);

        const newCard: CreditCard = {
          ...card,
          id: generateId(),
          currentStatementDate: dates.current,
          nextStatementDate: dates.next,
          dueDate: toISODate(dueDate),
          statementBalance: 0,
          totalOutstanding: 0,
          paymentStatus: "pending"
        };

        set((state: FinanceState) => {
          const updatedCards = [...state.creditCards, newCard];
          saveToLocalStorage('creditCards', updatedCards);
          return { creditCards: updatedCards };
        });
      },

      updateCreditCard: (id, card) => {
        set((state: FinanceState) => {
          const updatedCards = state.creditCards.map((c) => 
            c.id === id ? { ...c, ...card } : c
          );
          saveToLocalStorage('creditCards', updatedCards);
          return { creditCards: updatedCards };
        });
      },

      removeCreditCard: (id) => {
        set((state: FinanceState) => {
          const updatedCards = state.creditCards.filter((c) => c.id !== id);
          saveToLocalStorage('creditCards', updatedCards);
          return { creditCards: updatedCards };
        });
      },

      // Bank Accounts
      bankAccounts: loadFromLocalStorage<BankAccountString[]>('bankAccounts', DEFAULT_BANK_ACCOUNTS),

      addBankAccount: (account) => {
        set((state: FinanceState) => {
          if (state.bankAccounts.includes(account)) return state;
          const updatedAccounts = [...state.bankAccounts, account];
          saveToLocalStorage('bankAccounts', updatedAccounts);
          return { bankAccounts: updatedAccounts };
        });
      },

      removeBankAccount: (account) => {
        set((state: FinanceState) => {
          const updatedAccounts = state.bankAccounts.filter((a) => a !== account);
          saveToLocalStorage('bankAccounts', updatedAccounts);
          return { bankAccounts: updatedAccounts };
        });
      },

      updateBankAccount: (id, name) => {
        set((state: FinanceState) => {
          // Find the account to update
          const account = state.bankAccountsData.find(acc => acc.id === id);
          if (!account) return state;

          const oldName = account.name;

          // Update the account name
          const updatedAccounts = state.bankAccountsData.map(acc => 
            acc.id === id ? { ...acc, name } : acc
          );

          // Update transactions that use this account
          const updatedTransactions = state.transactions.map(transaction => 
            transaction.account === oldName ? { ...transaction, account: name } : transaction
          );

          saveToLocalStorage('bankAccountsData', updatedAccounts);
          saveToLocalStorage('transactions', updatedTransactions);

          return { 
            bankAccountsData: updatedAccounts,
            transactions: updatedTransactions
          };
        });
      },

      bankAccountsData: loadFromLocalStorage<BankAccount[]>('bankAccountsData', []),
      addBankAccountData: (account) => {
        set((state: FinanceState) => {
          const updatedAccounts = [
            ...state.bankAccountsData,
            {
              id: generateUUID(),
              name: account.name,
              createdAt: new Date().toISOString()
            }
          ];
          saveToLocalStorage('bankAccountsData', updatedAccounts);
          return { bankAccountsData: updatedAccounts };
        });
      },
      removeBankAccountData: (id) => {
        set((state: FinanceState) => {
          const updatedAccounts = state.bankAccountsData.filter((acc) => acc.id !== id);
          saveToLocalStorage('bankAccountsData', updatedAccounts);
          return { bankAccountsData: updatedAccounts };
        });
      },
      getBankAccountById: (id) => {
        const state = get();
        return state.bankAccountsData.find(acc => acc.id === id);
      },
      getBankAccountByName: (name) => {
        const state = get();
        return state.bankAccountsData.find(acc => acc.name === name);
      },

      // Credit Accounts
      creditAccounts: loadFromLocalStorage<CreditAccount[]>('creditAccounts', DEFAULT_CREDIT_ACCOUNTS),

      addCreditAccount: (account) => {
        set((state: FinanceState) => {
          if (state.creditAccounts.includes(account)) return state;
          const updatedAccounts = [...state.creditAccounts, account];
          saveToLocalStorage('creditAccounts', updatedAccounts);
          return { creditAccounts: updatedAccounts };
        });
      },

      removeCreditAccount: (account) => {
        set((state: FinanceState) => {
          const updatedAccounts = state.creditAccounts.filter((a) => a !== account);
          saveToLocalStorage('creditAccounts', updatedAccounts);
          return { creditAccounts: updatedAccounts };
        });
      },

      // Expense Categories
      expenseCategories: loadFromLocalStorage<ExpenseCategory[]>('expenseCategories', DEFAULT_EXPENSE_CATEGORIES),

      addExpenseCategory: (category: ExpenseCategory) => {
        set((state: FinanceState) => {
          if (state.expenseCategories.includes(category)) return state;
          const updatedCategories = [...state.expenseCategories, category];
          saveToLocalStorage('expenseCategories', updatedCategories);
          return { expenseCategories: updatedCategories };
        });
      },

      removeExpenseCategory: (category: ExpenseCategory) => {
        set((state: FinanceState) => {
          const updatedCategories = state.expenseCategories.filter((c) => c !== category);
          saveToLocalStorage('expenseCategories', updatedCategories);
          return { expenseCategories: updatedCategories };
        });
      },

      // Income Categories
      incomeCategories: loadFromLocalStorage<IncomeCategory[]>('incomeCategories', DEFAULT_INCOME_CATEGORIES),

      addIncomeCategory: (category: IncomeCategory) => {
        set((state: FinanceState) => {
          if (state.incomeCategories.includes(category)) return state;
          const updatedCategories = [...state.incomeCategories, category];
          saveToLocalStorage('incomeCategories', updatedCategories);
          return { incomeCategories: updatedCategories };
        });
      },

      removeIncomeCategory: (category: IncomeCategory) => {
        set((state: FinanceState) => {
          const updatedCategories = state.incomeCategories.filter((c) => c !== category);
          saveToLocalStorage('incomeCategories', updatedCategories);
          return { incomeCategories: updatedCategories };
        });
      },

      // People for reimbursements
      people: loadFromLocalStorage<string[]>('people', DEFAULT_PEOPLE),

      addPerson: (person) => {
        set((state: FinanceState) => {
          if (state.people.includes(person)) return state;
          const updatedPeople = [...state.people, person];
          saveToLocalStorage('people', updatedPeople);
          return { people: updatedPeople };
        });
      },

      removePerson: (person) => {
        set((state: FinanceState) => {
          const updatedPeople = state.people.filter((p) => p !== person);
          saveToLocalStorage('people', updatedPeople);
          return { people: updatedPeople };
        });
      },
      updatePerson: (oldName: string, newName: string) => {
        set(state => {
          // Update person in people array
          const updatedPeople = state.people.map(p => p === oldName ? newName : p);

          // Update person reference in transactions
          const updatedTransactions = state.transactions.map(t => {
            if (t.person === oldName) {
              return { ...t, person: newName };
            }
            return t;
          });

          return {
            ...state,
            people: updatedPeople,
            transactions: updatedTransactions
          };
        });
      },

      clearAllData: () =>
        set({
          bankAccounts: [],
          creditAccounts: [],
          expenseCategories: [
            "Food",
            "Transport",
            "Entertainment",
            "Housing",
            "Utilities",
            "Shopping",
            "Healthcare",
            "Education",
            "Travel",
            "Other"
          ],
          incomeCategories: [
            "Salary",
            "Freelance",
            "Gift",
            "Investments",
            "Reimbursement",
            "Other"
          ],
          transactions: [],
          bankAccountsData: [],
          creditCards: [],
          people: [],
          categoryIcons: [] //Added this line
        }),

      // Category icons
      categoryIcons: loadFromLocalStorage<CategoryIconMapping[]>('categoryIcons', DEFAULT_CATEGORY_ICONS),
      setCategoryIcons: (icons: CategoryIconMapping[]) => {
        set({ categoryIcons: icons });
        saveToLocalStorage('categoryIcons', icons);
      },
      removeTransactions: (ids: string[]) => {
        set((state: FinanceState) => {
          const updatedTransactions = state.transactions.filter((t) => !ids.includes(t.id));
          saveToLocalStorage('transactions', updatedTransactions);
          return { transactions: updatedTransactions };
        });
      },
    }),
    {
      name: 'finance-store',
      partialize: (state) => ({
        transactions: state.transactions,
        bankAccounts: state.bankAccounts,
        bankAccountsData: state.bankAccountsData,
        creditCards: state.creditCards,
        creditAccounts: state.creditAccounts,
        expenseCategories: state.expenseCategories,
        incomeCategories: state.incomeCategories,
        people: state.people,
        categoryIcons: state.categoryIcons
      }),
    }
  )
);

// For backward compatibility - now we keep both store names
export const useTransactionStore = useFinanceStore;