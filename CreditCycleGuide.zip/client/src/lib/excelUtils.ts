
import * as ExcelJS from "exceljs";
import FileSaver from "file-saver";
import { useFinanceStore } from "./transactionStore";

// Function to get bank accounts from our store
const getBankAccounts = (): string[] => {
  return useFinanceStore.getState().bankAccountsData.map(account => account.name);
};

// Function to get credit accounts from our store
const getCreditAccounts = (): string[] => {
  return useFinanceStore.getState().creditAccounts;
};

// Function to get expense categories from our store
const getExpenseCategories = (): string[] => {
  return useFinanceStore.getState().expenseCategories;
};

// Function to get income categories from our store
const getIncomeCategories = (): string[] => {
  return useFinanceStore.getState().incomeCategories;
};

// Transaction types remain constant
const transactionTypes = ["expense", "income", "reimbursement"];

// Get people data from the store
const getPeople = (): string[] => {
  return useFinanceStore.getState().people;
};

export async function generateExcelTemplate(errorRows?: number[], originalFile?: File) {
  // Get dynamic data from the store
  const state = useFinanceStore.getState();
  const bankAccounts = state.bankAccountsData.map(account => account.name);
  const creditCards = state.creditCards;
  const expenseCategories = state.expenseCategories;
  const incomeCategories = state.incomeCategories;
  const peopleData = state.people; // Fixed: using 'people' instead of 'peopleData'

  // Combine bank accounts and credit card names
  const allAccounts = [...bankAccounts, ...creditCards.map(card => card.name)];

  // Create a new workbook
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Finance Tracker Pro";
  workbook.lastModifiedBy = "Finance Tracker Pro";
  workbook.created = new Date();
  workbook.modified = new Date();

  // Create the Transaction Import worksheet FIRST so it appears as the active/default sheet when opening
  const worksheet = workbook.addWorksheet("Transaction Import", {
    properties: { tabColor: { argb: "FFC0000" } }
  });
  
  // Now create a hidden Data Sheet for dropdowns (order matters - this will be second)
  const dataSheet = workbook.addWorksheet('Data', { state: 'hidden' });

  // Set up columns in data sheet for each dropdown type
  dataSheet.getColumn('A').header = 'Transaction Types';
  dataSheet.getColumn('B').header = 'Accounts';
  dataSheet.getColumn('C').header = 'Expense Categories';
  dataSheet.getColumn('D').header = 'Income Categories';
  dataSheet.getColumn('E').header = 'People'; // Added People column

  // Add type options
  transactionTypes.forEach((type, index) => {
    dataSheet.getCell(`A${index + 2}`).value = type;
  });

  // Add account options
  allAccounts.forEach((account, index) => {
    dataSheet.getCell(`B${index + 2}`).value = account;
  });

  // Add expense category options
  expenseCategories.forEach((category, index) => {
    dataSheet.getCell(`C${index + 2}`).value = category;
  });

  // Add income category options
  incomeCategories.forEach((category, index) => {
    dataSheet.getCell(`D${index + 2}`).value = category;
  });

  // Add people options
  peopleData.forEach((person, index) => {
    dataSheet.getCell(`E${index + 2}`).value = person; // Fixed: people array contains strings directly
  });


  // Create instructions worksheet
  const instructionsSheet = workbook.addWorksheet("Instructions", {
    properties: { tabColor: { argb: "FF0000FF" } }
  });
  
  // Add instructions to the Instructions sheet
  instructionsSheet.getColumn('A').width = 100;
  
  // Add header
  const instructionsHeader = instructionsSheet.addRow(["Transaction Import Template Instructions"]);
  instructionsHeader.font = { bold: true, size: 14 };
  instructionsHeader.height = 30;
  
  // Add detailed instructions
  instructionsSheet.addRow(["INSTRUCTIONS: Fill in transaction details in the Transaction Import sheet. The template validates your entries."]);
  instructionsSheet.addRow([""]);
  instructionsSheet.addRow(["How to use this template:"]);
  instructionsSheet.addRow(["1. Fill in transaction details in the Transaction Import sheet"]);
  instructionsSheet.addRow(["2. Use the dropdown lists to select valid options"]);
  instructionsSheet.addRow(["3. For income transactions, use income categories"]);
  instructionsSheet.addRow(["4. For expense transactions, use expense categories"]);
  instructionsSheet.addRow(["5. For reimbursements, select a person in the category field"]);
  instructionsSheet.addRow([""]);
  instructionsSheet.addRow(["Category/Person field:"]);
  instructionsSheet.addRow(["- Use expense categories for expenses"]);
  instructionsSheet.addRow(["- Use income categories for income"]);
  instructionsSheet.addRow(["- Use person names for reimbursements"]);

  // Add column headers with formatting
  const headers = [
    { header: "Date (DD-MM-YYYY)", key: "date", width: 20 },
    { header: "Type", key: "type", width: 15 },
    { header: "Description", key: "description", width: 30 },
    { header: "Amount (Positive)", key: "amount", width: 15 },
    { header: "Account", key: "account", width: 20 },
    { header: "Category/Person", key: "category", width: 25 }
  ];

  worksheet.columns = headers;

  // Format headers
  const headerRow = worksheet.getRow(1);
  
  headerRow.eachCell(cell => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF333333" } };
  });
  
  // Add a hidden helper column for category type
  worksheet.getColumn(8).header = 'Category Type'; // Shifted column index
  worksheet.getColumn(8).hidden = true;

  // Determine if we should add sample rows or error rows
  const today = new Date();
  let rowsToFormat: ExcelJS.Row[] = [];

  if (!errorRows || errorRows.length === 0) {
    // Normal template - add sample rows
    // Add expense sample row
    const sampleRow = worksheet.addRow({
      date: today,
      type: "expense",
      description: "Grocery shopping",
      amount: 1250,
      account: bankAccounts[0] || "Bank Account",
      category: expenseCategories[0] || "Food",
      'Category Type': 'expense'  // Hidden helper column
    });

    // Add income sample row
    const sampleRow2 = worksheet.addRow({
      date: today,
      type: "income",
      description: "Monthly salary",
      amount: 50000,
      account: bankAccounts[0] || "Bank Account",
      category: incomeCategories[0] || "Salary",
      'Category Type': 'income'  // Hidden helper column
    });
    
    // Add reimbursement sample row
    const sampleRow3 = worksheet.addRow({
      date: today,
      type: "reimbursement",
      description: "Lunch paid for colleague",
      amount: 850,
      account: bankAccounts[0] || "Bank Account",
      category: peopleData[0] || "Friend",
      'Category Type': 'reimbursement'  // Hidden helper column
    });
    
    rowsToFormat = [sampleRow, sampleRow2, sampleRow3];
  } else if (originalFile) {
    // If we have the original file, we need to extract the error row data
    try {
      // Read the file and extract the error rows
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        if (!e.target || !e.target.result) {
          throw new Error("Failed to read file content");
        }

        const buffer = e.target.result;
        const sourceWorkbook = new ExcelJS.Workbook();
        await sourceWorkbook.xlsx.load(buffer as ArrayBuffer);
        
        // Get the worksheet
        let sourceWorksheet = sourceWorkbook.getWorksheet("Transaction Import");
        if (!sourceWorksheet) {
          sourceWorksheet = sourceWorkbook.getWorksheet(1);
        }
        
        if (!sourceWorksheet) {
          throw new Error("Could not find worksheet in the Excel file");
        }
        
        // Add error rows with actual data from the original file
        for (const rowNum of errorRows) {
          const sourceRow = sourceWorksheet.getRow(rowNum);
          
          if (sourceRow) {
            // Get values from the source row
            const date = sourceRow.getCell(1).value;
            const type = sourceRow.getCell(2).value?.toString() || '';
            const description = sourceRow.getCell(3).value?.toString() || '';
            const amount = Number(sourceRow.getCell(4).value) || 0;
            const account = sourceRow.getCell(5).value?.toString() || '';
            const category = sourceRow.getCell(6).value?.toString() || '';
            
            // Add the row with original data to the new template
            const errorRow = worksheet.addRow({
              date: date,
              type: type,
              description: description,
              amount: amount,
              account: account,
              category: category,
              'Category Type': type  // Use the transaction type as the category type
            });
            
            // Apply red background to the error row
            errorRow.eachCell(cell => {
              cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFDDDD" } };
            });
            
            rowsToFormat.push(errorRow);
          }
        }
      };
      
      reader.readAsArrayBuffer(originalFile);
      
    } catch (e) {
      console.error("Error extracting data from original file:", e);
      // Fallback to empty error rows
      errorRows.forEach(rowNum => {
        const errorRow = worksheet.addRow({
          date: null,
          type: '',
          description: `Row ${rowNum} had a validation error. Enter valid data here.`,
          amount: null,
          account: '',
          category: '',
          'Category Type': ''
        });
        
        // Apply red background to the error row
        errorRow.eachCell(cell => {
          cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFDDDD" } };
        });
        
        rowsToFormat.push(errorRow);
      });
    }
  } else {
    // Error template without original file - add empty placeholder rows
    errorRows.forEach(rowNum => {
      const errorRow = worksheet.addRow({
        date: null,
        type: '',
        description: `Row ${rowNum} had a validation error. Enter valid data here.`,
        amount: null,
        account: '',
        category: '',
        'Category Type': ''
      });
      
      // Apply red background to the error row
      errorRow.eachCell(cell => {
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFDDDD" } };
      });
      
      rowsToFormat.push(errorRow);
    });
  }
  
  // Apply formatting to all rows
  for (let row of rowsToFormat) {
    // Apply formatting to date cell to ensure it shows as DD-MM-YYYY
    row.getCell(1).numFmt = 'dd-mm-yyyy';
    
    // Apply number formatting to amount cell
    row.getCell(4).numFmt = '#,##0.00';
    
    // Apply text formatting to category column
    const categoryCell = row.getCell(6); // Category/Person column
    categoryCell.font = { color: { argb: "FF000000" } }; // Black text color
  }

  // Define dropdown references
  const typeRef = `Data!$A$2:$A$${transactionTypes.length + 1}`;
  const accountRef = `Data!$B$2:$B$${allAccounts.length + 1}`;
  const expenseCategoryRef = `Data!$C$2:$C$${expenseCategories.length + 1}`;
  const incomeCategoryRef = `Data!$D$2:$D$${incomeCategories.length + 1}`;
  const peopleRef = `Data!$E$2:$E$${peopleData.length + 1}`; // Added peopleRef

  // Add a note to highlight error rows if provided
  if (errorRows && errorRows.length > 0) {
    // Add an explanatory row for error rows
    const errorNotesRow = worksheet.addRow([]);
    const errorCell = worksheet.getCell(`A${errorNotesRow.number}`);
    worksheet.mergeCells(`A${errorNotesRow.number}:F${errorNotesRow.number}`);
    errorCell.value = `ATTENTION: These rows had validation errors. Please correct them and import the file again.`;
    errorCell.font = { bold: true, color: { argb: "FFFF0000" } };
    errorCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFEEEE" } };
    
    // Add a note about successful rows
    const successNotesRow = worksheet.addRow([]);
    const successCell = worksheet.getCell(`A${successNotesRow.number}`);
    worksheet.mergeCells(`A${successNotesRow.number}:F${successNotesRow.number}`);
    successCell.value = `NOTE: Successfully imported rows are not included in this template to prevent duplication.`;
    successCell.font = { italic: true, color: { argb: "FF666666" } };
  }

  // Set validation for 100 rows - start from row 2 (first data row)
  for (let i = 2; i <= 100; i++) {
    // No need to highlight rows here as we do it in the sample rows section
    // Date column (A)
    const dateCell = worksheet.getCell(`A${i}`);

    // Set number format to DD-MM-YYYY
    dateCell.numFmt = 'dd-mm-yyyy';

    // Set data validation
    dateCell.dataValidation = {
      type: 'date',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please enter a valid date in DD-MM-YYYY format',
      errorTitle: 'Invalid Date',
      showInputMessage: true,
      promptTitle: 'Date',
      prompt: 'Enter date in DD-MM-YYYY format',
      formulae: [new Date(2000, 0, 1), new Date(2050, 11, 31)] // Acceptable date range
    };

    // Type column (B)
    worksheet.getCell(`B${i}`).dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a transaction type from the dropdown list',
      errorTitle: 'Invalid Transaction Type',
      showInputMessage: true,
      promptTitle: 'Transaction Type',
      prompt: 'Select expense, income, or reimbursement',
      formulae: [typeRef]
    };

    // Amount column (D)
    const amountCell = worksheet.getCell(`D${i}`);

    // Set number format for currency
    amountCell.numFmt = '#,##0.00';

    amountCell.dataValidation = {
      type: 'decimal',
      operator: 'greaterThan',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Amount must be a positive number',
      errorTitle: 'Invalid Amount',
      showInputMessage: true,
      promptTitle: 'Amount',
      prompt: 'Enter a positive amount',
      formulae: [0] // Min value (must be greater than 0)
    };

    // Account column (E)
    worksheet.getCell(`E${i}`).dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a value from the dropdown list',
      errorTitle: 'Invalid Entry',
      showInputMessage: true,
      promptTitle: 'Account',
      prompt: 'Select an account from the dropdown list',
      formulae: [accountRef]
    };

    // For the Category/Person column (F), we'll set up conditional validation based on 
    // the transaction type. This requires Excel formulas.
    const categoryCell = worksheet.getCell(`F${i}`);

    // Create direct formula reference for dynamic validation based on the type selected
    // If type is income, show income categories
    // If type is expense, show expense categories
    // If type is reimbursement, show people list
    const formulaText = `=IF(B${i}="income",${incomeCategoryRef},IF(B${i}="expense",${expenseCategoryRef},${peopleRef}))`;

    categoryCell.dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a valid option for your transaction type',
      errorTitle: 'Invalid Selection',
      showInputMessage: true,
      promptTitle: 'Category/Person',
      prompt: 'For income use income categories, for expenses use expense categories, for reimbursements select a person',
      formulae: [formulaText]
    };

    // Add cell formula to track transaction type for validation
    worksheet.getCell(`H${i}`).value = { formula: `B${i}` }; // Shifted column index
  }

  // Generate buffer and trigger download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  
  // Use a different filename if we're highlighting error rows
  const filename = errorRows && errorRows.length > 0
    ? `finance_tracker_fix_errors_${new Date().toISOString().slice(0, 10)}.xlsx`
    : "finance_tracker_import_template.xlsx";
    
  FileSaver.saveAs(blob, filename);
}

export interface Transaction {
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
  person?: string; // Added person property
}

// Export transactions to Excel
export async function exportTransactionsToExcel(transactions: Transaction[]) {
  // Create a new workbook
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Finance Tracker Pro";
  workbook.lastModifiedBy = "Finance Tracker Pro";
  workbook.created = new Date();
  workbook.modified = new Date();

  // Create main worksheet
  const worksheet = workbook.addWorksheet("Transactions", {
    properties: { tabColor: { argb: "FFC0000" } }
  });

  // Add column headers with formatting
  const headers = [
    { header: "Date", key: "date", width: 15 },
    { header: "Type", key: "type", width: 15 },
    { header: "Description", key: "description", width: 40 },
    { header: "Amount", key: "amount", width: 15 },
    { header: "Account", key: "account", width: 20 },
    { header: "Category", key: "category", width: 20 },
    { header: "Person", key: "person", width: 20 }
  ];

  worksheet.columns = headers;

  // Format headers
  const headerRow = worksheet.getRow(1);
  headerRow.eachCell(cell => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF333333" } };
  });

  // Add transaction data
  transactions.forEach((transaction) => {
    // Format date to YYYY-MM-DD
    const txDate = new Date(transaction.date);
    const formattedDate = txDate.toISOString().split('T')[0];
    
    worksheet.addRow({
      date: formattedDate,
      type: transaction.type,
      description: transaction.description,
      amount: transaction.amount,
      account: transaction.account,
      category: transaction.category,
      person: transaction.person || ""
    });
  });

  // Apply number formatting to amount column
  worksheet.getColumn("amount").numFmt = "#,##0.00";
  
  // Auto-filter
  worksheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: transactions.length + 1, column: 7 }
  };

  // Generate buffer and trigger download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  FileSaver.saveAs(blob, `finance_tracker_transactions_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export async function parseExcelFile(file: File): Promise<Transaction[]> {
  return new Promise((resolve, reject) => {
    try {
      if (!file) {
        reject(new Error("No file provided"));
        return;
      }

      // Check if the file is an Excel file
      if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        reject(new Error("File must be an Excel file (.xlsx or .xls)"));
        return;
      }

      const reader = new FileReader();

      reader.onload = async (e) => {
        try {
          if (!e.target || !e.target.result) {
            reject(new Error("Failed to read file content"));
            return;
          }

          const buffer = e.target.result;
          const workbook = new ExcelJS.Workbook();

          try {
            await workbook.xlsx.load(buffer as ArrayBuffer);
          } catch (error) {
            console.error("Excel parsing error:", error);
            reject(new Error("Invalid Excel file format"));
            return;
          }

          // Get the right worksheet, trying several possible names
          let worksheet: ExcelJS.Worksheet | undefined = undefined;
          
          // Try several possible worksheet names - ordered by likelihood
          const possibleWorksheetNames = [
            "Transaction Import", 
            "Transactions",
            "Import",
            "Error Rows",
            "Sheet1"
          ];
          
          // Try each name
          for (const name of possibleWorksheetNames) {
            const foundSheet = workbook.getWorksheet(name);
            if (foundSheet) {
              worksheet = foundSheet;
              console.log(`Found worksheet named: ${name}`);
              break;
            }
          }
          
          // If not found by name, try to get the first sheet (excluding the Instructions sheet)
          if (!worksheet) {
            workbook.eachSheet((sheet) => {
              // Skip the Instructions sheet
              if (sheet.name !== "Instructions" && sheet.name !== "Data" && !worksheet) {
                worksheet = sheet;
                console.log(`Using first non-instructions sheet: ${sheet.name}`);
              }
            });
          }
          
          // Last resort - get any sheet
          if (!worksheet) {
            worksheet = workbook.getWorksheet(1);
            console.log("Using first sheet as a fallback");
          }

          if (!worksheet) {
            reject(new Error("Could not find worksheet in the Excel file"));
            return;
          }

          const transactions: Transaction[] = [];
          const errors: string[] = [];

          // Get income and expense categories for validation
          const incomeCategories = getIncomeCategories();
          const expenseCategories = getExpenseCategories();

          // Intelligently determine how many rows to skip
          let headerRows = 0;
          
          // Look for headers - in our template they should be in row 1
          const firstRow = worksheet.getRow(1);
          const headers = [
            "Date", "Type", "Description", "Amount", "Account", "Category"
          ];
          
          // Check if row 1 has our header text (case-insensitive contains check)
          let headerFound = false;
          let rowHasHeaders = true;
          
          for (let i = 0; i < headers.length; i++) {
            const cell = firstRow.getCell(i+1);
            const cellValue = cell.value;
            // Skip this check if cell has no value
            if (cellValue === null || cellValue === undefined) {
              rowHasHeaders = false;
              break;
            }
            
            const cellText = String(cellValue).toLowerCase();
            if (!cellText.includes(headers[i].toLowerCase())) {
              rowHasHeaders = false;
              break;
            }
          }
          
          if (rowHasHeaders) {
            headerFound = true;
            headerRows = 1; // We found headers at row 1, so skip just row 1
            console.log("Headers found at row 1");
          } else {
            // Try row 2 (for backward compatibility with older templates)
            const possibleHeaderRow = worksheet.getRow(2);
            rowHasHeaders = true;
            
            for (let i = 0; i < headers.length; i++) {
              const cell = possibleHeaderRow.getCell(i+1);
              const cellValue = cell.value;
              // Skip this check if cell has no value
              if (cellValue === null || cellValue === undefined) {
                rowHasHeaders = false;
                break;
              }
              
              const cellText = String(cellValue).toLowerCase();
              if (!cellText.includes(headers[i].toLowerCase())) {
                rowHasHeaders = false;
                break;
              }
            }
            
            if (rowHasHeaders) {
              headerFound = true;
              headerRows = 2; // We found headers at row 2, so skip rows 1 and 2
              console.log("Headers found at row 2");
            }
          }
          
          // If no headers were found, assume first row is header
          if (!headerFound) {
            headerRows = 1;
            console.log("No headers detected, defaulting to skip row 1");
          }

          // Get account list for validation - must match how accounts are generated in the template
          const state = useFinanceStore.getState();
          const bankAccounts = state.bankAccountsData.map(account => account.name);
          const creditCards = state.creditCards;
          // Combine bank accounts and credit card names - same as in generateExcelTemplate
          const allAccounts = [...bankAccounts, ...creditCards.map(card => card.name)];
          const peopleList = getPeople();
          
          // Track rows that have data but were skipped due to validation issues
          const rowsWithData: number[] = [];
          
          console.log(`Processing Excel file - will skip first ${headerRows} rows as headers`);
          
          // Check each row for data
          worksheet.eachRow((row, rowNumber) => {
            // Skip header rows
            if (rowNumber <= headerRows) return;

            // Check if row has any data
            let rowIsEmpty = true;
            let hasData = false;
            for (let i = 1; i <= 6; i++) { // Check main columns (date, type, description, amount, account, category)
              const cellValue = row.getCell(i).value;
              if (cellValue) {
                rowIsEmpty = false;
                if (i !== 3) { // Description can be empty
                  hasData = true;
                }
              }
            }
            
            // If row has any data, add to rowsWithData for tracking
            if (!rowIsEmpty) {
              rowsWithData.push(rowNumber);
            }
            
            // Skip empty rows
            if (rowIsEmpty) return;
            
            // If there's only a description but no other data, track as skipped and continue
            if (!hasData) {
              errors.push(`Row ${rowNumber}: Has description but missing other required fields`);
              return;
            }

            try {
              // Get date
              let dateValue = "";
              const dateCell = row.getCell(1);

              // Handle different date formats more flexibly
              if (dateCell.value instanceof Date) {
                // If it's already a Date object, format it as YYYY-MM-DD for storage
                const date = dateCell.value as Date;
                console.log("Found date object:", date);
                dateValue = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
              } else {
                // Otherwise try to parse the string or number
                let rawValue = dateCell.value;
                console.log("Raw date value type:", typeof rawValue, "Value:", rawValue);
                
                if (typeof rawValue === 'number') {
                  // This is likely an Excel serial date number
                  try {
                    // ExcelJS should have already converted this, but just in case:
                    const date = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
                    dateValue = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
                    console.log("Converted Excel serial date:", rawValue, "to:", dateValue);
                  } catch (e) {
                    console.error("Failed to convert Excel serial date:", rawValue, e);
                    dateValue = "";
                  }
                } else {
                  // Try to parse various string formats
                  dateValue = dateCell.value?.toString() || "";
                  console.log("String date value:", dateValue);
                  
                  // If date is in DD-MM-YYYY format, convert it to YYYY-MM-DD for storage
                  if (dateValue && dateValue.includes('-')) {
                    const parts = dateValue.split('-');
                    if (parts.length === 3) {
                      // Try to determine format based on part lengths
                      if (parts[0].length === 2 && parts[1].length === 2 && parts[2].length === 4) {
                        // DD-MM-YYYY format
                        dateValue = `${parts[2]}-${parts[1]}-${parts[0]}`;
                        console.log("Converted DD-MM-YYYY to YYYY-MM-DD:", dateValue);
                      } else if (parts[0].length === 4 && parts[1].length <= 2 && parts[2].length <= 2) {
                        // Already YYYY-MM-DD format, just ensure padding
                        dateValue = `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
                        console.log("Standardized YYYY-MM-DD format:", dateValue);
                      }
                    }
                  } else if (dateValue && dateValue.includes('/')) {
                    // Handle DD/MM/YYYY format as well
                    const parts = dateValue.split('/');
                    if (parts.length === 3) {
                      if (parts[2].length === 4) {
                        // Likely DD/MM/YYYY format
                        dateValue = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
                        console.log("Converted DD/MM/YYYY to YYYY-MM-DD:", dateValue);
                      }
                    }
                  }
                }
              }

              // Get other cell values
              const type = row.getCell(2).value?.toString() || "";
              const description = row.getCell(3).value?.toString() || "";
              const amount = Number(row.getCell(4).value) || 0;
              const account = row.getCell(5).value?.toString() || "";
              const category = row.getCell(6).value?.toString() || "";
              
              // For reimbursement type, the category field contains the person name
              let person = "";
              if (type === "reimbursement") {
                person = category; // Use the category value as the person
              }

              // Store all validation errors for this row
              const rowErrors: string[] = [];

              // Validate required fields
              if (!dateValue) rowErrors.push(`Date is required`);
              if (!type) rowErrors.push(`Type is required`);
              if (!account) rowErrors.push(`Account is required`);
              if (!category) rowErrors.push(`Category/Person is required`);

              // Validate amount
              if (amount <= 0) {
                rowErrors.push(`Amount must be a positive number`);
              }

              // Validate transaction type
              if (type && !transactionTypes.includes(type)) {
                rowErrors.push(`Invalid transaction type '${type}'. Must be one of: ${transactionTypes.join(', ')}`);
              }

              // Validate account exists in the system
              if (account && !allAccounts.includes(account)) {
                console.log("Account validation failed:", account, "Available accounts:", allAccounts);
                rowErrors.push(`Invalid account '${account}'. Must be a valid value from the app.`);
              }

              // Validate category is appropriate for transaction type
              if (type === "income" && !incomeCategories.includes(category)) {
                console.log("Income category validation failed:", category, "Available categories:", incomeCategories);
                rowErrors.push(`Invalid category '${category}' for income transaction. Must be a valid value from the app.`);
              } else if (type === "expense" && !expenseCategories.includes(category)) {
                console.log("Expense category validation failed:", category, "Available categories:", expenseCategories);
                rowErrors.push(`Invalid category '${category}' for expense transaction. Must be a valid value from the app.`);
              } else if (type === "reimbursement" && !peopleList.includes(category)) {
                console.log("Person validation failed for reimbursement:", category, "Available people:", peopleList);
                rowErrors.push(`Invalid person '${category}' for reimbursement. Must be a valid value from the app.`);
              }

              // If there are any validation errors for this row, add them to the errors array
              if (rowErrors.length > 0) {
                errors.push(`Row ${rowNumber}: ${rowErrors.join(', ')}`);
              } else {
                // Only add the transaction if there are no validation errors
                const transaction: Transaction = {
                  date: dateValue,
                  type,
                  description,
                  amount,
                  account,
                  category,
                  person // Added person to transaction
                };
                
                transactions.push(transaction);
              }
            } catch (err) {
              errors.push(`Row ${rowNumber}: Error parsing row - ${err instanceof Error ? err.message : String(err)}`);
            }
          });

          // If we have errors, always return them to the UI
          if (errors.length > 0) {
            // Create a custom error with the validation errors
            const customError = new Error("Validation errors in the Excel file:\n" + errors.join("\n"));
            // Attach the valid transactions to the error so they can still be used
            (customError as any).validTransactions = transactions;
            // Also attach the raw errors array
            (customError as any).errorsList = errors;
            
            reject(customError);
            return;
          }
          
          // If no transactions were found and no errors
          if (transactions.length === 0) {
            reject(new Error("No valid transactions found in the Excel file. Please make sure you've added data to the template and followed the format instructions."));
            return;
          }

          // If we have transactions and no errors, return them
          resolve(transactions);
        } catch (error) {
          console.error("Excel parsing error:", error);
          reject(new Error(`Error processing file: ${error instanceof Error ? error.message : String(error)}`));
        }
      };

      reader.onerror = (event) => {
        console.error("FileReader error:", event);
        reject(new Error("Error reading file"));
      };

      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("Overall error in parseExcelFile:", error);
      reject(new Error(`Error handling file: ${error instanceof Error ? error.message : String(error)}`));
    }
  });
}
