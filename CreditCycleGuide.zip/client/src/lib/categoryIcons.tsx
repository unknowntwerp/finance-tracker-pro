import React from 'react';
import * as Fa from 'react-icons/fa';
import * as Fi from 'react-icons/fi';
import * as Bi from 'react-icons/bi';
import * as Ri from 'react-icons/ri';
import * as Md from 'react-icons/md';
import * as Bs from 'react-icons/bs';
import * as Ai from 'react-icons/ai';
import * as Ti from 'react-icons/ti';
import * as Gi from 'react-icons/gi';
import * as Hi from 'react-icons/hi';
import * as Io from 'react-icons/io5';

// Define common categories
export enum CategoryType {
  EXPENSE = 'expense',
  INCOME = 'income',
  BOTH = 'both'
}

export interface CategoryIcon {
  id: string;
  name: string;
  icon: React.ElementType;
  type: CategoryType;
  color?: string;
}

// Array of category icons with both expense and income categories
export const categoryIcons: CategoryIcon[] = [
  // Food & Dining
  { id: 'food', name: 'Food', icon: Md.MdFastfood, type: CategoryType.EXPENSE, color: '#FF6B6B' },
  { id: 'restaurant', name: 'Restaurant', icon: Fa.FaUtensils, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'coffee', name: 'Coffee', icon: Fa.FaCoffee, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'groceries', name: 'Groceries', icon: Fa.FaShoppingBasket, type: CategoryType.EXPENSE, color: '#2E8B57' },

  // Shopping
  { id: 'shopping', name: 'Shopping', icon: Fa.FaShoppingCart, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'clothing', name: 'Clothing', icon: Fa.FaTshirt, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'electronics', name: 'Electronics', icon: Md.MdDevices, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'gifts', name: 'Gifts', icon: Fa.FaGift, type: CategoryType.EXPENSE, color: '#FF1493' },

  // Transportation
  { id: 'transport', name: 'Transport', icon: Fa.FaBus, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'fuel', name: 'Fuel', icon: Fa.FaGasPump, type: CategoryType.EXPENSE, color: '#FF4500' },
  { id: 'taxi', name: 'Taxi', icon: Fa.FaTaxi, type: CategoryType.EXPENSE, color: '#FFD700' },
  { id: 'parking', name: 'Parking', icon: Fa.FaParking, type: CategoryType.EXPENSE, color: '#808080' },
  { id: 'flight', name: 'Flight', icon: Fa.FaPlane, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'train', name: 'Train', icon: Fa.FaTrain, type: CategoryType.EXPENSE, color: '#008080' },

  // Entertainment
  { id: 'entertainment', name: 'Entertainment', icon: Fa.FaFilm, type: CategoryType.EXPENSE, color: '#9932CC' },
  { id: 'games', name: 'Games', icon: Fa.FaGamepad, type: CategoryType.EXPENSE, color: '#8A2BE2' },
  { id: 'sports', name: 'Sports', icon: Fa.FaFutbol, type: CategoryType.EXPENSE, color: '#228B22' },
  { id: 'books', name: 'Books', icon: Fa.FaBook, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'music', name: 'Music', icon: Fa.FaMusic, type: CategoryType.EXPENSE, color: '#4B0082' },

  // Health
  { id: 'health', name: 'Health', icon: Fa.FaHeartbeat, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'medicine', name: 'Medicine', icon: Fa.FaPills, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'doctor', name: 'Doctor', icon: Fa.FaUserMd, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'fitness', name: 'Fitness', icon: Fa.FaDumbbell, type: CategoryType.EXPENSE, color: '#FF8C00' },

  // Housing
  { id: 'housing', name: 'Housing', icon: Fa.FaHome, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'rent', name: 'Rent', icon: Fa.FaKey, type: CategoryType.EXPENSE, color: '#A0522D' },
  { id: 'furniture', name: 'Furniture', icon: Fa.FaCouch, type: CategoryType.EXPENSE, color: '#DAA520' },
  { id: 'maintenance', name: 'Maintenance', icon: Fa.FaTools, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'utilities', name: 'Utilities', icon: Fa.FaBolt, type: CategoryType.EXPENSE, color: '#FFD700' },

  // Bills
  { id: 'bills', name: 'Bills', icon: Fa.FaFileInvoiceDollar, type: CategoryType.EXPENSE, color: '#3CB371' },
  { id: 'internet', name: 'Internet', icon: Fa.FaWifi, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'phone', name: 'Phone', icon: Fa.FaMobileAlt, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'tv', name: 'TV', icon: Fa.FaTv, type: CategoryType.EXPENSE, color: '#000000' },

  // Education
  { id: 'education', name: 'Education', icon: Fa.FaGraduationCap, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'courses', name: 'Courses', icon: Fa.FaChalkboardTeacher, type: CategoryType.EXPENSE, color: '#9370DB' },
  { id: 'books_education', name: 'Books', icon: Fa.FaBookOpen, type: CategoryType.EXPENSE, color: '#8B4513' },

  // Personal
  { id: 'personal', name: 'Personal', icon: Fa.FaUser, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'beauty', name: 'Beauty', icon: Fa.FaSmile, type: CategoryType.EXPENSE, color: '#FF1493' },
  { id: 'clothing_personal', name: 'Clothing', icon: Fa.FaTshirt, type: CategoryType.EXPENSE, color: '#4682B4' },

  // Travel
  { id: 'travel', name: 'Travel', icon: Fa.FaSuitcase, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'hotel', name: 'Hotel', icon: Fa.FaHotel, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'adventure', name: 'Adventure', icon: Fa.FaMountain, type: CategoryType.EXPENSE, color: '#2E8B57' },

  // Financial
  { id: 'financial', name: 'Financial', icon: Fa.FaMoneyBillWave, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'insurance', name: 'Insurance', icon: Fa.FaShieldAlt, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'taxes', name: 'Taxes', icon: Fa.FaPercentage, type: CategoryType.EXPENSE, color: '#8B0000' },
  { id: 'investments', name: 'Investments', icon: Fa.FaChartLine, type: CategoryType.BOTH, color: '#4169E1' },

  // Income Categories
  { id: 'salary', name: 'Salary', icon: Fa.FaMoneyCheckAlt, type: CategoryType.INCOME, color: '#2E8B57' },
  { id: 'freelance', name: 'Freelance', icon: Fa.FaLaptopCode, type: CategoryType.INCOME, color: '#4169E1' },
  { id: 'bonus', name: 'Bonus', icon: Fa.FaAward, type: CategoryType.INCOME, color: '#FFD700' },
  { id: 'gifts_income', name: 'Gifts', icon: Fa.FaGift, type: CategoryType.INCOME, color: '#FF1493' },
  { id: 'refunds', name: 'Refunds', icon: Fa.FaUndo, type: CategoryType.INCOME, color: '#FF8C00' },
  { id: 'rental', name: 'Rental', icon: Fa.FaBuilding, type: CategoryType.INCOME, color: '#8B4513' },
  { id: 'dividends', name: 'Dividends', icon: Fa.FaPercent, type: CategoryType.INCOME, color: '#4169E1' },
  { id: 'interest', name: 'Interest', icon: Fa.FaUniversity, type: CategoryType.INCOME, color: '#2E8B57' },
  { id: 'pension', name: 'Pension', icon: Fa.FaClock, type: CategoryType.INCOME, color: '#696969' },

  // Miscellaneous
  { id: 'miscellaneous', name: 'Miscellaneous', icon: Fa.FaEllipsisH, type: CategoryType.BOTH, color: '#808080' },
  { id: 'pets', name: 'Pets', icon: Fa.FaPaw, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'charity', name: 'Charity', icon: Fa.FaHandHoldingHeart, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'childcare', name: 'Childcare', icon: Fa.FaBaby, type: CategoryType.EXPENSE, color: '#FF69B4' },
];

// Function to get icon by ID
export const getCategoryIconById = (id: string): CategoryIcon | undefined => {
  // Ensure case-insensitive matching to handle potential case issues
  // since some code might pass lowercase ids
  return categoryIcons.find(icon => icon.id.toLowerCase() === id.toLowerCase());
};

// Function to get filtered icons by type
export const getCategoryIconsByType = (type: CategoryType): CategoryIcon[] => {
  if (type === CategoryType.BOTH) {
    return categoryIcons;
  }
  return categoryIcons.filter(icon => icon.type === type || icon.type === CategoryType.BOTH);
};

// Function to render an icon with proper styling
export const renderCategoryIcon = (
  iconId: string, 
  size: number = 24, 
  className: string = '',
  showLabel: boolean = false,
  categoryName?: string
): JSX.Element => {
  const iconData = getCategoryIconById(iconId);

  if (!iconData) {
    // Fallback icon
    return showLabel ? (
      <div className="flex items-center gap-2">
        <Fa.FaQuestion size={size} className={className} color="#808080" />
        {showLabel && <span>{categoryName || 'Unknown'}</span>}
      </div>
    ) : (
      <Fa.FaQuestion size={size} className={className} color="#808080" />
    );
  }

  const IconComponent = iconData.icon;

  // Return icon with label if requested, similar to the provided image
  if (showLabel) {
    return (
      <div className="flex items-center gap-2">
        <IconComponent 
          size={size} 
          className={className} 
          color={iconData.color} 
          title={categoryName || iconData.name}
        />
      </div>
    );
  }

  // Return just the icon if no label is needed
  return (
    <IconComponent 
      size={size} 
      className={className} 
      color={iconData.color} 
      title={iconData.name}
    />
  );
};

// Default category icons by transaction type
export const getDefaultCategoryIcon = (type: 'expense' | 'income' | 'reimbursement'): string => {
  switch (type) {
    case 'expense':
      return 'miscellaneous';
    case 'income':
      return 'salary';
    case 'reimbursement':
      return 'refunds';
    default:
      return 'miscellaneous';
  }
};