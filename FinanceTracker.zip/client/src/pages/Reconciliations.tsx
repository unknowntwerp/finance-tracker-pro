
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useFinanceStore } from "@/lib/transactionStore";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { 
  Scale, 
  CheckCircle, 
  XCircle, 
  Building, 
  CreditCard, 
  AlertTriangle, 
  CheckSquare, 
  Calendar, 
  HelpCircle, 
  AlertCircle, 
  BarChart,
  ArrowRight
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

export default function Reconciliations() {
  const { bankAccountsData, creditCards, transactions } = useFinanceStore();
  const [actualBalances, setActualBalances] = useState<Record<string, string>>({});
  const [reconciliationDates, setReconciliationDates] = useState<Record<string, string>>({});
  const [completedReconciliations, setCompletedReconciliations] = useState<Record<string, boolean>>({});
  const [accountStats, setAccountStats] = useState<{
    totalAccounts: number;
    reconciled: number;
    pending: number;
    withDifferences: number;
  }>({
    totalAccounts: 0,
    reconciled: 0, 
    pending: 0,
    withDifferences: 0
  });

  // Initialize dates with today's date if empty
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
  const formattedDate = formatDate(today);

  // Calculate current balance for each account
  const calculateBalance = (account: string) => {
    // Check if this is a credit card account
    const isCreditCard = creditCards.some(card => card.name === account);
    const reconciliationDate = reconciliationDates[account] || today; // Use stored reconciliation date or today's date

    return transactions
      .filter(t => t.account === account)
      .filter(t => {
        const transactionDate = new Date(t.date);
        return transactionDate <= new Date(reconciliationDate);
      })
      .reduce((sum, t) => {
        // For credit cards, contra/payment transactions reduce the balance (negative amount reduces debt)
        // For bank accounts, they work as normal (negative amount means money went out)
        if (t.type === "contra") {
          return sum + t.amount; // Use amount directly, already negative for payments
        }

        // Handle transfers correctly - amount sign should be respected
        // For transfers, we respect the sign:
        // - Negative amount means money leaving the account
        // - Positive amount means money coming into the account
        if (t.type === "transfer") {
          return sum + t.amount;
        }

        if (isCreditCard) {
          // For credit cards, expenses increase balance (add to debt)
          // Income/payments decrease balance (reduce debt)
          if (t.type === "expense") return sum + t.amount;
          if (t.type === "income" || t.type === "payment") return sum - t.amount;
        } else {
          // For bank accounts, income increases balance, expenses decrease it
          if (t.type === "income" || t.type === "payment") return sum + t.amount;
          if (t.type === "expense") return sum - t.amount;
        }

        return sum;
      }, 0);
  };

  // Calculate difference between actual and current balance
  const getDifference = (account: string, currentBalance: number) => {
    // If no actual balance has been entered, return 0
    if (!actualBalances[account] || actualBalances[account] === "") {
      return 0;
    }

    const actualBalance = parseFloat(actualBalances[account]);
    if (isNaN(actualBalance)) {
      return 0;
    }

    const isCreditCard = creditCards.some(card => card.name === account);

    if (isCreditCard) {
      // For credit cards: positive means overpayment, negative means debt
      // Actual balance is what's shown on statement (usually negative for outstanding balance)
      return actualBalance - currentBalance;
    } else {
      // For bank accounts: simply subtract current from actual
      return actualBalance - currentBalance;
    }
  };

  // Mark a reconciliation as complete
  const completeReconciliation = (account: string) => {
    setCompletedReconciliations(prev => ({
      ...prev,
      [account]: true
    }));
  };

  // Reset a reconciliation
  const resetReconciliation = (account: string) => {
    setActualBalances(prev => {
      const newBalances = { ...prev };
      delete newBalances[account];
      return newBalances;
    });

    setReconciliationDates(prev => {
      const newDates = { ...prev };
      delete newDates[account];
      return newDates;
    });

    setCompletedReconciliations(prev => {
      const newCompletions = { ...prev };
      delete newCompletions[account];
      return newCompletions;
    });
  };
  
  // Calculate stats for the dashboard
  useEffect(() => {
    const allAccounts = [...bankAccountsData, ...creditCards];
    const total = allAccounts.length;
    const reconciled = Object.keys(completedReconciliations).filter(account => 
      completedReconciliations[account]
    ).length;
    
    const withDifferences = allAccounts
      .map(accountData => {
        const account = accountData.name;
        const currentBalance = calculateBalance(account);
        const difference = getDifference(account, currentBalance);
        return { account, difference };
      })
      .filter(item => actualBalances[item.account] && Math.abs(item.difference) > 0)
      .length;
      
    setAccountStats({
      totalAccounts: total,
      reconciled: reconciled,
      pending: total - reconciled,
      withDifferences: withDifferences
    });
  }, [bankAccountsData, creditCards, actualBalances, completedReconciliations]);

  // Render account table
  const renderAccountTable = (accounts: Array<{id: string, name: string}>, isCreditCard: boolean) => {
    if (accounts.length === 0) {
      return (
        <Card className={cn(
          "bg-gradient-to-br border",
          isCreditCard 
            ? "from-indigo-50 to-indigo-100 border-indigo-200" 
            : "from-blue-50 to-blue-100 border-blue-200"
        )}>
          <CardContent className="flex flex-col items-center justify-center py-10 text-center">
            {isCreditCard ? (
              <CreditCard className="h-12 w-12 text-indigo-400 mb-3" />
            ) : (
              <Building className="h-12 w-12 text-blue-400 mb-3" />
            )}
            <h3 className={cn(
              "text-xl font-medium mb-1",
              isCreditCard ? "text-indigo-700" : "text-blue-700"
            )}>
              No {isCreditCard ? "Credit Cards" : "Bank Accounts"} Added
            </h3>
            <p className={cn(
              "max-w-md mb-4",
              isCreditCard ? "text-indigo-600" : "text-blue-600"
            )}>
              Add {isCreditCard ? "credit cards" : "bank accounts"} in the {isCreditCard ? "Credit Cards" : "Bank Accounts"} section
            </p>
            <Button className={cn(
              isCreditCard ? "bg-indigo-600 hover:bg-indigo-700" : "bg-blue-600 hover:bg-blue-700"
            )}>
              <ArrowRight className="h-4 w-4 mr-2" /> Go to {isCreditCard ? "Credit Cards" : "Bank Accounts"}
            </Button>
          </CardContent>
        </Card>
      );
    }
    
    return (
      <Card className="border shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader className={cn(
              "bg-gradient-to-r",
              isCreditCard 
                ? "from-indigo-50 to-indigo-100" 
                : "from-blue-50 to-blue-100" 
            )}>
              <TableRow>
                <TableHead className="font-semibold py-4 w-[15%]">Account</TableHead>
                <TableHead className="font-semibold w-[15%]">Statement Date</TableHead>
                <TableHead className="font-semibold w-[12%]">System Balance</TableHead>
                <TableHead className="font-semibold w-[15%]">Statement Balance</TableHead>
                <TableHead className="font-semibold w-[10%]">Variance</TableHead>
                <TableHead className="font-semibold w-[13%]">Status</TableHead>
                <TableHead className="font-semibold text-right w-[20%]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {accounts.map(accountData => {
                const account = accountData.name;
                const currentBalance = calculateBalance(account);
                const difference = getDifference(account, currentBalance);
                const isComplete = completedReconciliations[account];
                const hasActualBalance = Boolean(actualBalances[account]);
                
                // Determine the status and color scheme
                let statusColor = "bg-gray-100 border-gray-200 text-gray-700";
                let statusText = "Not Started";
                let StatusIcon = AlertCircle; // Component names should be PascalCase
                
                if (isComplete) {
                  statusColor = "bg-green-100 border-green-200 text-green-800";
                  statusText = "Reconciled";
                  StatusIcon = CheckCircle;
                } else if (hasActualBalance) {
                  if (difference === 0) {
                    statusColor = "bg-blue-100 border-blue-200 text-blue-800";
                    statusText = "Ready to Reconcile";
                    StatusIcon = CheckSquare;
                  } else {
                    statusColor = "bg-amber-100 border-amber-200 text-amber-800";
                    statusText = "Needs Attention";
                    StatusIcon = AlertTriangle;
                  }
                }
                
                return (
                  <TableRow key={accountData.id} className={isComplete ? "bg-green-50" : ""}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {isCreditCard ? (
                          <CreditCard className="h-5 w-5 flex-shrink-0 text-indigo-600" />
                        ) : (
                          <Building className="h-5 w-5 flex-shrink-0 text-blue-600" />
                        )}
                        <span className="truncate">{account}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full">
                        <Input
                          type="date"
                          value={reconciliationDates[account] || today}
                          onChange={(e) => setReconciliationDates(prev => ({
                            ...prev,
                            [account]: e.target.value
                          }))}
                          disabled={isComplete}
                          className={`w-full ${isComplete ? "opacity-80" : ""} py-2`}
                        />
                      </div>
                    </TableCell>
                    <TableCell className="font-medium whitespace-nowrap">
                      {formatCurrency(currentBalance)}
                    </TableCell>
                    <TableCell>
                      <div className="w-full">
                        <Input
                          type="number"
                          value={actualBalances[account] || ""}
                          onChange={(e) => setActualBalances(prev => ({
                            ...prev,
                            [account]: e.target.value
                          }))}
                          placeholder="Enter balance"
                          disabled={isComplete}
                          className={`w-full ${isComplete ? "opacity-80" : ""} py-2`}
                        />
                      </div>
                    </TableCell>
                    <TableCell className={`font-medium whitespace-nowrap ${difference > 0 ? 'text-green-600' : difference < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                      {actualBalances[account] ? formatCurrency(difference) : "—"}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={cn("flex items-center gap-1 px-2 py-1", statusColor)}
                      >
                        <StatusIcon className="w-3.5 h-3.5" />
                        <span>{statusText}</span>
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {isComplete ? (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => resetReconciliation(account)}
                          className="text-gray-600 hover:bg-gray-100 py-1.5"
                        >
                          <XCircle className="w-3.5 h-3.5 mr-1.5" /> Reopen
                        </Button>
                      ) : (
                        <div className="flex gap-2 justify-end">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => resetReconciliation(account)}
                            className="text-gray-600 hover:bg-gray-100 py-1.5"
                            disabled={!actualBalances[account]}
                          >
                            <XCircle className="w-3.5 h-3.5 mr-1.5" /> Reset
                          </Button>
                          <Button 
                            variant="default" 
                            size="sm" 
                            onClick={() => completeReconciliation(account)}
                            className={cn(
                              "transition-colors py-1.5",
                              difference === 0 
                                ? "bg-green-600 hover:bg-green-700" 
                                : "bg-amber-600 hover:bg-amber-700"
                            )}
                            disabled={!actualBalances[account]}
                          >
                            <CheckCircle className="w-3.5 h-3.5 mr-1.5" /> 
                            {difference === 0 ? "Reconcile" : "Force"}
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    );
  };

  // Render dashboard summary cards
  const renderReconciliationSummary = () => {
    const reconciliationProgress = accountStats.totalAccounts 
      ? Math.round((accountStats.reconciled / accountStats.totalAccounts) * 100) 
      : 0;
      
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-blue-700">Reconciliation Status</span>
              <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                {reconciliationProgress}%
              </Badge>
            </div>
            <Progress value={reconciliationProgress} className="h-1.5 bg-blue-200" />
            <div className="flex justify-between text-xs pt-1">
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-600" />
                <span>Reconciled: {accountStats.reconciled}</span>
              </div>
              <div className="flex items-center gap-1">
                <AlertCircle className="h-3 w-3 text-amber-600" />
                <span>Pending: {accountStats.pending}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-purple-700">Accounts with Differences</span>
              <div className="flex items-center gap-1">
                <AlertTriangle className="h-4 w-4 text-purple-700" />
                <span className="text-xl font-bold text-purple-700">{accountStats.withDifferences}</span>
              </div>
            </div>
            <p className="text-xs text-purple-600 mt-1.5">
              {accountStats.withDifferences === 0 
                ? "All accounts match their statements" 
                : `${accountStats.withDifferences} account(s) have variances`}
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-teal-50 border-teal-200">
          <CardContent className="p-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-teal-700">Last Reconciliation</span>
              <Calendar className="h-4 w-4 text-teal-700" />
            </div>
            {accountStats.reconciled > 0 ? (
              <div className="mt-1.5">
                <p className="text-xs text-teal-600">Date:</p>
                <p className="text-sm font-medium text-teal-700">{formattedDate}</p>
              </div>
            ) : (
              <p className="text-xs text-teal-600 mt-1.5">No reconciliations yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="container px-4 py-6">
      {/* Hero section */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-6">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text">
              Account Reconciliation
            </h1>
            <p className="text-gray-600 max-w-xl">
              Match your bank statements with your records
            </p>
          </div>


        </div>
      </div>
      
      {/* Reconciliation Summary */}
      {renderReconciliationSummary()}
      
      {/* Main Content */}
      <Tabs defaultValue="bank" className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList className="bg-gray-100 p-1">
            <TabsTrigger value="bank" className="flex items-center gap-1.5">
              <Building className="h-4 w-4" />
              <span>Bank Accounts</span>
              {bankAccountsData.length > 0 && (
                <Badge variant="secondary" className="ml-1 bg-gray-200">
                  {bankAccountsData.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="credit" className="flex items-center gap-1.5">
              <CreditCard className="h-4 w-4" />
              <span>Credit Cards</span>
              {creditCards.length > 0 && (
                <Badge variant="secondary" className="ml-1 bg-gray-200">
                  {creditCards.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>
          
          <div className="flex items-center">
            <Button variant="outline" size="sm" className="text-sm font-medium">
              <BarChart className="h-4 w-4 mr-2" /> Reconciliation History
            </Button>
          </div>
        </div>
        
        <TabsContent value="bank" className="mt-0 pt-2">
          {renderAccountTable(bankAccountsData, false)}
        </TabsContent>
        
        <TabsContent value="credit" className="mt-0 pt-2">
          {renderAccountTable(creditCards, true)}
        </TabsContent>
      </Tabs>
    </div>
  );
}
