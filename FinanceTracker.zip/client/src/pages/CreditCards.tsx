import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, SharedLimitGroup, useFinanceStore, calculateCreditUtilization } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Plus, 
  CreditCard as CreditCardIcon, 
  Calendar, 
  Trash2, 
  AlertCircle, 
  Banknote, 
  Edit, 
  FileText,
  ArrowUpRight,
  Wallet,
  PieChart,
  Clock,
  Activity,
  Check,
  ArrowDownRight,
  BadgeDollarSign,
  Building
} from "lucide-react";
import { formatCurrency } from "@/lib/formatters";

// Generate a unique ID
const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};

export default function CreditCards() {
  const { 
    creditCards, 
    transactions, 
    sharedLimitGroups,
    addCreditCard, 
    updateCreditCard, 
    removeCreditCard, 
    bankAccountsData, 
    addTransaction,
    addSharedLimitGroup,
    updateSharedLimitGroup,
    removeSharedLimitGroup,
    addCardToSharedGroup,
    removeCardFromSharedGroup
  } = useFinanceStore();
  
  // Credit card form state
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CreditCard | null>(null);
  const [paymentBankAccount, setPaymentBankAccount] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [name, setName] = useState("");
  const [bank, setBank] = useState("");
  const [statementDay, setStatementDay] = useState("");
  const [daysAfter, setDaysAfter] = useState("");
  const [creditLimit, setCreditLimit] = useState("");
  const [isSharedLimit, setIsSharedLimit] = useState(false);
  const [selectedSharedGroup, setSelectedSharedGroup] = useState("");
  const [selectedCardForExport, setSelectedCardForExport] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editCardId, setEditCardId] = useState<string | null>(null);
  
  // Shared limit group form state
  const [isSharedGroupDialogOpen, setIsSharedGroupDialogOpen] = useState(false);
  const [isSharedLimitManagementOpen, setIsSharedLimitManagementOpen] = useState(false);
  const [sharedGroupName, setSharedGroupName] = useState("");
  const [sharedGroupLimit, setSharedGroupLimit] = useState("");
  const [editSharedGroupId, setEditSharedGroupId] = useState<string | null>(null);
  const [isEditSharedGroup, setIsEditSharedGroup] = useState(false);

  // Calculate total amount in the current cycle (between current and next statement dates)
  // This should also account for excess payments from statement balance
  const calculateCycleTotal = (card: CreditCard) => {
    // Current cycle transactions (excluding payments that are meant for statement balance)
    const currentCycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        // Only include transactions after the statement date (not including statement date)
        // and before the next statement date
        return txDate > cycleStart && txDate < cycleEnd && 
              !(t.type === "contra" && t.amount < 0 && t.metadata?.paymentFor === "statement_balance");
      });

    // Calculate raw current cycle amount from normal transactions
    const rawCycleTotal = currentCycleTransactions.reduce((sum, tx) => {
      // Income transactions should reduce the balance (negative amount for credit card)
      if (tx.type === 'income') {
        return sum - tx.amount; // Subtract income amounts (credit)
      } 
      // Expense transactions increase the balance (positive amount for credit card)
      else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
        return sum + tx.amount;
      }
      // Contra entries (payments) should be handled as is
      else {
        return sum + tx.amount;
      }
    }, 0);

    // Calculate statement balance and payments to determine excess
    const statementDate = new Date(card.currentStatementDate);
    const rawStatementBalance = transactions
      .filter(t => t.account === card.name)
      .filter(t => new Date(t.date) <= statementDate)
      .reduce((sum, tx) => {
        // Income transactions should reduce the balance (negative amount for credit card)
        if (tx.type === 'income') {
          return sum - tx.amount; // Subtract income amounts (credit)
        } 
        // Expense transactions increase the balance (positive amount for credit card)
        else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
          return sum + tx.amount;
        }
        // Contra entries (payments) should be handled as is
        else {
          return sum + tx.amount;
        }
      }, 0);

    // Find all payment transactions after statement date
    // Including both statement balance payments and explicit current cycle payments
    const allPaymentsAfterStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        return txDate > statementDate && 
               t.type === "contra" && 
               t.amount < 0;
      });
    
    // First, calculate excess from statement payments
    const statementPayments = allPaymentsAfterStatement.filter(t => 
      t.metadata?.paymentFor === "statement_balance"
    );
    
    // Calculate how much of each payment should go to statement vs. current cycle
    let remainingStatementBalance = Math.max(0, rawStatementBalance);
    let excessPaymentTotal = 0;

    for (const payment of statementPayments) {
      const paymentAmount = Math.abs(payment.amount);

      // If statement is already paid off, all goes to current cycle
      if (remainingStatementBalance <= 0) {
        excessPaymentTotal += paymentAmount;
        continue;
      }

      // Calculate how much of this payment is for statement vs excess
      const amountForStatement = Math.min(paymentAmount, remainingStatementBalance);
      const excess = paymentAmount - amountForStatement;

      // Apply to statement balance first
      remainingStatementBalance -= amountForStatement;

      // Any excess goes to current cycle
      if (excess > 0) {
        excessPaymentTotal += excess;
      }
    }
    
    // Next, add direct current cycle payments
    const currentCyclePayments = allPaymentsAfterStatement.filter(t => 
      t.metadata?.paymentFor === "current_cycle"
    );
    
    // Log for debugging
    console.log("DEBUGGING CARD:", card.name);
    console.log("Current Cycle Payments:", currentCyclePayments);
    console.log("All Payments After Statement:", allPaymentsAfterStatement);
    console.log("Raw Cycle Total before excess:", rawCycleTotal);
    console.log("Excess Payment Total before adding current cycle:", excessPaymentTotal);
    
    for (const payment of currentCyclePayments) {
      excessPaymentTotal += Math.abs(payment.amount);
      console.log("Added current cycle payment:", Math.abs(payment.amount));
      console.log("New excess total:", excessPaymentTotal);
    }
    
    console.log("Final Excess Payment Total:", excessPaymentTotal);
    console.log("Final Cycle Total:", rawCycleTotal - excessPaymentTotal);

    // Current cycle balance is raw charges minus excess payments
    return rawCycleTotal - excessPaymentTotal;
  };

  // Calculate statement balance (transactions before statement date)
  const calculateStatementBalance = (card: CreditCard) => {
    const statementDate = new Date(card.currentStatementDate);

    // Get all transactions on or before the statement date
    const allTransactionsBeforeStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        // Include transactions on the statement date (same day)
        return txDate <= statementDate;
      });

    // Calculate the raw statement balance, accounting for transaction types
    const rawStatementBalance = allTransactionsBeforeStatement.reduce((sum, tx) => {
      // Income transactions should reduce the balance (negative amount for credit card)
      if (tx.type === 'income') {
        return sum - tx.amount; // Subtract income amounts (credit)
      } 
      // Expense transactions increase the balance (positive amount for credit card)
      else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
        return sum + tx.amount;
      }
      // Contra entries (payments) should be handled as is
      else {
        return sum + tx.amount;
      }
    }, 0);

    console.log("RAW STATEMENT BALANCE FOR", card.name, ":", rawStatementBalance);

    // Find payments made after statement date that should reduce the statement balance
    // Only include payments explicitly marked for statement balance
    const paymentsAfterStatement = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        return txDate > statementDate && 
               t.type === "contra" && 
               t.amount < 0 && 
               t.metadata?.paymentFor === "statement_balance";
      });

    // Calculate how much payment to apply
    let appliedPayments = 0;

    // Sort payments by date (oldest first)
    const sortedPayments = [...paymentsAfterStatement].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    console.log("PAYMENTS AFTER STATEMENT:", sortedPayments);

    // If statement balance is already negative (overpaid from previous cycle),
    // return the negative balance immediately
    if (rawStatementBalance < 0) {
      console.log("Returning negative statement balance:", rawStatementBalance);
      return rawStatementBalance;
    }

    // If there's no positive statement balance, return 0
    if (rawStatementBalance <= 0) {
      console.log("No statement balance");
      return 0;
    }

    // Process payments
    let remainingStatementBalance = rawStatementBalance;

    for (const payment of sortedPayments) {
      const paymentAmount = Math.abs(payment.amount);

      // If statement balance is already paid off, no need to apply more payments
      if (remainingStatementBalance <= 0) break;

      // Apply payment to statement balance (limited by remaining balance)
      const amountToApply = Math.min(paymentAmount, remainingStatementBalance);
      appliedPayments += amountToApply;
      remainingStatementBalance -= amountToApply;
    }

    const finalBalance = rawStatementBalance - appliedPayments;
    console.log("FINAL STATEMENT BALANCE:", finalBalance);
    return finalBalance;
  };

  const exportCardTransactions = (card: CreditCard) => {
    const cycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      });

    const csv = [
      ['Date', 'Description', 'Amount', 'Category'].join(','),
      ...cycleTransactions.map(t => 
        [t.date, t.description, t.amount, t.category].join(',')
      )
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}-statement.csv`;
    a.click();
  };

  const resetForm = () => {
    setName("");
    setBank("");
    setStatementDay("");
    setDaysAfter("");
    setCreditLimit("");
    setIsSharedLimit(false);
    setSelectedSharedGroup("");
    setFormError(null);
  };
  
  const resetSharedGroupForm = () => {
    setSharedGroupName("");
    setSharedGroupLimit("");
    setEditSharedGroupId(null);
    setIsEditSharedGroup(false);
    setFormError(null);
  };
  
  // Calculate usage for a shared limit group
  const calculateSharedGroupUsage = (groupId: string) => {
    // Get all cards in this group
    const groupCards = creditCards.filter(card => card.sharedLimitGroupId === groupId);
    
    // Sum their usage
    return groupCards.reduce((total, card) => {
      return total + calculateStatementBalance(card) + calculateCycleTotal(card);
    }, 0);
  };
  
  // Calculate the usage for a specific card
  const calculateCardUsage = (card: CreditCard) => {
    return calculateStatementBalance(card) + calculateCycleTotal(card);
  };
  
  // Handle adding or updating a shared limit group
  const handleAddOrUpdateSharedGroup = () => {
    // Form validation
    if (!sharedGroupName.trim()) {
      setFormError("Group name is required");
      return;
    }
    
    const totalLimitNum = parseFloat(sharedGroupLimit);
    if (isNaN(totalLimitNum) || totalLimitNum <= 0) {
      setFormError("Total limit must be a positive number");
      return;
    }
    
    const groupData = {
      name: sharedGroupName.trim(),
      totalLimit: totalLimitNum,
      cardIds: []
    };
    
    if (isEditSharedGroup && editSharedGroupId) {
      // Update existing group
      updateSharedLimitGroup(editSharedGroupId, groupData);
    } else {
      // Add new group
      addSharedLimitGroup(groupData);
    }
    
    // Close dialog and reset form
    setIsSharedGroupDialogOpen(false);
    resetSharedGroupForm();
  };
  
  // Handle opening the shared group dialog for editing
  const handleEditSharedGroup = (group: SharedLimitGroup) => {
    setSharedGroupName(group.name);
    setSharedGroupLimit(String(group.totalLimit));
    setEditSharedGroupId(group.id);
    setIsEditSharedGroup(true);
    setIsSharedLimitManagementOpen(false); // Close the management dialog
    setIsSharedGroupDialogOpen(true);
  };

  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const handlePayment = () => {
    if (!selectedCard || !paymentBankAccount || !paymentAmount || !paymentDate) return;

    const amount = parseFloat(paymentAmount);
    const date = paymentDate;

    // Get the current statement balance
    const statementBalance = calculateStatementBalance(selectedCard);

    // Add contra transaction pair for credit card payment
    // For bank account: negative amount (money goes out)
    addTransaction({
      date,
      type: "contra",
      description: `Payment to ${selectedCard.name}`,
      amount: -amount, // Negative amount for bank account (money going out)
      account: paymentBankAccount,
      category: "Credit Card Payment"
    });

    // Determine payment application:
    // If payment is less than or equal to statement balance, apply all to statement
    // If payment exceeds statement balance, split into two transactions
    if (amount <= statementBalance || statementBalance <= 0) {
      // Apply entire payment to statement balance (or current cycle if no statement balance)
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount}`,
        amount: -amount, // Negative amount for credit card (reduces outstanding debt)
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: statementBalance > 0 ? "statement_balance" : "current_cycle", 
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: amount
        }
      });
    } else {
      // Split payment: part for statement balance, part for current cycle
      // First transaction - pay off statement balance
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Statement)`,
        amount: -statementBalance, // Amount that covers statement balance
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "statement_balance",
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: statementBalance
        }
      });

      // Second transaction - excess payment for current cycle
      const excessAmount = amount - statementBalance;
      addTransaction({
        date, 
        type: "contra",
        description: `Payment received from ${paymentBankAccount} (Current Cycle)`,
        amount: -excessAmount, // Excess amount
        account: selectedCard.name,
        category: "Credit Card Payment",
        metadata: {
          paymentFor: "current_cycle",
          statementDate: selectedCard.currentStatementDate,
          paymentAmount: excessAmount
        }
      });
    }

    // Reset payment form
    setIsPaymentDialogOpen(false);
    setSelectedCard(null);
    setPaymentBankAccount("");
    setPaymentAmount("");
    setPaymentDate(new Date().toISOString().split('T')[0]);
  };

  const getPaymentStatus = (card: CreditCard) => {
    const now = new Date();
    const dueDate = new Date(card.dueDate);

    // Get current statement balance after payments
    const currentStatementBalance = calculateStatementBalance(card);

    const statementDate = new Date(card.currentStatementDate);
    const rawStatementBalance = transactions
      .filter(t => t.account === card.name)
      .filter(t => new Date(t.date) < statementDate)
      .reduce((sum, tx) => {
        // Income transactions should reduce the balance (negative amount for credit card)
        if (tx.type === 'income') {
          return sum - tx.amount; // Subtract income amounts (credit)
        } 
        // Expense transactions increase the balance (positive amount for credit card)
        else if (tx.type === 'expense' || (tx.type !== 'contra' && tx.amount > 0)) {
          return sum + tx.amount;
        }
        // Contra entries (payments) should be handled as is
        else {
          return sum + tx.amount;
        }
      }, 0);

    // If there never was a statement balance or it's been fully paid off
    if (currentStatementBalance <= 0) {
      // If there was a real statement balance that's now paid off
      if (rawStatementBalance > 0) {
        return "fully paid";
      }
      // If there was never a statement balance to begin with
      return "no due";
    }

    // If statement balance exists and is partially paid
    if (currentStatementBalance > 0 && currentStatementBalance < rawStatementBalance) {
      return "partially paid";
    }

    // If statement is unpaid and overdue
    if (currentStatementBalance > 0 && now > dueDate) {
      return "overdue";
    }

    // If statement is unpaid but not yet due
    return "pending";
  };

  const handleAddOrUpdateCard = () => {
    // Form validation
    if (!name.trim()) {
      setFormError("Card name is required");
      return;
    }

    if (!bank.trim()) {
      setFormError("Bank name is required");
      return;
    }

    const statementDayNum = parseInt(statementDay);
    if (isNaN(statementDayNum) || statementDayNum < 1 || statementDayNum > 31) {
      setFormError("Statement day must be between 1 and 31");
      return;
    }

    const daysAfterNum = parseInt(daysAfter);
    if (isNaN(daysAfterNum) || daysAfterNum < 1 || daysAfterNum > 60) {
      setFormError("Days after must be between 1 and 60");
      return;
    }

    const creditLimitNum = parseFloat(creditLimit);
    if (isNaN(creditLimitNum) || creditLimitNum <= 0) {
      setFormError("Credit limit must be a positive number");
      return;
    }

    // Validate shared group selection if shared limit is selected
    if (isSharedLimit && !selectedSharedGroup) {
      setFormError("Please select a shared limit group");
      return;
    }

    const cardData: Omit<CreditCard, 'id' | 'currentStatementDate' | 'nextStatementDate' | 'dueDate' | 'statementBalance' | 'totalOutstanding' | 'paymentStatus'> = {
      name,
      bank,
      statementDay: statementDayNum,
      daysAfter: daysAfterNum,
      creditLimit: creditLimitNum,
      isSharedLimit,
      sharedLimitGroupId: isSharedLimit ? selectedSharedGroup : undefined
    };

    if (isEditMode && editCardId) {
      // Update existing card
      updateCreditCard(editCardId, cardData);
      
      // Handle shared limit group assignment changes
      const existingCard = creditCards.find(c => c.id === editCardId);
      if (existingCard) {
        // If card is now part of a shared group but wasn't before, or changed groups
        if (isSharedLimit && selectedSharedGroup && 
            (!existingCard.isSharedLimit || existingCard.sharedLimitGroupId !== selectedSharedGroup)) {
          // Add card to the new group
          addCardToSharedGroup(editCardId, selectedSharedGroup);
        } 
        // If card was part of a shared group but now isn't
        else if (!isSharedLimit && existingCard.isSharedLimit) {
          // Remove card from any group
          removeCardFromSharedGroup(editCardId);
        }
      }
    } else {
      // Add new card
      const newCardId = addCreditCard(cardData);
      
      // If this is a shared limit card, add it to the group
      if (isSharedLimit && selectedSharedGroup && newCardId) {
        addCardToSharedGroup(newCardId, selectedSharedGroup);
      }
    }

    // Close dialog and reset form
    setIsDialogOpen(false);
    resetForm();
  };

  const handleOpenDialog = () => {
    resetForm();
    setIsEditMode(false);
    setEditCardId(null);
    setIsDialogOpen(true);
  };

  const handleOpenEditDialog = (card: CreditCard) => {
    resetForm();
    setName(card.name);
    setBank(card.bank);
    setStatementDay(String(card.statementDay));
    setDaysAfter(String(card.daysAfter));
    setCreditLimit(String(card.creditLimit));
    setIsSharedLimit(card.isSharedLimit);
    setSelectedSharedGroup(card.sharedLimitGroupId || '');
    setIsEditMode(true);
    setEditCardId(card.id);
    setIsDialogOpen(true);
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "no due":
      case "fully paid":
        return "bg-green-100 text-green-800";
      case "partially paid":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
    });
  };

  return (
    <div className="container px-4 py-6">
      {/* Hero section */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-6">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text">
              Credit Card Management
            </h1>
            <p className="text-gray-600 max-w-xl">
              Track your credit cards, statement cycles, and payments in one convenient place.
            </p>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={() => {
                setIsSharedLimitManagementOpen(true);
              }}
              variant="outline"
              className="border-indigo-200 text-indigo-700 hover:bg-indigo-50"
            >
              <Building className="mr-2 h-4 w-4" /> Manage Shared Limits
            </Button>
            <Button 
              onClick={handleOpenDialog}
              className="btn-gradient"
            >
              <Plus className="mr-2 h-4 w-4" /> Add Card
            </Button>
          </div>
        </div>
      </div>

      {creditCards.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <CreditCardIcon className="h-8 w-8 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Credit Cards Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-4">
              Add your credit cards to track statement dates, payment due dates, and balances.
            </p>
            <Button onClick={handleOpenDialog}>
              <Plus className="h-4 w-4 mr-2" /> Add Credit Card
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Credit Card Overview Statistics in single row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
            {/* Card 1: Total Outstanding */}
            <div className="rounded-lg shadow-sm p-6 border border-red-200 bg-gradient-to-br from-red-50 to-white">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-red-700">Total Outstanding</h3>
                <div className="h-8 w-8 rounded-full bg-red-100 border border-red-200 flex items-center justify-center">
                  <CreditCardIcon className="h-4 w-4 text-red-600" />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold text-red-600">
                  {formatCurrency(creditCards.reduce((sum, card) => {
                    const statementBalance = calculateStatementBalance(card);
                    const cycleTotal = calculateCycleTotal(card);
                    return sum + statementBalance + cycleTotal;
                  }, 0))}
                </p>
                <p className="text-sm text-gray-500">
                  Across {creditCards.length} credit {creditCards.length === 1 ? 'card' : 'cards'}
                </p>
              </div>
            </div>
            
            {/* Card 2: Upcoming Payments */}
            <div className="rounded-lg shadow-sm p-6 border border-amber-200 bg-gradient-to-br from-amber-50 to-white">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-amber-700">Upcoming Payments</h3>
                <div className="h-8 w-8 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center">
                  <Calendar className="h-4 w-4 text-amber-600" />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold text-amber-600">
                  {formatCurrency(creditCards
                    .filter(card => {
                      const status = getPaymentStatus(card);
                      return status === "pending" || status === "partially paid";
                    })
                    .reduce((sum, card) => sum + calculateStatementBalance(card), 0)
                  )}
                </p>
                <p className="text-sm text-gray-500">
                  Payments due soon
                </p>
              </div>
            </div>
            
            {/* Card 3: Credit Utilization */}
            <div className="rounded-lg shadow-sm p-6 border border-indigo-200 bg-gradient-to-br from-indigo-50 to-white">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-indigo-700">Credit Utilization</h3>
                <div className="h-8 w-8 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center">
                  <PieChart className="h-4 w-4 text-indigo-600" />
                </div>
              </div>
              <div className="space-y-1">
                {(() => {
                  // Use the shared limit utility function for accurate credit utilization
                  const utilization = calculateCreditUtilization(creditCards, sharedLimitGroups, transactions);
                  
                  // Calculate utilization percentage as a decimal for comparisons
                  const utilizationDecimal = utilization.utilizationPercentage / 100;
                  
                  return (
                    <>
                      <div className="flex items-center justify-between">
                        <p className="text-3xl font-bold text-indigo-600">{utilization.utilizationPercentage.toFixed(1)}%</p>
                        <span className={`text-xs font-medium px-2 py-1 rounded-full bg-white border shadow-sm ml-2 inline-block mt-1 
                          ${utilizationDecimal <= 0.30 ? "text-green-700 border-green-200" : 
                            utilizationDecimal <= 0.50 ? "text-blue-700 border-blue-200" : 
                            utilizationDecimal <= 0.75 ? "text-amber-700 border-amber-200" : "text-red-700 border-red-200"}`}>
                          {utilizationDecimal <= 0.30 ? "Excellent" : 
                          utilizationDecimal <= 0.50 ? "Good" : 
                          utilizationDecimal <= 0.75 ? "Fair" : "High"}
                        </span>
                      </div>
                      <div className="mt-2 mb-1">
                        <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden shadow-inner">
                          <div 
                            className={`h-full ${
                              utilizationDecimal <= 0.30 ? "bg-green-500" : 
                              utilizationDecimal <= 0.50 ? "bg-blue-500" : 
                              utilizationDecimal <= 0.75 ? "bg-amber-500" : "bg-red-500"
                            }`}
                            style={{ width: `${Math.min(utilization.utilizationPercentage, 100)}%` }}
                          ></div>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500">
                        {formatCurrency(utilization.totalUtilized)} of {formatCurrency(utilization.totalLimit)} total credit limit
                      </p>
                    </>
                  );
                })()}
              </div>
            </div>
          </div>

          {/* Shared limit groups content removed from main page */}

          {/* Credit Card Management Section */}
          <div>
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <CreditCardIcon className="h-5 w-5 mr-2 text-primary" /> 
              Your Credit Cards
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {creditCards
                .sort((a, b) => {
                  // Get payment status for both cards
                  const statusA = getPaymentStatus(a);
                  const statusB = getPaymentStatus(b);
                  
                  // Define priority order for payment statuses
                  const statusPriority: Record<string, number> = {
                    "overdue": 0,      // Highest priority
                    "pending": 1,
                    "partially paid": 2,
                    "fully paid": 3,
                    "no due": 4        // Lowest priority
                  };
                  
                  // First, sort by payment status priority
                  if (statusPriority[statusA] !== statusPriority[statusB]) {
                    return statusPriority[statusA] - statusPriority[statusB];
                  }
                  
                  // If same status, sort by due date (for pending and overdue cards)
                  if (statusA === "pending" || statusA === "overdue") {
                    const dueDateA = new Date(a.dueDate);
                    const dueDateB = new Date(b.dueDate);
                    return dueDateA.getTime() - dueDateB.getTime(); // Soonest due date first
                  }
                  
                  // For fully paid or no due cards, sort by statement date
                  return new Date(a.currentStatementDate).getTime() - new Date(b.currentStatementDate).getTime();
                })
                .map((card) => {
                  // Calculate payment status for each card
                  const paymentStatus = getPaymentStatus(card);

                  return (
                    <Card 
                      key={card.id} 
                      className="overflow-hidden hover:shadow-md transition-shadow border-gray-200"
                      style={{
                        background: paymentStatus === "fully paid" || paymentStatus === "no due" 
                          ? "linear-gradient(to right, #e6f7ef, #ffffff)" 
                          : paymentStatus === "partially paid" 
                            ? "linear-gradient(to right, #e6f0fa, #ffffff)" 
                            : paymentStatus === "pending" 
                              ? "linear-gradient(to right, #fef5e7, #ffffff)" 
                              : "linear-gradient(to right, #feebeb, #ffffff)",
                        borderLeft: paymentStatus === "fully paid" || paymentStatus === "no due" 
                          ? "4px solid rgb(34, 197, 94)" 
                          : paymentStatus === "partially paid" 
                            ? "4px solid rgb(59, 130, 246)" 
                            : paymentStatus === "pending" 
                              ? "4px solid rgb(234, 179, 8)" 
                              : "4px solid rgb(239, 68, 68)"
                      }}
                    >
                      <CardHeader className="pb-1.5 px-3 pt-3">
                        <div className="flex justify-between items-start">
                          <div className="overflow-hidden">
                            <CardTitle className="text-base font-bold tracking-tight truncate group flex items-center">
                              {card.name}
                              {card.isSharedLimit && (
                                <span 
                                  className="ml-2 inline-flex items-center rounded-full bg-indigo-100 px-1.5 py-0.5 text-xs font-medium text-indigo-700"
                                  title="This card shares a credit limit with other cards"
                                >
                                  Shared
                                </span>
                              )}
                            </CardTitle>
                            <div className="text-xs text-gray-500 mt-1 flex items-center truncate">
                              <Building className="h-3 w-3 mr-1 inline flex-shrink-0" />
                              <span className="truncate">{card.bank}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenEditDialog(card)}
                              className="p-0.5 h-auto text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeCreditCard(card.id)}
                              className="p-0.5 h-auto text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex justify-between mt-1.5">
                          <div className="flex flex-col">
                            <Badge variant="outline" className="px-2 py-0.5 text-xs bg-white border font-medium">
                              {card.isSharedLimit && card.sharedLimitGroupId ? (
                                <>
                                  <span className="text-indigo-600 font-medium">Limit:</span> {formatCurrency(
                                    sharedLimitGroups.find(g => g.id === card.sharedLimitGroupId)?.totalLimit || card.creditLimit
                                  )}
                                </>
                              ) : (
                                formatCurrency(card.creditLimit)
                              )}
                            </Badge>
                          </div>
                          <Badge 
                            className={`px-2 py-0.5 text-xs font-medium ${
                              paymentStatus === "fully paid" || paymentStatus === "no due" ? "bg-green-100 text-green-800 border-green-200" :
                              paymentStatus === "partially paid" ? "bg-blue-100 text-blue-800 border-blue-200" :
                              paymentStatus === "pending" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                              "bg-red-100 text-red-800 border-red-200"
                            }`}
                          >
                            {paymentStatus === "no due" ? "No Due" : 
                             paymentStatus === "fully paid" ? "Fully Paid" :
                             paymentStatus === "partially paid" ? "Partially Paid" :
                             paymentStatus.charAt(0).toUpperCase() + paymentStatus.slice(1)}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="px-3 pb-3 pt-1">
                        <div className="space-y-3">
                          <div className="grid grid-cols-3 gap-1 text-sm bg-gray-50 rounded-lg p-1.5 border border-gray-100">
                            <div className="text-center p-1.5 bg-white rounded shadow-sm">
                              <div className="uppercase font-semibold text-xs text-indigo-600 mb-0.5">Statement</div>
                              <div className="font-medium">{formatDate(card.currentStatementDate)}</div>
                            </div>
                            <div className="text-center p-1.5 bg-white rounded shadow-sm">
                              <div className="uppercase font-semibold text-xs text-purple-600 mb-0.5">Next</div>
                              <div className="font-medium">{formatDate(card.nextStatementDate)}</div>
                            </div>
                            <div className="text-center p-1.5 bg-white rounded shadow-sm">
                              <div className="uppercase font-semibold text-xs text-orange-600 mb-0.5">Due</div>
                              <div className={`font-medium ${
                                paymentStatus === "overdue" ? "text-red-600 font-bold" : 
                                new Date(card.dueDate) <= new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000) ? "text-amber-600" : "text-gray-800"
                              }`}>
                                {formatDate(card.dueDate)}
                              </div>
                            </div>
                          </div>

                          <div className="space-y-1 text-sm pt-1.5">
                            <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors">
                              <span className="text-gray-700 flex items-center gap-1">
                                <Badge variant="outline" className="h-2 w-2 p-0 bg-red-500 border-none rounded-full"/>
                                Statement Balance
                              </span>
                              <span className={`font-medium ${
                                calculateStatementBalance(card) > 0 
                                  ? "text-red-600" 
                                  : calculateStatementBalance(card) < 0 
                                    ? "text-green-600" 
                                    : "text-gray-500"
                              }`}>
                                {formatCurrency(calculateStatementBalance(card), false, true)}
                              </span>
                            </div>
                            <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors">
                              <span className="text-gray-700 flex items-center gap-1">
                                <Badge variant="outline" className="h-2 w-2 p-0 bg-blue-500 border-none rounded-full"/>
                                Current Cycle
                              </span>
                              <span className={`font-medium ${
                                calculateCycleTotal(card) > 0
                                  ? "text-blue-600"
                                  : calculateCycleTotal(card) < 0
                                    ? "text-green-600"
                                    : "text-blue-600"
                              }`}>
                                {formatCurrency(calculateCycleTotal(card), false, true)}
                              </span>
                            </div>
                            <div className="flex justify-between items-center p-1.5 hover:bg-gray-50 rounded transition-colors font-medium">
                              <span className="text-gray-800 flex items-center gap-1">
                                <Badge variant="outline" className="h-2 w-2 p-0 bg-purple-500 border-none rounded-full"/>
                                Total Outstanding
                              </span>
                              {(() => {
                                // Calculate total
                                const statementBalance = calculateStatementBalance(card);
                                const cycleTotal = calculateCycleTotal(card);
                                const totalOutstanding = statementBalance + cycleTotal;
                                
                                return (
                                  <span className={`font-medium ${
                                    totalOutstanding > 0 
                                      ? "text-red-600" 
                                      : totalOutstanding < 0
                                        ? "text-green-600"
                                        : "text-gray-900"
                                  }`}>
                                    {formatCurrency(totalOutstanding, false, true)}
                                  </span>
                                );
                              })()}
                            </div>
                            <div className="flex justify-between items-center p-1.5 mt-1 hover:bg-gray-50 rounded transition-colors">
                              <span className="text-gray-700 flex items-center gap-1">
                                <Badge variant="outline" className="h-2 w-2 p-0 bg-green-500 border-none rounded-full"/>
                                Available Credit
                              </span>
                              {(() => {
                                const statementBalance = calculateStatementBalance(card);
                                const cycleTotal = calculateCycleTotal(card);
                                const totalOutstanding = statementBalance + cycleTotal;
                                
                                // For shared limit cards, we need to calculate available credit differently
                                let availableCredit;
                                if (card.isSharedLimit && card.sharedLimitGroupId) {
                                  // Find the shared limit group
                                  const group = sharedLimitGroups.find(g => g.id === card.sharedLimitGroupId);
                                  if (group) {
                                    // Calculate total usage of all cards in the group
                                    const groupUsage = calculateSharedGroupUsage(group.id);
                                    // Available credit is the group limit minus total usage
                                    availableCredit = group.totalLimit - groupUsage;
                                  } else {
                                    // Fallback to individual card limit if group not found
                                    availableCredit = card.creditLimit - totalOutstanding;
                                  }
                                } else {
                                  // Regular individual card calculation
                                  availableCredit = card.creditLimit - totalOutstanding;
                                }
                                
                                return (
                                  <span className="font-medium text-green-600">
                                    {formatCurrency(availableCredit, false, true)}
                                  </span>
                                );
                              })()}
                            </div>
                          </div>

                          <div className="flex gap-2 mt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-xs flex-1 h-7 px-1.5"
                              onClick={() => window.location.href = '/transactions?account=' + card.name}
                            >
                              <FileText className="h-3.5 w-3.5 mr-1" />
                              <span className="truncate">View Transactions</span>
                            </Button>
                            <Button
                              onClick={() => {
                                setSelectedCard(card);
                                setIsPaymentDialogOpen(true);
                              }}
                              variant="default"
                              size="sm"
                              className="text-xs flex-1 h-7 bg-indigo-600 hover:bg-indigo-700 px-1.5 whitespace-nowrap"
                            >
                              Pay Bill
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Make Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedCard && (
              <>
                <div className="space-y-2">
                  <Label>Card</Label>
                  <p className="text-sm font-medium">{selectedCard.name}</p>
                </div>
                <div className="space-y-2">
                  <Label>Statement Balance</Label>
                  <p className={`text-sm font-medium ${
                    calculateStatementBalance(selectedCard) < 0 ? "text-green-600" : ""
                  }`}>
                    {formatCurrency(calculateStatementBalance(selectedCard), false, true)}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentBankAccount">Pay From Account</Label>
                  <Select
                    value={paymentBankAccount}
                    onValueChange={setPaymentBankAccount}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccountsData.length > 0 ? 
                        bankAccountsData.map((account) => (
                          <SelectItem key={account.id} value={account.name}>
                            {account.name}
                          </SelectItem>
                        )) : 
                        <SelectItem value="" disabled>No accounts available</SelectItem>
                      }
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Amount</Label>
                  <Input
                    id="paymentAmount"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="Enter payment amount"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentDate">Payment Date</Label>
                  <Input
                    id="paymentDate"
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePayment}>
              Make Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Edit Credit Card' : 'Add Credit Card'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="flex items-center gap-2 p-3 bg-red-50 text-red-800 rounded-md">
                <AlertCircle className="h-5 w-5" />
                <p className="text-sm">{formError}</p>
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Card Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Citi Rewards"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bank">Bank Name</Label>
                <Input
                  id="bank"
                  placeholder="e.g., Citibank"
                  value={bank}
                  onChange={(e) => setBank(e.target.value)}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="statementDay">
                  Statement Day
                  <span className="ml-1 text-xs text-gray-500">(of month)</span>
                </Label>
                <Input
                  id="statementDay"
                  type="number"
                  min="1"
                  max="31"
                  placeholder="e.g., 15"
                  value={statementDay}
                  onChange={(e) => setStatementDay(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="daysAfter">
                  Days Until Due
                  <span className="ml-1 text-xs text-gray-500">(after statement)</span>
                </Label>
                <Input
                  id="daysAfter"
                  type="number"
                  min="1"
                  max="60"
                  placeholder="e.g., 21"
                  value={daysAfter}
                  onChange={(e) => setDaysAfter(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="creditLimit">Credit Limit</Label>
              <Input
                id="creditLimit"
                type="number"
                min="0"
                step="0.01"
                placeholder="e.g., 10000"
                value={creditLimit}
                onChange={(e) => setCreditLimit(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 mb-2">
                <Checkbox 
                  id="isSharedLimit" 
                  checked={isSharedLimit}
                  onCheckedChange={(checked) => setIsSharedLimit(checked === true)}
                />
                <Label 
                  htmlFor="isSharedLimit"
                  className="cursor-pointer text-sm font-medium"
                >
                  This card shares credit limit with other cards
                </Label>
              </div>
              
              {isSharedLimit && (
                <div className="space-y-2 ml-6">
                  <Label htmlFor="sharedLimitGroup">Select shared limit group</Label>
                  <Select 
                    value={selectedSharedGroup} 
                    onValueChange={setSelectedSharedGroup}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a shared limit group" />
                    </SelectTrigger>
                    <SelectContent>
                      {sharedLimitGroups.map(group => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.name} - {formatCurrency(group.totalLimit)}
                        </SelectItem>
                      ))}
                      {sharedLimitGroups.length === 0 && (
                        <SelectItem disabled value="none">
                          No shared limit groups available
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  
                  <div className="flex items-center mt-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      type="button"
                      className="text-xs"
                      onClick={() => {
                        resetSharedGroupForm();
                        setIsSharedGroupDialogOpen(true);
                      }}
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Create New Group
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddOrUpdateCard}>
              {isEditMode ? 'Save Changes' : 'Add Card'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Shared Limit Group Dialog */}
      <Dialog open={isSharedGroupDialogOpen} onOpenChange={setIsSharedGroupDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {isEditSharedGroup ? 'Edit Shared Limit Group' : 'Create Shared Limit Group'}
            </DialogTitle>
            <DialogDescription>
              Create a group for credit cards that share a common credit limit
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="flex items-center gap-2 p-3 bg-red-50 text-red-800 rounded-md">
                <AlertCircle className="h-5 w-5" />
                <p className="text-sm">{formError}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="groupName">Group Name</Label>
              <Input
                id="groupName"
                placeholder="e.g., Citibank Cards"
                value={sharedGroupName}
                onChange={(e) => setSharedGroupName(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Usually the bank name that issued the cards
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="totalLimit">Total Credit Limit</Label>
              <Input
                id="totalLimit"
                type="number"
                min="0"
                step="0.01"
                placeholder="e.g., 25000"
                value={sharedGroupLimit}
                onChange={(e) => setSharedGroupLimit(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                The total credit limit shared across all cards in this group
              </p>
            </div>

            {isEditSharedGroup && editSharedGroupId && (
              <div className="space-y-2 pt-2">
                <Label className="text-sm font-medium">Cards in this group</Label>
                <div className="border rounded-md p-3 bg-gray-50">
                  {creditCards
                    .filter(card => card.sharedLimitGroupId === editSharedGroupId)
                    .map(card => (
                      <div key={card.id} className="flex items-center justify-between py-1">
                        <div className="flex items-center">
                          <CreditCardIcon className="h-4 w-4 mr-2 text-primary" />
                          <span>{card.name}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => removeCardFromSharedGroup(card.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ))}
                  {creditCards.filter(card => card.sharedLimitGroupId === editSharedGroupId).length === 0 && (
                    <p className="text-sm text-gray-500 py-1">No cards in this group yet</p>
                  )}
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="sm:justify-between">
            <div className="flex items-center gap-2">
              {isEditSharedGroup && (
                <Button 
                  variant="outline" 
                  className="text-red-500 hover:text-red-700 hover:bg-red-50 border-red-200"
                  onClick={() => {
                    if (editSharedGroupId) {
                      removeSharedLimitGroup(editSharedGroupId);
                      setIsSharedGroupDialogOpen(false);
                      resetSharedGroupForm();
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setIsSharedGroupDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddOrUpdateSharedGroup}>
                {isEditSharedGroup ? 'Save Changes' : 'Create Group'}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Shared Limit Management Dialog */}
      <Dialog open={isSharedLimitManagementOpen} onOpenChange={setIsSharedLimitManagementOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Manage Shared Credit Limits</DialogTitle>
            <DialogDescription>
              Create and manage groups of credit cards that share a common credit limit
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-6">
            {sharedLimitGroups.length === 0 ? (
              <div className="p-6 bg-gray-50 rounded-lg text-center">
                <Building className="h-8 w-8 text-gray-400 mx-auto mb-3" />
                <h3 className="text-base font-medium mb-2">No shared limit groups</h3>
                <p className="text-gray-500 text-sm mb-4">
                  Create a shared limit group for cards issued by the same bank that share a common credit limit
                </p>
                <Button 
                  onClick={() => {
                    resetSharedGroupForm();
                    setIsSharedLimitManagementOpen(false);
                    setIsSharedGroupDialogOpen(true);
                  }}
                  className="mx-auto"
                >
                  <Plus className="h-4 w-4 mr-1" /> Create New Group
                </Button>
              </div>
            ) : (
              <>
                <div className="flex justify-between mb-4">
                  <h3 className="text-base font-medium">Your Shared Limit Groups</h3>
                  <Button 
                    onClick={() => {
                      resetSharedGroupForm();
                      setIsSharedLimitManagementOpen(false);
                      setIsSharedGroupDialogOpen(true);
                    }}
                    variant="outline"
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-1" /> Create New Group
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {sharedLimitGroups.map(group => {
                    const groupUsage = calculateSharedGroupUsage(group.id);
                    const groupCards = creditCards.filter(card => card.sharedLimitGroupId === group.id);
                    const utilization = groupUsage / group.totalLimit;
                    
                    return (
                      <div 
                        key={group.id} 
                        className="p-4 border rounded-lg hover:shadow-sm transition-all"
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="text-base font-semibold">{group.name}</h4>
                            <p className="text-sm text-gray-500">
                              {formatCurrency(group.totalLimit)} shared limit
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditSharedGroup(group)}
                              className="h-8 text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                            >
                              <Edit className="h-3.5 w-3.5 mr-1" /> Edit
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (window.confirm(`Remove "${group.name}" shared limit group? This will reset all cards in this group to individual limits.`)) {
                                  removeSharedLimitGroup(group.id);
                                }
                              }}
                              className="h-8 text-red-600 hover:text-red-800 hover:bg-red-50"
                            >
                              <Trash2 className="h-3.5 w-3.5 mr-1" /> Remove
                            </Button>
                          </div>
                        </div>
                        
                        <div className="space-y-1 mb-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Utilization: {(utilization * 100).toFixed(1)}%</span>
                            <span className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                              utilization <= 0.30 ? "bg-green-100 text-green-800" : 
                              utilization <= 0.50 ? "bg-blue-100 text-blue-800" : 
                              utilization <= 0.75 ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"
                            }`}>
                              {utilization <= 0.30 ? "Low" : 
                              utilization <= 0.50 ? "Good" : 
                              utilization <= 0.75 ? "Moderate" : "High"}
                            </span>
                          </div>
                          <Progress 
                            value={Math.min(utilization * 100, 100)} 
                            className="h-2" 
                            indicatorClassName={`${
                              utilization <= 0.30 ? "bg-green-500" : 
                              utilization <= 0.50 ? "bg-blue-500" : 
                              utilization <= 0.75 ? "bg-amber-500" : "bg-red-500"
                            }`}
                          />
                        </div>
                        
                        <Separator className="my-3" />
                        
                        <div>
                          <h5 className="text-sm font-medium mb-2">Cards in this group</h5>
                          {groupCards.length > 0 ? (
                            <div className="space-y-2">
                              {groupCards.map(card => (
                                <div key={card.id} className="flex justify-between items-center p-2 bg-gray-50 rounded-md text-sm">
                                  <div className="flex items-center">
                                    <CreditCardIcon className="h-4 w-4 mr-2 text-gray-500" />
                                    <span>{card.name}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <span className="text-gray-700">{formatCurrency(calculateCardUsage(card))}</span>
                                    <Button
                                      variant="ghost" 
                                      size="sm"
                                      onClick={() => {
                                        if (window.confirm(`Remove "${card.name}" from this shared limit group?`)) {
                                          removeCardFromSharedGroup(card.id);
                                        }
                                      }}
                                      className="h-6 w-6 p-0 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-gray-500 italic">No cards assigned to this group yet</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSharedLimitManagementOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}