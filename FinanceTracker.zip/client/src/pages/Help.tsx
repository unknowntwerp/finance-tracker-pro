
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, BarChart3, CreditCard, PiggyBank, Tag, FileText, Settings, Calendar, ArrowLeftRight } from "lucide-react";

export default function Help() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <AlertCircle className="h-6 w-6" /> Help & Instructions
        </h1>
      </div>

      <Card>
        <CardContent className="py-6">
          <Tabs defaultValue="getting-started">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
              <TabsTrigger value="accounts">Accounts & Categories</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="features">Advanced Features</TabsTrigger>
            </TabsList>

            <TabsContent value="getting-started" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <Settings className="h-5 w-5" /> Welcome to Your Personal Finance Tracker
                </h2>
                <p className="text-gray-700 mb-4">
                  This application helps you manage your personal finances by tracking your income, expenses, 
                  bank accounts, credit cards, and more. Here's how to get started:
                </p>
                
                <ol className="list-decimal pl-6 space-y-3">
                  <li>
                    <strong>Set up your accounts</strong> - Add your bank accounts and credit cards from their 
                    respective pages in the sidebar.
                  </li>
                  <li>
                    <strong>Create categories</strong> - Before adding transactions, set up expense and income 
                    categories from the Manage Lists page.
                  </li>
                  <li>
                    <strong>Add transactions</strong> - Record your income and expenses in the Transactions page.
                  </li>
                  <li>
                    <strong>Monitor your dashboard</strong> - View your financial summary, charts, and balances in the Dashboard.
                  </li>
                </ol>
              </div>

              <div className="p-5 border border-blue-200 rounded-xl bg-blue-50 flex items-start gap-4">
                <div className="text-blue-500 bg-white p-2 rounded-full shadow-sm">
                  <AlertCircle className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Important Note</h4>
                  <p className="text-gray-700 text-sm">
                    This application stores all data in your browser. To prevent data loss, use the Backup feature 
                    regularly to export your financial data.
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="accounts" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <PiggyBank className="h-5 w-5" /> Bank Accounts
                </h2>
                <p className="text-gray-700 mb-4">
                  Track your checking, savings, and investment accounts:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Bank Accounts</strong> in the sidebar</li>
                  <li>Click <strong>Add Account</strong> to create a new account</li>
                  <li>Enter the account name, type, and current balance</li>
                  <li>View your bank account balances in the Dashboard</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <CreditCard className="h-5 w-5" /> Credit Cards
                </h2>
                <p className="text-gray-700 mb-4">
                  Manage your credit cards and track spending:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Credit Cards</strong> in the sidebar</li>
                  <li>Click <strong>Add Credit Card</strong> to create a new card</li>
                  <li>Enter the card name, limit, and current balance</li>
                  <li>Set up billing cycle information to track payment due dates</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <Tag className="h-5 w-5" /> Managing Categories
                </h2>
                <p className="text-gray-700 mb-4">
                  Categories help organize your transactions:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Manage Lists</strong> in the sidebar</li>
                  <li>Create expense categories (Food, Transport, etc.)</li>
                  <li>Create income categories (Salary, Freelance, etc.)</li>
                  <li>Assign icons to categories for better visualization</li>
                  <li>Edit or delete categories as needed</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="transactions" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <ArrowLeftRight className="h-5 w-5" /> Recording Transactions
                </h2>
                <p className="text-gray-700 mb-4">
                  Keep track of all your income and expenses:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Transactions</strong> in the sidebar</li>
                  <li>Click <strong>Add Transaction</strong> to record a new transaction</li>
                  <li>Select transaction type (Income or Expense)</li>
                  <li>Enter date, description, amount, account, and category</li>
                  <li>Add notes or tags for additional organization</li>
                  <li>Use filters to find specific transactions</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <FileText className="h-5 w-5" /> Bulk Import
                </h2>
                <p className="text-gray-700 mb-4">
                  Save time by importing multiple transactions at once:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Bulk Import</strong> in the sidebar</li>
                  <li>Download the Excel template</li>
                  <li>Fill in your transactions in the template</li>
                  <li>Upload the completed file</li>
                  <li>Review and confirm the imported transactions</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <Calendar className="h-5 w-5" /> Recurring Transactions
                </h2>
                <p className="text-gray-700 mb-4">
                  Set up regular payments or income:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>When adding a transaction, check "Make recurring"</li>
                  <li>Select the frequency (daily, weekly, monthly, etc.)</li>
                  <li>Set the end date or number of occurrences</li>
                  <li>The system will automatically create future transactions</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="features" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" /> Analytics
                </h2>
                <p className="text-gray-700 mb-4">
                  Gain insights into your spending and saving habits:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Analytics</strong> in the sidebar</li>
                  <li>View spending by category</li>
                  <li>Track monthly income vs. expenses</li>
                  <li>Analyze trends over time</li>
                  <li>Identify areas to reduce spending</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <FileText className="h-5 w-5" /> Backup & Restore
                </h2>
                <p className="text-gray-700 mb-4">
                  Protect your financial data:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Backup</strong> in the sidebar</li>
                  <li>Click <strong>Export Data</strong> to download a JSON backup file</li>
                  <li>Store this file securely</li>
                  <li>To restore, click <strong>Import Data</strong> and select your backup file</li>
                  <li>Create regular backups to prevent data loss</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <CreditCard className="h-5 w-5" /> Credit Card Billing Cycles
                </h2>
                <p className="text-gray-700 mb-4">
                  Never miss a payment deadline:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Credit Card Billing Cycle</strong> in the sidebar</li>
                  <li>Set your statement closing date and payment due date</li>
                  <li>The app will calculate your payment window</li>
                  <li>Receive reminders about upcoming payments</li>
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <ArrowLeftRight className="h-5 w-5" /> Receivables & Payables
                </h2>
                <p className="text-gray-700 mb-4">
                  Track money owed to you or that you owe to others:
                </p>
                
                <ul className="list-disc pl-6 space-y-2">
                  <li>Go to <strong>Receivables</strong> in the sidebar</li>
                  <li>Add persons who owe you money or whom you owe</li>
                  <li>Record transactions with the appropriate person</li>
                  <li>Monitor outstanding balances</li>
                  <li>Mark items as paid when settled</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Keyboard Shortcuts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Add new transaction</span>
                <kbd className="px-2 py-1 bg-gray-100 border rounded text-sm">Ctrl + N</kbd>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Search transactions</span>
                <kbd className="px-2 py-1 bg-gray-100 border rounded text-sm">Ctrl + F</kbd>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Go to Dashboard</span>
                <kbd className="px-2 py-1 bg-gray-100 border rounded text-sm">Ctrl + D</kbd>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Save changes</span>
                <kbd className="px-2 py-1 bg-gray-100 border rounded text-sm">Ctrl + S</kbd>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
