import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useFinanceStore, ImportTransaction, Transaction } from "@/lib/transactionStore";
// Also import TransactionSplit in case we need it for transaction display
import type { TransactionSplit } from "@/lib/transactionStore";
import { Building, Plus, ArrowDown, ArrowUp, FileText, AlertCircle, Trash2, 
         MoreHorizontal, CreditCard, Wallet, TrendingUp, TrendingDown, DollarSign,
         ExternalLink, PiggyBank, Pencil, Info as InfoIcon } from "lucide-react";
import { formatCurrency, formatDateFriendly } from "@/lib/formatters";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

// Define BankAccount interface since it's not exported from transactionStore
interface BankAccount {
  id: string;
  name: string;
  createdAt: string;
}

interface ExtendedFinanceStore {
  bankAccountsData: BankAccount[];
  transactions: Transaction[];
  addBankAccountData: (account: { name: string }) => void;
  removeBankAccountData: (id: string) => void;
  updateBankAccount: (id: string, name: string) => void;
  addTransaction: (transaction: ImportTransaction) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
}

export default function BankAccounts() {
  const { 
    bankAccountsData, 
    transactions, 
    addBankAccountData, 
    removeBankAccountData, 
    addTransaction,
    updateBankAccount,
    updateTransaction 
  } = useFinanceStore() as unknown as ExtendedFinanceStore;

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [newBankAccount, setNewBankAccount] = useState("");
  const [newBankBalance, setNewBankBalance] = useState("0");
  const [newOpeningDate, setNewOpeningDate] = useState(new Date().toISOString().split('T')[0]);
  const [editingAccount, setEditingAccount] = useState<{ 
    id: string, 
    name: string, 
    openingBalance: string,
    openingDate: string 
  }>({ 
    id: "", 
    name: "", 
    openingBalance: "0",
    openingDate: new Date().toISOString().split('T')[0]
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [transferSource, setTransferSource] = useState(""); 
  const [transferDestination, setTransferDestination] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferDate, setTransferDate] = useState(new Date().toISOString().split('T')[0]);

  // Define the structure for account balances
  interface AccountBalance {
    id: string;
    balance: number;
    transactions: number;
    monthlyIncome: number;
    monthlyExpense: number;
    recentTransactions: Transaction[];
  }

  // Calculate balances and transactions for each bank account
  const bankBalances: Record<string, AccountBalance> = bankAccountsData.reduce((acc, accountData) => {
    const account = accountData.name;
    const accountTransactions = transactions.filter(t => t.account === account);
    const balance = accountTransactions.reduce((sum, t) => {
      if (t.type === "income" || t.type === "payment") return sum + t.amount;
      if (t.type === "expense") return sum - t.amount;
      if (t.type === "contra") return sum + t.amount; // Handle contra transactions correctly
      return sum;
    }, 0);

    const monthlyIncome = accountTransactions
      .filter(t => t.type === "income" && new Date(t.date).getMonth() === new Date().getMonth())
      .reduce((sum, t) => sum + t.amount, 0);

    const monthlyExpense = accountTransactions
      .filter(t => t.type === "expense" && new Date(t.date).getMonth() === new Date().getMonth())
      .reduce((sum, t) => sum + t.amount, 0);
      
    // Get the last 5 transactions to display
    const recentTransactions = accountTransactions
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 3);

    return {
      ...acc,
      [account]: {
        id: accountData.id,
        balance,
        transactions: accountTransactions.length,
        monthlyIncome,
        monthlyExpense,
        recentTransactions
      }
    };
  }, {});

  const totalBalance: number = Object.values(bankBalances).reduce((sum, account) => sum + (account?.balance || 0), 0);
  
  console.log('BankAccounts page balance calculation:', totalBalance);
  
  // Debug each account balance 
  Object.entries(bankBalances).forEach(([accountName, accountData]) => {
    console.log(`Account ${accountName} balance:`, accountData.balance);
  });

  const handleAddAccount = () => {
    if (!newBankAccount.trim()) {
      setFormError("Bank account name is required");
      return;
    }

    if (bankAccountsData.some(acc => acc.name === newBankAccount)) {
      setFormError("Bank account already exists");
      return;
    }

    addBankAccountData({ name: newBankAccount });
    
    // If opening balance is provided, create an initial balance transaction
    const openingBalance = parseFloat(newBankBalance);
    if (!isNaN(openingBalance) && openingBalance > 0) {
      addTransaction({
        date: newOpeningDate, // Use the opening date provided by the user
        type: "income",
        description: "Opening Balance",
        amount: openingBalance,
        account: newBankAccount,
        category: "Deposit"
      });
    }
    
    setNewBankAccount("");
    setNewBankBalance("0");
    setNewOpeningDate(new Date().toISOString().split('T')[0]);
    setFormError(null);
    setIsDialogOpen(false);
  };
  
  const handleEditAccount = () => {
    if (!editingAccount.name.trim()) {
      setFormError("Bank account name is required");
      return;
    }

    if (bankAccountsData.some(acc => acc.name === editingAccount.name && acc.id !== editingAccount.id)) {
      setFormError("Bank account with this name already exists");
      return;
    }

    // Get the original account name before updating
    const oldAccount = bankAccountsData.find(acc => acc.id === editingAccount.id);
    if (!oldAccount) return;
    
    // Find the opening balance transaction if it exists
    const openingBalanceTx = transactions.find(t => 
      t.account === oldAccount.name && 
      t.description === "Opening Balance" && 
      t.type === "income"
    );

    // Update the account name (this already updates all transaction account names)
    updateBankAccount(editingAccount.id, editingAccount.name);
    
    // Handle opening balance changes if there's a new balance
    const newOpeningBalance = parseFloat(editingAccount.openingBalance);
    
    if (!isNaN(newOpeningBalance) && newOpeningBalance >= 0) {
      if (openingBalanceTx) {
        // If there's an existing opening balance transaction, update its amount and date
        updateTransaction(openingBalanceTx.id, {
          amount: newOpeningBalance,
          date: editingAccount.openingDate // Update the date as well
        });
      } else if (newOpeningBalance > 0) {
        // If there's no opening balance transaction but we have a new amount, create one
        addTransaction({
          date: editingAccount.openingDate, // Use the opening date provided by the user
          type: "income",
          description: "Opening Balance",
          amount: newOpeningBalance,
          account: editingAccount.name,
          category: "Deposit"
        });
      }
    }
    
    setFormError(null);
    setIsEditDialogOpen(false);
  };

  const handleTransfer = () => {
    if (!transferSource || !transferDestination || !transferAmount || !transferDate) {
      return;
    }

    const amount = parseFloat(transferAmount);
    if (isNaN(amount) || amount <= 0) {
      return;
    }

    // Add outgoing transaction from source account
    addTransaction({
      date: transferDate,
      type: "expense", // Changed from "transfer" to "expense"
      description: `Transfer to ${transferDestination}`,
      amount: amount, // Use positive amount
      account: transferSource,
      category: "Transfer"
    });

    // Add incoming transaction to destination account
    addTransaction({
      date: transferDate,
      type: "income", // Changed from "transfer" to "income"
      description: `Transfer from ${transferSource}`,
      amount: amount, // Positive for incoming
      account: transferDestination,
      category: "Transfer"
    });

    setTransferAmount("");
    setTransferSource("");
    setTransferDestination("");
    setTransferDate(new Date().toISOString().split('T')[0]);
    setIsTransferDialogOpen(false);
  };

  // Function to get color for account cards
  const getAccountCardStyle = (account: string, index: number) => {
    const colorClasses = [
      'from-blue-50 to-blue-100 border-blue-200',
      'from-emerald-50 to-emerald-100 border-emerald-200',
      'from-indigo-50 to-indigo-100 border-indigo-200',
      'from-purple-50 to-purple-100 border-purple-200',
      'from-cyan-50 to-cyan-100 border-cyan-200',
      'from-amber-50 to-amber-100 border-amber-200'
    ];
    return colorClasses[index % colorClasses.length];
  };

  return (
    <div className="container px-4 py-6">
      {/* Hero section */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-6">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text">
              Bank Accounts
            </h1>
            <p className="text-gray-600 max-w-xl">
              Manage your accounts and track your balances
            </p>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={() => setIsTransferDialogOpen(true)} 
              variant="outline" 
              className="flex items-center gap-2"
              disabled={bankAccountsData.length < 2}
            >
              <ArrowDown className="mr-2 h-4 w-4 text-blue-600" /> Transfer Funds
            </Button>
            <Button 
              onClick={() => setIsDialogOpen(true)} 
              className="btn-gradient"
            >
              <Plus className="mr-2 h-4 w-4" /> Add Bank Account
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Total Balance Card */}
        <Card className="border border-blue-200 shadow-sm bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-blue-700">Total Balance</h3>
              <div className="h-8 w-8 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center">
                <Wallet className="h-4 w-4 text-blue-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className={cn(
                "text-3xl font-bold", 
                totalBalance >= 0 ? "text-blue-600" : "text-red-600"
              )}>
                {formatCurrency(totalBalance)}
              </p>
              <p className="text-sm text-gray-500">
                Across {bankAccountsData.length} bank {bankAccountsData.length === 1 ? 'account' : 'accounts'}
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Monthly Income Card */}
        <Card className="border border-green-200 shadow-sm bg-gradient-to-br from-green-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-green-700">Monthly Income</h3>
              <div className="h-8 w-8 rounded-full bg-green-100 border border-green-200 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-green-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-3xl font-bold text-green-600">
                {formatCurrency(Object.values(bankBalances).reduce((sum, account) => sum + (account?.monthlyIncome || 0), 0))}
              </p>
              <p className="text-sm text-gray-500">
                This month's deposits
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Monthly Expenses Card */}
        <Card className="border border-red-200 shadow-sm bg-gradient-to-br from-red-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-red-700">Monthly Expenses</h3>
              <div className="h-8 w-8 rounded-full bg-red-100 border border-red-200 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-red-600" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-3xl font-bold text-red-600">
                {formatCurrency(Object.values(bankBalances).reduce((sum, account) => sum + (account?.monthlyExpense || 0), 0))}
              </p>
              <p className="text-sm text-gray-500">
                This month's withdrawals
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {bankAccountsData.length === 0 ? (
        <Card className="border border-blue-200 shadow-sm overflow-hidden">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="rounded-full bg-blue-100 p-4 mb-4 border border-blue-200">
              <Building className="h-12 w-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No Bank Accounts Added</h3>
            <p className="text-gray-600 max-w-md mb-8">
              Add your bank accounts to track balances, monitor transactions, and manage your finances in one place.
            </p>
            <div className="flex gap-3">
              <Button onClick={() => setIsTransferDialogOpen(true)} 
                     variant="outline" 
                     className="border-gray-200 hover:bg-gray-50 transition-colors flex items-center gap-2"
                     disabled={bankAccountsData.length < 2}>
                <ArrowDown className="h-4 w-4 text-blue-600" /> Transfer Funds
              </Button>
              <Button onClick={() => setIsDialogOpen(true)} 
                     className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white flex items-center gap-2">
                <Plus className="h-4 w-4" /> Add Bank Account
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {bankAccountsData
            .sort((a, b) => {
              // Sort by balance in descending order (highest balance first)
              const balanceA = bankBalances[a.name]?.balance || 0;
              const balanceB = bankBalances[b.name]?.balance || 0;
              return balanceB - balanceA;
            })
            .map((accountData, index) => {
              const account = accountData.name;
              const balanceData = bankBalances[account];
              const cardColorClass = getAccountCardStyle(account, index);
              
              return (
              <Card key={accountData.id} className={cn(
                "group hover:shadow-md transition-all duration-300 border overflow-hidden bg-gradient-to-br", 
                cardColorClass
              )}>
                {/* Compact Header with Account Name, Balance, and Buttons */}
                <div className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-7 w-7 rounded-full bg-white/80 border border-current flex items-center justify-center text-blue-600 flex-shrink-0">
                      <Building className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex flex-col">
                      <h3 className="font-medium text-sm leading-none mb-1">{account}</h3>
                      <p className="text-xs text-gray-500 leading-none">{balanceData?.transactions || 0} transactions</p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-1">
                    <Badge variant="outline" className={cn(
                      "px-1.5 py-0.5 text-xs font-medium border",
                      balanceData?.balance >= 0 
                        ? "bg-green-100 text-green-700 border-green-200" 
                        : "bg-red-100 text-red-700 border-red-200"
                    )}>
                      {balanceData?.balance >= 0 ? 'Active' : 'Overdrawn'}
                    </Badge>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const openingBalanceTx = transactions.find(t => 
                            t.account === account && 
                            t.description === "Opening Balance" && 
                            t.type === "income"
                          );
                          setEditingAccount({ 
                            id: accountData.id, 
                            name: account,
                            openingBalance: openingBalanceTx ? openingBalanceTx.amount.toString() : "0",
                            openingDate: openingBalanceTx ? openingBalanceTx.date : new Date().toISOString().split('T')[0]
                          });
                          setIsEditDialogOpen(true);
                        }}
                        className="p-1 h-6 w-6 rounded-full text-blue-600 bg-blue-50 hover:bg-blue-100"
                        title="Edit Account"
                      >
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeBankAccountData(accountData.id)}
                        className="p-1 h-6 w-6 rounded-full text-red-600 bg-red-50 hover:bg-red-100"
                        title="Delete Account"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Main content area */}
                <div className="px-3 pb-3">
                  {/* Balance display */}
                  <div className="flex flex-col items-center mb-3 p-2 bg-white/80 rounded-lg shadow-inner border border-current/10">
                    <p className="text-xs font-medium text-gray-600">Balance</p>
                    <p className={cn(
                      "text-lg font-bold",
                      balanceData?.balance >= 0 ? "text-green-600" : "text-red-600"
                    )}>
                      {formatCurrency(balanceData?.balance || 0)}
                    </p>
                  </div>
                  
                  {/* Monthly inflows/outflows summary */}
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    {/* Inflows */}
                    <div className="bg-white/70 rounded-lg p-2 text-center">
                      <p className="text-xs text-gray-600">Inflows</p>
                      <p className="font-medium text-sm text-green-600">
                        {formatCurrency(balanceData?.monthlyIncome || 0)}
                      </p>
                    </div>
                    {/* Outflows */}
                    <div className="bg-white/70 rounded-lg p-2 text-center">
                      <p className="text-xs text-gray-600">Outflows</p>
                      <p className="font-medium text-sm text-red-600">
                        {formatCurrency(balanceData?.monthlyExpense || 0)}
                      </p>
                    </div>
                  </div>
                  
                  {/* Recent Transactions - Compact List */}
                  {balanceData?.recentTransactions && balanceData.recentTransactions.length > 0 && (
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <h4 className="text-xs font-medium text-gray-500">Recent Transactions</h4>
                        <Link href={`/transactions?account=${encodeURIComponent(account)}`} className="text-xs text-blue-600 hover:underline flex items-center">
                          <span>View All</span>
                          <FileText className="h-3 w-3 ml-1" />
                        </Link>
                      </div>
                      
                      {/* Transaction list - limited to 2 transactions */}
                      <div className="space-y-1.5">
                        {balanceData.recentTransactions.slice(0, 2).map((transaction: any) => (
                          <div key={transaction.id} className="flex items-center justify-between p-2 rounded-md bg-white/60 border border-current/10">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <div className={cn(
                                "w-2 h-2 rounded-full flex-shrink-0",
                                transaction.type === "income" ? "bg-green-500" : "bg-red-500"
                              )} />
                              <div className="min-w-0">
                                <p className="text-sm font-medium truncate">{transaction.description}</p>
                                <p className="text-xs text-gray-500">{formatDateFriendly(transaction.date, 'short')}</p>
                              </div>
                            </div>
                            <span className={cn(
                              "text-sm font-semibold ml-2 flex-shrink-0",
                              transaction.type === "income" ? "text-green-600" : "text-red-600"
                            )}>
                              {transaction.type === "income" ? "+" : "-"}
                              {formatCurrency(Math.abs(transaction.amount))}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Bank Account Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md border border-blue-200 shadow-md">
          <DialogHeader className="pb-1">
            <DialogTitle className="text-xl flex items-center gap-2 text-blue-700">
              <Building className="h-5 w-5" /> Add Bank Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700 border border-red-200">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-gray-700">Account Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., HDFC Savings, SBI Current"
                  value={newBankAccount}
                  onChange={(e) => setNewBankAccount(e.target.value)}
                  className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter a unique, descriptive name for your bank account
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="initialBalance" className="text-gray-700">Opening Balance (Optional)</Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500">₹</span>
                  </div>
                  <Input
                    id="initialBalance"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={newBankBalance}
                    onChange={(e) => setNewBankBalance(e.target.value)}
                    className="pl-7 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  If you'd like to set an initial balance for this account
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="openingDate" className="text-gray-700">Opening Balance Date</Label>
                <Input
                  id="openingDate"
                  type="date"
                  value={newOpeningDate}
                  onChange={(e) => setNewOpeningDate(e.target.value)}
                  className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The date when the opening balance was recorded
                </p>
              </div>
            </div>
          </div>
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => setIsDialogOpen(false)}
              className="border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAddAccount}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Plus className="h-4 w-4 mr-2" /> Add Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Funds Dialog */}
      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent className="sm:max-w-md border border-blue-200 shadow-md">
          <DialogHeader className="pb-1">
            <DialogTitle className="text-xl flex items-center gap-2 text-blue-700">
              <ArrowDown className="h-5 w-5" /> Transfer Funds
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4 mb-2">
              <div className="space-y-2">
                <Label htmlFor="transferSource" className="text-gray-700">From Account</Label>
                <Select value={transferSource} onValueChange={setTransferSource}>
                  <SelectTrigger className="border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccountsData.map((account) => (
                      <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="transferDestination" className="text-gray-700">To Account</Label>
                <Select value={transferDestination} onValueChange={setTransferDestination}>
                  <SelectTrigger className="border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Select destination" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccountsData
                      .filter(account => account.name !== transferSource)
                      .map((account) => (
                        <SelectItem key={account.id} value={account.name}>{account.name}</SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-sm text-blue-700 mb-2">
              <p className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
                <span>This will create two transactions - a withdrawal from the source account and a deposit to the destination account.</span>
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="transferAmount" className="text-gray-700">Amount</Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500">₹</span>
                  </div>
                  <Input
                    id="transferAmount"
                    type="number"
                    placeholder="0.00"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="pl-7 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="transferDate" className="text-gray-700">Transfer Date</Label>
                <Input
                  id="transferDate"
                  type="date"
                  value={transferDate}
                  onChange={(e) => setTransferDate(e.target.value)}
                  className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => setIsTransferDialogOpen(false)}
              className="border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleTransfer}
              disabled={!transferSource || !transferDestination || !transferAmount || parseFloat(transferAmount) <= 0}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <ArrowDown className="h-4 w-4 mr-2" /> Complete Transfer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Bank Account Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md border border-blue-200 shadow-md">
          <DialogHeader className="pb-1">
            <DialogTitle className="text-xl flex items-center gap-2 text-blue-700">
              <Pencil className="h-5 w-5" /> Edit Bank Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700 border border-red-200">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="editName" className="text-gray-700">Account Name</Label>
                <Input
                  id="editName"
                  placeholder="e.g., HDFC Savings, SBI Current"
                  value={editingAccount.name}
                  onChange={(e) => setEditingAccount({ ...editingAccount, name: e.target.value })}
                  className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter a unique, descriptive name for your bank account
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="editInitialBalance" className="text-gray-700">Opening Balance</Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500">₹</span>
                  </div>
                  <Input
                    id="editInitialBalance"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={editingAccount.openingBalance}
                    onChange={(e) => setEditingAccount({ ...editingAccount, openingBalance: e.target.value })}
                    className="pl-7 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Initial balance when account was created
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="editOpeningDate" className="text-gray-700">Opening Balance Date</Label>
                <Input
                  id="editOpeningDate"
                  type="date"
                  value={editingAccount.openingDate}
                  onChange={(e) => setEditingAccount({ ...editingAccount, openingDate: e.target.value })}
                  className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The date when the opening balance was recorded
                </p>
              </div>
              
              <p className="text-xs text-blue-600 mt-2 bg-blue-50 p-2 rounded-md border border-blue-100">
                <InfoIcon className="h-3.5 w-3.5 inline-block mr-1" />
                Note: Changing the opening balance or date will update the initial "Opening Balance" transaction.
              </p>
            </div>
          </div>
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleEditAccount}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              <Pencil className="h-4 w-4 mr-2" /> Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}