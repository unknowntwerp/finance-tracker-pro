import { useEffect, useState } from "react";

export default function Home() {
  const [environment, setEnvironment] = useState("loading...");

  useEffect(() => {
    // Fetch environment info from the server
    fetch("/api/environment")
      .then((res) => res.json())
      .then((data) => {
        setEnvironment(data.environment);
      })
      .catch(() => {
        setEnvironment("unknown");
      });
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen flex items-center justify-center">
      <div className="text-center p-8">
        <h1 className="text-5xl md:text-7xl font-bold text-primary mb-4 tracking-tight">
          Hello World
        </h1>
        <p className="text-gray-600">Served with Node.js</p>
        <div className="mt-6 p-4 bg-white shadow-md rounded-lg text-sm text-gray-500 max-w-md mx-auto">
          <p className="mb-2">
            <span className="font-semibold">Server Status:</span>{" "}
            <span className="text-green-500">Running</span>
          </p>
          <p>
            <span className="font-semibold">Environment:</span>{" "}
            <span>{environment}</span>
          </p>
        </div>
      </div>
    </div>
  );
}
