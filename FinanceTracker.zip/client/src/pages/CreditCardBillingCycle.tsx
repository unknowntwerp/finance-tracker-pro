import { Link } from "wouter";
import { 
  ArrowUpRight, 
  CreditCard, 
  Calendar,
  Clock,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  CalendarRange,
  ShieldCheck,
  ExternalLink
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function CreditCardBillingCycle() {
  return (
    <div className="flex flex-col gap-6">
      {/* Hero section */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-2">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text">
              Understanding Credit Card Billing Cycles
            </h1>
            <p className="text-gray-600 max-w-xl">
              A comprehensive guide to how billing cycles work, key dates to remember, and strategies to maximize your grace period.
            </p>
          </div>

          <div className="flex gap-3">
            <Link href="/credit-cards">
              <Button className="btn-gradient">
                <CreditCard className="mr-2 h-4 w-4" /> Manage Cards
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="outline">
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Table of Contents */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card className="stat-card border-t-4 border-royal sticky top-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-royal" />
                <span>In This Guide</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <nav className="flex flex-col space-y-1">
                <a href="#what-is-billing-cycle" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  What is a Billing Cycle?
                </a>
                <a href="#key-dates" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  Key Dates to Remember
                </a>
                <a href="#grace-period" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  Understanding Grace Period
                </a>
                <a href="#billing-timeline" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  Complete Billing Timeline
                </a>
                <a href="#payment-strategies" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  Payment Strategies
                </a>
                <a href="#faq" className="p-2 text-gray-700 hover:text-royal hover:bg-blue-50 rounded-md transition-colors">
                  Frequently Asked Questions
                </a>
              </nav>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3 space-y-6">
          {/* What is a Billing Cycle Section */}
          <section id="what-is-billing-cycle" className="chart-container fade-in">
            <h2 className="heading-with-line">What is a Credit Card Billing Cycle?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="stat-card border-t-4 border-royal">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <CalendarRange className="mr-2 h-5 w-5 text-royal" />
                    <span>Time Period</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    A recurring period (typically 28-31 days) during which all your credit card transactions are recorded.
                  </p>
                </CardContent>
              </Card>

              <Card className="stat-card border-t-4 border-coral">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Calendar className="mr-2 h-5 w-5 text-coral" />
                    <span>Statement Date</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    The last day of your billing cycle when your statement is generated, showing all transactions made during that cycle.
                  </p>
                </CardContent>
              </Card>

              <Card className="stat-card border-t-4 border-lime">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Clock className="mr-2 h-5 w-5 text-lime" />
                    <span>Due Date</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    The deadline by which you must pay at least the minimum payment to avoid late fees and penalties.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="my-6 p-6 bg-blue-50 rounded-xl border border-blue-100">
              <div className="flex gap-4 items-start">
                <div className="text-royal bg-white p-3 rounded-full shadow-sm">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Important to Understand</h4>
                  <p className="text-gray-700">
                    Your billing cycle is not the same as a calendar month. It's a specific period set by your credit card issuer. 
                    For example, your billing cycle might run from the 15th of one month to the 14th of the next.
                  </p>
                </div>
              </div>
            </div>

            <p className="text-gray-700 mb-4">
              Every credit card has a billing cycle, which is the period of time between billing statements. This cycle determines when your transactions will appear on your statement and when you'll need to pay for those transactions.
            </p>

            <p className="text-gray-700 mb-4">
              Most credit card billing cycles range from 28 to 31 days, typically closing on the same date each month. The transactions you make during this period are compiled into your monthly statement, which will show:
            </p>

            <ul className="list-disc pl-6 mb-6 text-gray-700 space-y-2">
              <li>All purchases made during that billing cycle</li>
              <li>Any payments you've made to your account</li>
              <li>Interest charges and fees (if applicable)</li>
              <li>Your new balance</li>
              <li>Minimum payment required</li>
              <li>Payment due date</li>
            </ul>
          </section>

          {/* Key Dates Section */}
          <section id="key-dates" className="chart-container scale-in">
            <h2 className="heading-with-line">Key Dates to Remember</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Card className="dashboard-card">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-full bg-blue-100 text-royal">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-1">Statement Closing Date</h3>
                    <p className="text-gray-600 text-sm">
                      This marks the end of your billing cycle. Transactions after this date will appear on your next statement.
                    </p>
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Example:</span> If your statement closes on the 15th of each month, purchases made on the 16th will appear on the following month's statement.
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="dashboard-card">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-full bg-coral-100 text-coral">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-1">Payment Due Date</h3>
                    <p className="text-gray-600 text-sm">
                      The deadline by which you must make at least the minimum payment to avoid late fees.
                    </p>
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Example:</span> If your payment is due on the 10th, you must make at least the minimum payment by 5PM on that day to avoid penalties.
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            <div className="p-5 border border-gray-200 rounded-xl bg-white mb-6">
              <h4 className="text-lg font-semibold mb-4">The Typical Timeline</h4>
              <div className="relative">
                <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                
                <div className="relative pl-10 pb-6">
                  <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">1</div>
                  <h5 className="font-semibold text-gray-800">Start of Billing Cycle</h5>
                  <p className="text-gray-600 text-sm">Your new billing cycle begins, and all new transactions start being recorded.</p>
                </div>
                
                <div className="relative pl-10 pb-6">
                  <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">2</div>
                  <h5 className="font-semibold text-gray-800">Statement Closing Date (End of Billing Cycle)</h5>
                  <p className="text-gray-600 text-sm">Your statement is generated, showing all transactions during this cycle.</p>
                </div>
                
                <div className="relative pl-10 pb-6">
                  <div className="absolute left-0 w-6 h-6 rounded-full bg-coral text-white flex items-center justify-center">3</div>
                  <h5 className="font-semibold text-gray-800">Grace Period</h5>
                  <p className="text-gray-600 text-sm">Typically 21-25 days during which you can pay your balance without incurring interest charges.</p>
                </div>
                
                <div className="relative pl-10">
                  <div className="absolute left-0 w-6 h-6 rounded-full bg-coral text-white flex items-center justify-center">4</div>
                  <h5 className="font-semibold text-gray-800">Payment Due Date</h5>
                  <p className="text-gray-600 text-sm">Deadline to pay at least the minimum amount due to avoid late fees.</p>
                </div>
              </div>
            </div>

            <div className="p-5 border border-lime-200 rounded-xl bg-lime-50 flex items-start gap-4">
              <div className="text-lime bg-white p-2 rounded-full shadow-sm">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-1">Pro Tip</h4>
                <p className="text-gray-700 text-sm">
                  Mark these key dates in your calendar or set up automatic reminders. Most credit card issuers also offer email or text alerts for upcoming due dates.
                </p>
              </div>
            </div>
          </section>

          {/* Grace Period Section */}
          <section id="grace-period" className="chart-container fade-in">
            <h2 className="heading-with-line">Understanding the Grace Period</h2>
            
            <div className="bg-white p-6 rounded-xl border border-gray-200 mb-6">
              <h3 className="text-xl font-semibold mb-3 text-gray-800">What is a Grace Period?</h3>
              <p className="text-gray-700 mb-4">
                A grace period is the time between the end of your billing cycle (statement closing date) and your payment due date. During this period, you can pay off your new purchases in full without incurring any interest charges.
              </p>
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 mb-4">
                <p className="text-sm text-gray-700">
                  <span className="font-semibold">Important:</span> Grace periods typically only apply to new purchases, not to cash advances or balance transfers.
                </p>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Typical Grace Period Length</h4>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                <div className="bg-royal h-2.5 rounded-full" style={{ width: "75%" }}></div>
              </div>
              <div className="flex justify-between text-xs text-gray-600 mb-4">
                <span>0 days</span>
                <span>15 days</span>
                <span>21 days (Minimum required by law)</span>
                <span>30 days</span>
              </div>
              <p className="text-gray-700 mb-2">
                By law, credit card issuers that offer a grace period must provide at least 21 days from when your statement is made available to you. Most grace periods range from 21 to 25 days.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card className="dashboard-card border-l-4 border-lime">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-gray-800">How to Keep Your Grace Period</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex gap-3">
                      <CheckCircle2 className="h-5 w-5 text-lime shrink-0" />
                      <span className="text-gray-700 text-sm">Pay your statement balance in full by the due date each month</span>
                    </li>
                    <li className="flex gap-3">
                      <CheckCircle2 className="h-5 w-5 text-lime shrink-0" />
                      <span className="text-gray-700 text-sm">Set up automatic payments for at least the full statement balance</span>
                    </li>
                    <li className="flex gap-3">
                      <CheckCircle2 className="h-5 w-5 text-lime shrink-0" />
                      <span className="text-gray-700 text-sm">Keep track of your spending to ensure you can pay in full</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="dashboard-card border-l-4 border-coral">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-gray-800">How You Lose Your Grace Period</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex gap-3">
                      <AlertCircle className="h-5 w-5 text-coral shrink-0" />
                      <span className="text-gray-700 text-sm">Making only the minimum payment or partial payments</span>
                    </li>
                    <li className="flex gap-3">
                      <AlertCircle className="h-5 w-5 text-coral shrink-0" />
                      <span className="text-gray-700 text-sm">Missing a payment entirely</span>
                    </li>
                    <li className="flex gap-3">
                      <AlertCircle className="h-5 w-5 text-coral shrink-0" />
                      <span className="text-gray-700 text-sm">Taking cash advances (these typically have no grace period)</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="p-5 border border-gray-200 rounded-xl bg-white mb-4">
              <h4 className="text-lg font-semibold mb-3">Restoring Your Grace Period</h4>
              <p className="text-gray-700 mb-4">
                If you've lost your grace period by carrying a balance, most credit card issuers will restore it after you've paid your balance in full for one or two consecutive billing cycles.
              </p>
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h5 className="font-semibold text-gray-800 mb-1">During this time:</h5>
                <ul className="list-disc pl-6 text-sm text-gray-700">
                  <li>Interest will be charged on new purchases from the date of purchase</li>
                  <li>You'll continue accruing interest on any existing balance</li>
                  <li>Paying in full for 1-2 consecutive cycles typically restores the grace period</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Billing Timeline Visualization */}
          <section id="billing-timeline" className="chart-container scale-in">
            <h2 className="heading-with-line">Complete Billing Cycle Timeline</h2>
            
            <div className="p-6 bg-white rounded-xl border border-gray-200 mb-6 overflow-x-auto">
              <div className="min-w-[800px]">
                <div className="relative h-20 mb-8">
                  {/* Timeline bar */}
                  <div className="absolute top-10 left-0 right-0 h-2 bg-gray-200 rounded-full"></div>
                  
                  {/* Day 1 */}
                  <div className="absolute top-0 left-0">
                    <div className="w-5 h-5 bg-royal rounded-full absolute top-8 left-1/2 transform -translate-x-1/2"></div>
                    <div className="absolute top-16 -left-10 w-28 text-center">
                      <p className="font-semibold text-sm text-gray-800">Day 1</p>
                      <p className="text-xs text-gray-600">Billing Cycle Starts</p>
                    </div>
                  </div>
                  
                  {/* Day 30 */}
                  <div className="absolute top-0 left-1/3">
                    <div className="w-5 h-5 bg-royal rounded-full absolute top-8 left-1/2 transform -translate-x-1/2"></div>
                    <div className="absolute top-16 -left-10 w-28 text-center">
                      <p className="font-semibold text-sm text-gray-800">Day 30</p>
                      <p className="text-xs text-gray-600">Statement Date</p>
                    </div>
                  </div>
                  
                  {/* Day 50 */}
                  <div className="absolute top-0 left-2/3">
                    <div className="w-5 h-5 bg-coral rounded-full absolute top-8 left-1/2 transform -translate-x-1/2"></div>
                    <div className="absolute top-16 -left-10 w-28 text-center">
                      <p className="font-semibold text-sm text-gray-800">Day 50</p>
                      <p className="text-xs text-gray-600">Payment Due Date</p>
                    </div>
                  </div>
                  
                  {/* Day 60 */}
                  <div className="absolute top-0 right-0">
                    <div className="w-5 h-5 bg-royal rounded-full absolute top-8 left-1/2 transform -translate-x-1/2"></div>
                    <div className="absolute top-16 -left-10 w-28 text-center">
                      <p className="font-semibold text-sm text-gray-800">Day 60</p>
                      <p className="text-xs text-gray-600">Next Billing Cycle</p>
                    </div>
                  </div>
                  
                  {/* Periods */}
                  <div className="absolute top-4 left-[16%] right-[66%] h-3 bg-blue-100 rounded-full opacity-60"></div>
                  <div className="absolute top-4 left-[33%] right-[33%] h-3 bg-lime-100 rounded-full opacity-60"></div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="p-4 border border-blue-100 rounded-lg bg-blue-50">
                    <h4 className="font-semibold text-gray-800 flex items-center mb-2">
                      <div className="w-3 h-3 bg-blue-100 mr-2 rounded-full"></div>
                      Billing Cycle (Days 1-30)
                    </h4>
                    <p className="text-sm text-gray-700">
                      All transactions during this period are recorded and will appear on your monthly statement. This includes purchases, payments, refunds, and any fees or interest charges.
                    </p>
                  </div>
                  
                  <div className="p-4 border border-lime-100 rounded-lg bg-lime-50">
                    <h4 className="font-semibold text-gray-800 flex items-center mb-2">
                      <div className="w-3 h-3 bg-lime-100 mr-2 rounded-full"></div>
                      Grace Period (Days 30-50)
                    </h4>
                    <p className="text-sm text-gray-700">
                      The period between your statement date and payment due date. If you pay your statement balance in full by the due date, you won't be charged interest on new purchases made during the previous billing cycle.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-5 border border-gray-200 rounded-xl bg-blue-50">
              <div className="flex gap-4 items-start">
                <div className="text-royal bg-white p-3 rounded-full shadow-sm">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Real-World Example</h4>
                  <p className="text-gray-700 mb-3">
                    Let's say your billing cycle runs from January 1 to January 30, with a payment due date of February 19:
                  </p>
                  <ul className="list-disc pl-6 text-gray-700 space-y-1">
                    <li>Any purchases between Jan 1-30 will appear on your January statement</li>
                    <li>Your statement closes on Jan 30, and you have until Feb 19 to pay</li>
                    <li>This gives you a 20-day grace period to pay without incurring interest</li>
                    <li>Purchases made between Jan 31-Feb 19 will appear on your February statement</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Payment Strategies */}
          <section id="payment-strategies" className="chart-container fade-in">
            <h2 className="heading-with-line">Smart Payment Strategies</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card className="dashboard-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <ShieldCheck className="mr-2 h-5 w-5 text-royal" />
                    <span>Avoiding Interest Charges</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex gap-3 items-start">
                      <div className="bg-royal text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                      <div>
                        <p className="font-medium text-gray-800">Pay in Full Every Month</p>
                        <p className="text-sm text-gray-600">Always pay your statement balance in full by the due date to avoid interest charges.</p>
                      </div>
                    </li>
                    <Separator />
                    <li className="flex gap-3 items-start">
                      <div className="bg-royal text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                      <div>
                        <p className="font-medium text-gray-800">Set Up Automatic Payments</p>
                        <p className="text-sm text-gray-600">Configure automatic payments for the full statement balance to ensure you never miss a due date.</p>
                      </div>
                    </li>
                    <Separator />
                    <li className="flex gap-3 items-start">
                      <div className="bg-royal text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                      <div>
                        <p className="font-medium text-gray-800">Pay Early</p>
                        <p className="text-sm text-gray-600">Don't wait until the last minute. Pay a few days before the due date to avoid processing delays.</p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="dashboard-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <DollarSign className="mr-2 h-5 w-5 text-lime" />
                    <span>Managing Cash Flow</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex gap-3 items-start">
                      <div className="bg-lime text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                      <div>
                        <p className="font-medium text-gray-800">Time Large Purchases Strategically</p>
                        <p className="text-sm text-gray-600">Make large purchases right after your statement closes to maximize your time before payment is due.</p>
                      </div>
                    </li>
                    <Separator />
                    <li className="flex gap-3 items-start">
                      <div className="bg-lime text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                      <div>
                        <p className="font-medium text-gray-800">Multiple Payment Approach</p>
                        <p className="text-sm text-gray-600">Make smaller payments throughout the month instead of one large payment if that helps your cash flow.</p>
                      </div>
                    </li>
                    <Separator />
                    <li className="flex gap-3 items-start">
                      <div className="bg-lime text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                      <div>
                        <p className="font-medium text-gray-800">Budget for Next Month's Payment</p>
                        <p className="text-sm text-gray-600">When your statement arrives, immediately set aside the payment amount in your budget.</p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="p-6 bg-white rounded-xl border border-gray-200 mb-6">
              <h3 className="text-xl font-semibold mb-4 text-gray-800">Maximizing Your Interest-Free Period</h3>
              <p className="text-gray-700 mb-4">
                By understanding your billing cycle, you can maximize the amount of time you have before you need to pay for purchases.
              </p>
              
              <div className="bg-gray-50 p-5 rounded-lg border border-gray-100 mb-4">
                <h4 className="font-semibold text-gray-800 mb-3">Example: Maximizing Your Interest-Free Time</h4>
                <div className="relative">
                  <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                  
                  <div className="relative pl-10 pb-4">
                    <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">1</div>
                    <p className="text-gray-700">Your billing cycle runs from the 1st to the 30th of each month.</p>
                  </div>
                  
                  <div className="relative pl-10 pb-4">
                    <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">2</div>
                    <p className="text-gray-700">Your payment due date is the 25th of the following month.</p>
                  </div>
                  
                  <div className="relative pl-10 pb-4">
                    <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">3</div>
                    <p className="text-gray-700">If you make a purchase on the 2nd, it will appear on that month's statement, and you'll have about 23 days to pay for it interest-free.</p>
                  </div>
                  
                  <div className="relative pl-10">
                    <div className="absolute left-0 w-6 h-6 rounded-full bg-royal text-white flex items-center justify-center">4</div>
                    <p className="text-gray-700">But if you make a purchase on the 29th, it will still appear on that month's statement, but you'll have about 55 days before you need to pay for it (25 days in the next month plus 30 days of the next billing cycle).</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-lime-50 rounded-lg border border-lime-200">
                <div className="flex gap-3 items-start">
                  <CheckCircle2 className="h-5 w-5 text-lime shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    <span className="font-semibold">Pro Tip:</span> For planned large purchases, try to time them right after your statement closes to get the maximum interest-free period (potentially up to 55 days depending on your card).
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* FAQ Section */}
          <section id="faq" className="chart-container scale-in">
            <h2 className="heading-with-line">Frequently Asked Questions</h2>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  What happens if I only make the minimum payment?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  If you only make the minimum payment, you'll be charged interest on the remaining balance. You'll also lose your grace period for new purchases, meaning interest will start accruing immediately on new transactions until you pay your balance in full for one or two consecutive billing cycles.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  Does my billing cycle date ever change?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  Usually, your billing cycle remains consistent from month to month. However, credit card issuers may occasionally adjust billing cycle dates for operational reasons or upon customer request. If your billing cycle date changes, your issuer should notify you in advance.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  Do all credit cards have a grace period?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  No, not all credit cards offer a grace period. While most do, some cards, particularly those designed for people with lower credit scores, might not. Always check your cardholder agreement to understand if your card offers a grace period and how it works.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  What's the difference between the statement balance and current balance?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  The statement balance is the total amount you owed at the end of your billing cycle. The current balance includes all transactions since your statement was generated. To avoid interest, you need to pay the statement balance in full by the due date, not necessarily the current balance.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-5">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  Can I change my due date?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  Yes, many credit card issuers allow you to change your payment due date to one that better aligns with your personal financial situation, such as after you receive your paycheck. Contact your credit card issuer directly to request a due date change.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-6">
                <AccordionTrigger className="text-left font-medium text-gray-800 hover:text-royal">
                  Do cash advances follow the same billing cycle rules?
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  No, cash advances typically do not receive a grace period. Interest begins accruing immediately from the date of the cash advance, and often at a higher rate than regular purchases. Additionally, cash advances usually incur a transaction fee.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </section>

          {/* Summary and Resources */}
          <section className="chart-container fade-in">
            <h2 className="heading-with-line">Summary</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="p-5 bg-white rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold mb-3 text-gray-800">Key Takeaways</h3>
                <ul className="space-y-2">
                  <li className="flex gap-3">
                    <CheckCircle2 className="h-5 w-5 text-royal shrink-0" />
                    <span className="text-gray-700">Understand your billing cycle dates and payment due dates</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="h-5 w-5 text-royal shrink-0" />
                    <span className="text-gray-700">Pay your statement balance in full to avoid interest charges</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="h-5 w-5 text-royal shrink-0" />
                    <span className="text-gray-700">Use the grace period to your advantage for large purchases</span>
                  </li>
                  <li className="flex gap-3">
                    <CheckCircle2 className="h-5 w-5 text-royal shrink-0" />
                    <span className="text-gray-700">Set up payment reminders or automatic payments</span>
                  </li>
                </ul>
              </div>
              
              <div className="p-5 bg-white rounded-xl border border-gray-200">
                <h3 className="text-lg font-semibold mb-3 text-gray-800">Additional Resources</h3>
                <ul className="space-y-3">
                  <li className="flex gap-3">
                    <ExternalLink className="h-5 w-5 text-royal shrink-0" />
                    <a href="#" className="text-royal hover:underline">How to Read Your Credit Card Statement</a>
                  </li>
                  <li className="flex gap-3">
                    <ExternalLink className="h-5 w-5 text-royal shrink-0" />
                    <a href="#" className="text-royal hover:underline">Understanding Credit Card Interest Calculation</a>
                  </li>
                  <li className="flex gap-3">
                    <ExternalLink className="h-5 w-5 text-royal shrink-0" />
                    <a href="#" className="text-royal hover:underline">Strategies to Pay Off Credit Card Debt</a>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="p-6 bg-gradient-to-r from-royal to-violet rounded-xl text-white">
              <h3 className="text-xl font-bold mb-2">Stay Informed, Stay in Control</h3>
              <p className="mb-4">
                Understanding your credit card billing cycle is a crucial step in managing your finances effectively.
                By knowing when your billing cycle starts and ends, when your payment is due, and how the grace period works,
                you can make informed decisions that help you avoid unnecessary interest charges and fees.
              </p>
              <Link href="/dashboard">
                <Button variant="outline" className="bg-white text-royal hover:bg-blue-50">
                  Return to Dashboard
                </Button>
              </Link>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}