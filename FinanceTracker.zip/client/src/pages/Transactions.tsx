import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Clipboard, Trash2, FileDown, FileUp, Filter, ChevronDown, Calendar, Pencil as PencilIcon, CheckCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useFinanceStore, Transaction, ImportTransaction } from "@/lib/transactionStore";
import { formatCurrency } from "@/lib/formatters";
import { exportTransactionsToExcel } from "@/lib/excelUtils";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Alert } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { renderCategoryIcon, getDefaultCategoryIcon } from "@/lib/categoryIcons";
import BulkImportForm from "@/components/BulkImportForm";
import ImportModal from "@/components/ImportModal";
import AddTransactionForm from "@/components/AddTransactionForm";


const formatDate = (dateStr: string) => {
  try {
    const date = new Date(dateStr);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  } catch (e) {
    return dateStr;
  }
};

export default function Transactions() {
  const { transactions, removeTransaction, removeTransactions } = useFinanceStore();

  // Import Modal state
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);

  // Sort and filter states
  const [sortField, setSortField] = useState<'date' | 'amount' | 'category'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filterText, setFilterText] = useState('');
  const [periodFilter, setPeriodFilter] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Transaction editing state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTransactionId, setEditingTransactionId] = useState<string | null>(null);
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<string>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState('');

  // Function to reset the form and open the add transaction modal
  const openAddTransactionModal = () => {
    // Reset form fields for a new transaction and use the AddTransactionForm component
    setEditingTransactionId(null);
    setTransactionType('expense');
    setIsAddModalOpen(true);
  };

  // No longer need to listen for global event as it's handled by MainLayout

  // Intentionally removed split transaction state
  
  // Selection state for bulk actions
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);

  // Get filters from URL query parameters
  const queryParams = new URLSearchParams(window.location.search);
  const accountFilter = queryParams.get('account');
  const personFilter = queryParams.get('personFilter');

  // Filter transactions based on selected criteria
  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((transaction) => {
        // Text filter
        if (filterText && !transaction.description.toLowerCase().includes(filterText.toLowerCase())) {
          return false;
        }

        // Account filter
        if (accountFilter && accountFilter !== 'all' && transaction.account !== accountFilter) {
          return false;
        }

        // Category/Person filter
        if (categoryFilter && categoryFilter !== 'all') {
          if (transaction.type === 'reimbursement') {
            if (transaction.person !== categoryFilter) {
              return false;
            }
          } else {
            if (transaction.category !== categoryFilter) {
              return false;
            }
          }
        }

        // Person filter from URL parameter
        if (personFilter && personFilter !== 'all' && transaction.person !== personFilter) {
          return false;
        }

        // Transaction type filter
        if (typeFilter !== "all" && transaction.type !== typeFilter) {
          return false;
        }

        // Date range filter
        if (startDate) {
          const txDate = new Date(transaction.date);
          const filterStart = new Date(startDate);
          // Set to start of day
          filterStart.setHours(0, 0, 0, 0);
          if (txDate < filterStart) {
            return false;
          }
        }

        if (endDate) {
          const txDate = new Date(transaction.date);
          const filterEnd = new Date(endDate);
          // Set to end of day
          filterEnd.setHours(23, 59, 59, 999);
          if (txDate > filterEnd) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortField === 'date') {
          return sortOrder === 'asc'
            ? new Date(a.date).getTime() - new Date(b.date).getTime()
            : new Date(b.date).getTime() - new Date(a.date).getTime()
        }
        if (sortField === 'amount') {
          return sortOrder === 'asc' ? a.amount - b.amount : b.amount - a.amount
        }
        return sortOrder === 'asc'
          ? a.category.localeCompare(b.category)
          : b.category.localeCompare(a.category)
      });
  }, [transactions, filterText, accountFilter, personFilter, typeFilter, startDate, endDate, sortField, sortOrder, categoryFilter]);

  // Clear all filters
  const clearAllFilters = () => {
    setFilterText('');
    setTypeFilter('all');
    setPeriodFilter('all');
    setStartDate(null);
    setEndDate(null);
    setSortField('date');
    setSortOrder('desc');
    setCategoryFilter('all');

    // Clear URL parameters
    const url = new URL(window.location.href);
    url.searchParams.delete('account');
    url.searchParams.delete('personFilter');
    window.history.pushState({}, '', url.toString());

    // Force re-render
    window.dispatchEvent(new Event('popstate'));
  };

  const handleEditTransaction = (transaction: Transaction) => {
    // Set transaction details for editing
    setTransactionDate(transaction.date);
    setTransactionType(transaction.type);
    setTransactionDescription(transaction.description);
    setTransactionAmount(transaction.amount.toString());
    setTransactionAccount(transaction.account);
    setTransactionCategory(transaction.category);
    setTransactionPerson(transaction.person || '');
    setEditingTransactionId(transaction.id);
    setIsAddModalOpen(true);
  };

  const handleDeleteTransaction = (transactionId: string) => {
    if (confirm('Are you sure you want to delete this transaction?')) {
      removeTransaction(transactionId);
    }
  };

  // Split transaction feature removed

  // Handle file selection for import modal
  const handleFileSelected = (file: File | null) => {
    setImportFile(file);
  };

  // Close import modal and reset state
  const handleCloseImportModal = () => {
    setIsImportModalOpen(false);
    setImportFile(null);
  };
  
  // Toggle selection of a single transaction
  const toggleTransactionSelection = (transactionId: string) => {
    setSelectedTransactions(prev => 
      prev.includes(transactionId) 
        ? prev.filter(id => id !== transactionId) 
        : [...prev, transactionId]
    );
  };
  
  // Handle select/deselect all transactions
  const toggleSelectAll = () => {
    if (selectAll || selectedTransactions.length === filteredTransactions.length) {
      // If all are selected or select all is true, deselect all
      setSelectedTransactions([]);
      setSelectAll(false);
    } else {
      // Otherwise, select all filtered transactions
      setSelectedTransactions(filteredTransactions.map(t => t.id));
      setSelectAll(true);
    }
  };
  
  // Handle bulk delete of selected transactions
  const handleBulkDelete = () => {
    if (selectedTransactions.length > 0) {
      setIsDeleteConfirmOpen(true);
    }
  };
  
  // Perform the actual deletion after confirmation
  const confirmBulkDelete = () => {
    removeTransactions(selectedTransactions);
    setSelectedTransactions([]);
    setSelectAll(false);
    setIsDeleteConfirmOpen(false);
  };

  return (
    <div className="container p-4 mx-auto space-y-6 max-w-7xl fade-in">
      {/* Import Modal */}
      <Dialog open={isImportModalOpen} onOpenChange={(open) => !open && handleCloseImportModal()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Import Transactions</DialogTitle>
          </DialogHeader>

          <div className="py-4 space-y-4">
            <BulkImportForm onFileSelected={handleFileSelected} />

            {importFile && (
              <Alert className="mt-2 bg-blue-50 text-blue-800 border border-blue-200">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-500" />
                  <p className="text-sm font-medium">File selected: {importFile.name}</p>
                </div>
                <p className="text-xs mt-1 text-blue-600">Click "Import Now" to process this file</p>
              </Alert>
            )}
          </div>

          <DialogFooter className="sm:justify-between">
            <Button 
              variant="outline" 
              onClick={handleCloseImportModal}
            >
              Cancel
            </Button>
            {importFile && (
              <Button 
                onClick={() => {
                  setIsImportModalOpen(false);
                  // Show the import progress modal
                  setTimeout(() => {
                    // We use a timeout to allow the first modal to close properly
                    // before opening the new one
                    setIsImportModalOpen(true);
                  }, 100);
                }}
              >
                Import Now
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Progress Modal */}
      {importFile && (
        <ImportModal 
          isOpen={isImportModalOpen}
          onClose={handleCloseImportModal}
          file={importFile}
        />
      )}
      {/* Header with gradient background */}
      <div className="relative rounded-3xl p-8 overflow-hidden float-card bg-white mb-2">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10"
             style={{
               background: "radial-gradient(circle at top right, #4169E1, transparent 70%)",
               zIndex: 0
             }}
        />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2 primary-gradient-text flex items-center gap-3">
              <Clipboard className="h-7 w-7 text-primary" />
              <span>All Transactions</span>
            </h1>
            <p className="text-gray-600 max-w-xl">
              View, filter and manage all your financial transactions in one place
            </p>
          </div>

          <div className="flex gap-3 self-end">
            <Button 
              onClick={openAddTransactionModal}
              className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white"
            >
              + Add Transaction
            </Button>
            <Button 
              onClick={() => exportTransactionsToExcel(filteredTransactions)}
              variant="outline"
              className="flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors"
            >
              <FileDown className="h-4 w-4" /> Export to Excel
            </Button>
            <Button 
              onClick={() => setIsImportModalOpen(true)}
              variant="outline"
              className="flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors"
            >
              <FileUp className="h-4 w-4" /> Import
            </Button>
          </div>
        </div>
      </div>

      {/* Transaction Card */}
      <Card className="shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300">
        <CardHeader className="pb-2">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle className="text-xl font-bold flex items-center gap-2">
                Transaction History
              </CardTitle>
              <CardDescription>
                {filteredTransactions.length === 0 
                  ? "No transactions found with current filters" 
                  : `Showing ${filteredTransactions.length} transactions`}
              </CardDescription>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {selectedTransactions.length > 0 ? (
                <div className="flex items-center gap-2">
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    className="h-9 bg-red-500 hover:bg-red-600 text-white flex items-center gap-1"
                    onClick={handleBulkDelete}
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete Selected ({selectedTransactions.length})
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9"
                    onClick={() => {
                      setSelectedTransactions([]);
                      setSelectAll(false);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <div className="relative flex items-center">
                  <Input
                    type="text"
                    placeholder="Filter transactions..."
                    value={filterText}
                    onChange={(e) => setFilterText(e.target.value)}
                    className="pr-8 border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                  {filterText && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute right-0 h-full w-8 p-0"
                      onClick={() => setFilterText('')}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-gray-400"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </Button>
                  )}
                </div>
              )}

              <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors">
                    <Filter className="h-4 w-4" />
                    <span>Filters</span>
                    <ChevronDown className="h-4 w-4 opacity-70" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[320px] md:w-[520px] p-4" align="end">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">Filter Options</h4>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 text-xs text-gray-500 hover:text-blue-600"
                        onClick={clearAllFilters}
                      >
                        Clear All
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* 1. Date Filter */}
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Date Range</label>
                        <Select
                          value={periodFilter || "all"}
                          onValueChange={(value) => {
                            // Set periodFilter
                            setPeriodFilter(value);

                            const now = new Date();

                            // Reset dates first
                            setStartDate(null);
                            setEndDate(null);

                            switch (value) {
                              case "thisMonth":
                                // First day of current month
                                setStartDate(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]);
                                // Last day of current month
                                setEndDate(new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0]);
                                break;
                              case "lastMonth":
                                // First day of last month
                                setStartDate(new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0]);
                                // Last day of last month
                                setEndDate(new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0]);
                                break;
                              case "thisYear":
                                // First day of current year
                                setStartDate(new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0]);
                                // Last day of current year
                                setEndDate(new Date(now.getFullYear(), 11, 31).toISOString().split('T')[0]);
                                break;
                              case "custom":
                                // Keep dates empty for custom selection
                                break;
                              default:
                                // All time - no date filtering
                                break;
                            }
                          }}
                        >
                          <SelectTrigger className="border-gray-200 focus:ring-1 focus:ring-blue-500">
                            <SelectValue placeholder="Select time period" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Time</SelectItem>
                            <SelectItem value="thisMonth">This Month</SelectItem>
                            <SelectItem value="lastMonth">Last Month</SelectItem>
                            <SelectItem value="thisYear">This Year</SelectItem>
                            <SelectItem value="custom">Custom Range</SelectItem>
                          </SelectContent>
                        </Select>

                        {periodFilter === "custom" && (
                          <div className="flex flex-col sm:flex-row gap-2 mt-2">
                            <div className="flex-1">
                              <label className="text-xs text-gray-500 mb-1 block">From</label>
                              <Input
                                type="date"
                                value={startDate || ""}
                                onChange={(e) => setStartDate(e.target.value || null)}
                                className="border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                              />
                            </div>
                            <div className="flex-1">
                              <label className="text-xs text-gray-500 mb-1 block">To</label>
                              <Input
                                type="date"
                                value={endDate || ""}
                                onChange={(e) => setEndDate(e.target.value || null)}
                                className="border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* 2. Type Filter */}
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Transaction Type</label>
                        <Select
                          value={typeFilter}
                          onValueChange={setTypeFilter}
                        >
                          <SelectTrigger className="border-gray-200 focus:ring-1 focus:ring-blue-500">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                            <SelectItem value="expense">Expenses</SelectItem>
                            <SelectItem value="income">Income</SelectItem>
                            <SelectItem value="reimbursement">Reimbursements</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* 3. Category/Person Filter */}
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Category/Person</label>
                        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                          <SelectTrigger className="border-gray-200 focus:ring-1 focus:ring-blue-500">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Categories</SelectItem>

                            {/* Show relevant categories based on selected transaction type */}
                            {typeFilter === "income" ? (
                              // Show only income categories
                              Array.from(new Set(transactions
                                .filter(t => t.type === "income")
                                .map(t => t.category)
                              )).filter(Boolean).map(category => (
                                <SelectItem key={category} value={category || "unknown"}>{category}</SelectItem>
                              ))
                            ) : typeFilter === "expense" ? (
                              // Show only expense categories
                              Array.from(new Set(transactions
                                .filter(t => t.type === "expense")
                                .map(t => t.category)
                              )).filter(Boolean).map(category => (
                                <SelectItem key={category} value={category || "unknown"}>{category}</SelectItem>
                              ))
                            ) : typeFilter === "reimbursement" ? (
                              // Show only persons for reimbursements
                              Array.from(new Set(transactions
                                .filter(t => t.type === "reimbursement")
                                .map(t => t.person)
                              )).filter(Boolean).map(person => (
                                <SelectItem key={person} value={person || "unknown"}>{person}</SelectItem>
                              ))
                            ) : (
                              // Show all categories and persons when "all" is selected
                              <>
                                {Array.from(new Set(transactions.map(t => t.category))).filter(Boolean).map(category => (
                                  <SelectItem key={category} value={category || "unknown"}>{category}</SelectItem>
                                ))}
                                {Array.from(new Set(transactions.map(t => t.person))).filter(Boolean).map(person => (
                                  <SelectItem key={person} value={person || "unknown"}>{person}</SelectItem>
                                ))}
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* 4. Account Filter */}
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Account</label>
                        <Select 
                          value={accountFilter || "all"}
                          onValueChange={(value) => {
                            // Update URL with the account filter
                            const url = new URL(window.location.href);
                            if (value === "all") {
                              url.searchParams.delete('account');
                            } else {
                              url.searchParams.set('account', value);
                            }
                            window.history.pushState({}, '', url.toString());

                            // Force an immediate re-render to apply filter
                            // This is crucial for the filter to work immediately like other filters
                            window.dispatchEvent(new Event('popstate'));

                            // Also close the filter popover to be consistent with immediate filtering
                            setIsFilterOpen(false);
                          }}
                        >
                          <SelectTrigger className="border-gray-200 focus:ring-1 focus:ring-blue-500">
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Accounts</SelectItem>

                            {/* Show relevant accounts based on selected transaction type */}
                            {typeFilter === "income" ? (
                              // Show only accounts used for income transactions
                              Array.from(new Set(transactions
                                .filter(t => t.type === "income")
                                .map(t => t.account)
                              )).filter(Boolean).map(account => (
                                <SelectItem key={account} value={account || "unknown"}>{account}</SelectItem>
                              ))
                            ) : typeFilter === "expense" ? (
                              // Show only accounts used for expense transactions
                              Array.from(new Set(transactions
                                .filter(t => t.type === "expense")
                                .map(t => t.account)
                              )).filter(Boolean).map(account => (
                                <SelectItem key={account} value={account || "unknown"}>{account}</SelectItem>
                              ))
                            ) : typeFilter === "reimbursement" ? (
                              // Show only accounts used for reimbursement transactions
                              Array.from(new Set(transactions
                                .filter(t => t.type === "reimbursement")
                                .map(t => t.account)
                              )).filter(Boolean).map(account => (
                                <SelectItem key={account} value={account || "unknown"}>{account}</SelectItem>
                              ))
                            ) : (
                              // Show all accounts when "all" is selected for type
                              Array.from(new Set(transactions.map(t => t.account))).filter(Boolean).map(account => (
                                <SelectItem key={account} value={account || "unknown"}>{account}</SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <div className="flex flex-col sm:flex-row justify-between gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Sort By</label>
                          <Select 
                            value={sortField} 
                            onValueChange={(value: "date" | "amount" | "category") => setSortField(value)}
                          >
                            <SelectTrigger className="w-full border-gray-200 focus:ring-1 focus:ring-blue-500">
                              <SelectValue placeholder="Sort by" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="date">Date</SelectItem>
                              <SelectItem value="amount">Amount</SelectItem>
                              <SelectItem value="category">Category</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium">Sort Order</label>
                          <Select 
                            value={sortOrder} 
                            onValueChange={(value: "asc" | "desc") => setSortOrder(value)}
                          >
                            <SelectTrigger className="w-full border-gray-200 focus:ring-1 focus:ring-blue-500">
                              <SelectValue placeholder="Order" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="asc">Ascending</SelectItem>
                              <SelectItem value="desc">Descending</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button 
                        className="text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                        onClick={() => setIsFilterOpen(false)}
                      >
                        Close Filters
                      </Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Applied filters display */}
              {(typeFilter !== "all" || categoryFilter !== "all" || accountFilter || periodFilter) && (
                <div className="ml-2 flex flex-wrap gap-2 items-center">
                  {typeFilter !== "all" && (
                    <Badge variant="outline" className="px-2 py-1 capitalize flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-200">
                      {typeFilter}
                      <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => setTypeFilter("all")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                      </Button>
                    </Badge>
                  )}
                  {categoryFilter !== "all" && (
                    <Badge variant="outline" className="px-2 py-1 flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-200">
                      {categoryFilter}
                      <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => setCategoryFilter("all")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                      </Button>
                    </Badge>
                  )}
                  {accountFilter && (
                    <Badge variant="outline" className="px-2 py-1 flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-200">
                      {accountFilter}
                      <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => {
                        const url = new URL(window.location.href);
                        url.searchParams.delete('account');
                        window.history.pushState({}, '', url.toString());
                        window.dispatchEvent(new Event('popstate'));
                      }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                      </Button>
                    </Badge>
                  )}
                  {periodFilter && periodFilter !== "all" && (
                    <Badge variant="outline" className="px-2 py-1 flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-200">
                      <Calendar className="h-3 w-3 mr-1" />
                      {periodFilter === "thisMonth" ? "This Month" : 
                       periodFilter === "lastMonth" ? "Last Month" : 
                       periodFilter === "thisYear" ? "This Year" : 
                       periodFilter === "custom" ? "Custom Range" : periodFilter}
                      <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => {
                        setPeriodFilter("all");
                        setStartDate(null);
                        setEndDate(null);
                      }}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                      </Button>
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg">
            <div className="overflow-hidden rounded-lg border border-gray-100 shadow-sm">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="w-10 px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">
                      <div className="flex items-center justify-center">
                        <Checkbox 
                          checked={filteredTransactions.length > 0 && selectedTransactions.length === filteredTransactions.length}
                          onCheckedChange={toggleSelectAll}
                          className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                          aria-label="Select all transactions"
                        />
                      </div>
                    </th>
                    <th className="text-left px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Date</th>
                    <th className="text-left px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Type</th>
                    <th className="text-left px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Category/Person</th>
                    <th className="text-left px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Description</th>
                    <th className="text-left px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Account</th>
                    <th className="text-right px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Amount</th>
                    <th className="text-center px-4 py-2.5 bg-gray-50 text-gray-600 font-medium text-xs uppercase tracking-wider border-b">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredTransactions.map((transaction) => {
                    // Get icon ID for this category
                    const iconInfo = useFinanceStore.getState().categoryIcons.find(c => 
                      c.category === (transaction.category || transaction.person)
                    );
                    const iconId = iconInfo?.iconId || 
                                     (transaction.type === 'expense' ? 
                                      getDefaultCategoryIcon('expense') : 
                                      getDefaultCategoryIcon('income'));
                    
                    const isSelected = selectedTransactions.includes(transaction.id);

                    return (
                      <tr 
                        key={transaction.id} 
                        className={`hover:bg-gray-50 transition-colors ${isSelected ? 'bg-blue-50' : ''}`}
                      >
                        <td className="py-3 px-4 text-center">
                          <Checkbox 
                            checked={isSelected} 
                            onCheckedChange={() => toggleTransactionSelection(transaction.id)}
                            className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                            aria-label={`Select transaction ${transaction.description}`}
                          />
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-700">{formatDate(transaction.date)}</td>
                        <td className="py-3 px-4">
                          <Badge 
                            className={`
                              ${transaction.type === 'income' ? 'bg-green-50 text-green-700 border border-green-200' : 
                                transaction.type === 'expense' ? 'bg-red-50 text-red-700 border border-red-200' : 
                                'bg-blue-50 text-blue-700 border border-blue-200'}
                              text-xs px-1.5 py-0.5 rounded capitalize whitespace-nowrap
                            `}
                          >
                            {transaction.type}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="flex-shrink-0">
                              {(transaction.category || transaction.person) ? 
                                renderCategoryIcon(iconId, 16, "", false) : 
                                '—'
                              }
                            </div>
                            <span className="text-sm text-gray-800 truncate max-w-[120px]">
                              {transaction.category || transaction.person || '—'}
                            </span>
                            {transaction.isSplit && (
                              <span 
                                className="inline-flex items-center px-1 py-0.5 rounded text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200"
                                title="This transaction is split across multiple categories"
                              >
                                Split
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-800 font-medium truncate max-w-[200px]" title={transaction.description}>{transaction.description}</td>
                        <td className="py-3 px-4 text-sm text-gray-700">{transaction.account}</td>
                        <td className={`py-3 px-4 text-right font-medium text-sm whitespace-nowrap ${
                          transaction.type === 'contra'
                            ? transaction.description.toLowerCase().includes("payment to")
                              ? 'text-red-600'
                              : transaction.description.toLowerCase().includes("payment received")
                                ? 'text-green-600'
                                : transaction.amount < 0 ? 'text-red-600' : 'text-green-600'
                            : transaction.type === 'income'
                              ? 'text-green-600'
                              : 'text-red-600'
                        }`}>
                          {transaction.type === 'income' || 
                           (transaction.type === 'contra' && transaction.description.toLowerCase().includes("payment received"))
                           ? '+' : '-'}
                          {formatCurrency(Math.abs(transaction.amount))}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <div className="inline-flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditTransaction(transaction)}
                              className="p-1.5 h-7 w-7 rounded-full text-blue-600 bg-blue-50 hover:bg-blue-100"
                              title="Edit Transaction"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteTransaction(transaction.id);
                              }}
                              className="p-1.5 h-7 w-7 rounded-full text-red-600 bg-red-50 hover:bg-red-100"
                              title="Delete Transaction"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {filteredTransactions.length > 0 && (
            <div className="mt-4 flex justify-between items-center text-sm text-gray-500">
              <span>Showing {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? 's' : ''}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Form using the unified AddTransactionForm component */}
      <AddTransactionForm 
        isOpen={isAddModalOpen} 
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingTransactionId(null);
        }}
        initialType={transactionType}
      />
      
      {/* Edit Transaction Handling */}
      {editingTransactionId && (
        <Dialog open={!!editingTransactionId} onOpenChange={(isOpen) => {
          if (!isOpen) {
            setEditingTransactionId(null);
          }
        }}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Edit Transaction</DialogTitle>
              <DialogDescription>
                Edit transaction details below
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={transactionDate}
                    onChange={(e) => setTransactionDate(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select
                    value={transactionType}
                    onValueChange={(value) => {
                      setTransactionType(value);
                      setTransactionCategory('');
                      setTransactionPerson('');
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="expense">Expense</SelectItem>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="reimbursement">Reimbursement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  placeholder="Enter description"
                  value={transactionDescription}
                  onChange={(e) => setTransactionDescription(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  min="0.01"
                  step="0.01"
                  placeholder="Enter amount"
                  value={transactionAmount}
                  onChange={(e) => setTransactionAmount(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account">Account</Label>
                <Select
                  value={transactionAccount}
                  onValueChange={(value) => setTransactionAccount(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from(new Set(transactions.map(t => t.account))).filter(Boolean).map(account => (
                      <SelectItem key={account} value={account || "unknown"}>{account}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">
                  {transactionType === 'reimbursement' ? 'Person' : 'Category'}
                </Label>
                {transactionType === 'reimbursement' ? (
                  <Input
                    id="person"
                    placeholder="Enter person name"
                    value={transactionPerson}
                    onChange={(e) => setTransactionPerson(e.target.value)}
                  />
                ) : (
                  <Select
                    value={transactionCategory}
                    onValueChange={(value) => setTransactionCategory(value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={`Select ${transactionType === 'expense' ? 'expense' : 'income'} category`} />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from(new Set(
                        transactions
                          .filter(t => t.type === transactionType)
                          .map(t => t.category)
                      )).filter(Boolean).map(category => (
                        <SelectItem key={category} value={category || "unknown"}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setEditingTransactionId(null);
              }}>
                Cancel
              </Button>
              <Button onClick={() => {
                // Update existing transaction
                const partialTransaction: Partial<Transaction> = {
                  date: transactionDate,
                  type: transactionType,
                  description: transactionDescription,
                  amount: parseFloat(transactionAmount),
                  account: transactionAccount,
                  category: transactionCategory,
                  person: transactionPerson,
                };
                useFinanceStore.getState().updateTransaction(editingTransactionId, partialTransaction);

                // Reset form and close modal
                setEditingTransactionId(null);
                setTransactionDate(new Date().toISOString().split('T')[0]);
                setTransactionType('expense');
                setTransactionDescription('');
                setTransactionAmount('');
                setTransactionAccount('');
                setTransactionCategory('');
                setTransactionPerson('');
              }}>
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Split Transaction feature removed */}
      
      {/* Bulk Delete Confirmation Dialog */}
      <Dialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl">Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedTransactions.length} selected transaction{selectedTransactions.length !== 1 ? 's' : ''}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex justify-between mt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteConfirmOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive"
              className="bg-red-500 hover:bg-red-600 text-white"
              onClick={confirmBulkDelete}
            >
              Delete {selectedTransactions.length} Transaction{selectedTransactions.length !== 1 ? 's' : ''}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}