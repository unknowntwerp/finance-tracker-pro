import React from 'react';
// Import icon libraries - using specific imports to ensure all icons are properly loaded
import * as Fa from 'react-icons/fa';
import * as Fi from 'react-icons/fi';
import * as Bi from 'react-icons/bi';
import * as Ri from 'react-icons/ri';
import * as Md from 'react-icons/md';
import * as Bs from 'react-icons/bs';
import * as Io from 'react-icons/io5';
import * as Hi from 'react-icons/hi';
import * as Gi from 'react-icons/gi';
import * as Cg from 'react-icons/cg';

// Define common categories
export enum CategoryType {
  EXPENSE = 'expense',
  INCOME = 'income',
  BOTH = 'both'
}

export interface CategoryIcon {
  id: string;
  name: string;
  icon: React.ElementType;
  type: CategoryType;
  color?: string;
}

// Array of category icons with both expense and income categories
export const categoryIcons: CategoryIcon[] = [
  // Food & Dining
  { id: 'food', name: 'Food', icon: Md.MdFastfood, type: CategoryType.EXPENSE, color: '#FF6B6B' },
  { id: 'restaurant', name: 'Restaurant', icon: Fa.FaUtensils, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'coffee', name: 'Coffee', icon: Fa.FaCoffee, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'groceries', name: 'Groceries', icon: Fa.FaShoppingBasket, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'bakery', name: 'Bakery', icon: Gi.GiBread, type: CategoryType.EXPENSE, color: '#CD853F' },
  { id: 'bar', name: 'Bar', icon: Fa.FaGlassMartiniAlt, type: CategoryType.EXPENSE, color: '#8B0000' },
  { id: 'ice_cream', name: 'Ice Cream', icon: Fa.FaIceCream, type: CategoryType.EXPENSE, color: '#F08080' },
  { id: 'smoothie', name: 'Smoothie', icon: Gi.GiSmoothies, type: CategoryType.EXPENSE, color: '#FF69B4' },

  // Shopping
  { id: 'shopping', name: 'Shopping', icon: Fa.FaShoppingCart, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'clothing', name: 'Clothing', icon: Fa.FaTshirt, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'electronics', name: 'Electronics', icon: Md.MdDevices, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'gifts', name: 'Gifts', icon: Fa.FaGift, type: CategoryType.EXPENSE, color: '#FF1493' },
  { id: 'jewelry', name: 'Jewelry', icon: Gi.GiDiamondRing, type: CategoryType.EXPENSE, color: '#B8860B' },
  { id: 'shoes', name: 'Shoes', icon: Gi.GiRunningShoe, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'eyewear', name: 'Eyewear', icon: Fa.FaGlasses, type: CategoryType.EXPENSE, color: '#2F4F4F' },
  { id: 'accessories', name: 'Accessories', icon: Gi.GiWatch, type: CategoryType.EXPENSE, color: '#704214' },
  { id: 'cosmetics', name: 'Cosmetics', icon: Gi.GiLipstick, type: CategoryType.EXPENSE, color: '#FF69B4' },
  { id: 'luxury', name: 'Luxury', icon: Gi.GiCrystalShine, type: CategoryType.EXPENSE, color: '#FFD700' },

  // Transportation
  { id: 'transport', name: 'Transport', icon: Fa.FaBus, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'fuel', name: 'Fuel', icon: Fa.FaGasPump, type: CategoryType.EXPENSE, color: '#FF4500' },
  { id: 'taxi', name: 'Taxi', icon: Fa.FaTaxi, type: CategoryType.EXPENSE, color: '#FFD700' },
  { id: 'parking', name: 'Parking', icon: Fa.FaParking, type: CategoryType.EXPENSE, color: '#808080' },
  { id: 'flight', name: 'Flight', icon: Fa.FaPlane, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'train', name: 'Train', icon: Fa.FaTrain, type: CategoryType.EXPENSE, color: '#008080' },
  { id: 'bike', name: 'Bike', icon: Fa.FaBiking, type: CategoryType.EXPENSE, color: '#006400' },
  { id: 'scooter', name: 'Scooter', icon: Gi.GiScooter, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'car_rental', name: 'Car Rental', icon: Fa.FaCarSide, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'cruise', name: 'Cruise', icon: Fa.FaShip, type: CategoryType.EXPENSE, color: '#00008B' },
  { id: 'toll', name: 'Toll', icon: Fa.FaRoad, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'car_service', name: 'Car Service', icon: Fa.FaWrench, type: CategoryType.EXPENSE, color: '#A52A2A' },

  // Entertainment
  { id: 'entertainment', name: 'Entertainment', icon: Fa.FaFilm, type: CategoryType.EXPENSE, color: '#9932CC' },
  { id: 'games', name: 'Games', icon: Fa.FaGamepad, type: CategoryType.EXPENSE, color: '#8A2BE2' },
  { id: 'sports', name: 'Sports', icon: Fa.FaFutbol, type: CategoryType.EXPENSE, color: '#228B22' },
  { id: 'books', name: 'Books', icon: Fa.FaBook, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'music', name: 'Music', icon: Fa.FaMusic, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'concert', name: 'Concert', icon: Fa.FaGuitar, type: CategoryType.EXPENSE, color: '#8B008B' },
  { id: 'theater', name: 'Theater', icon: Fa.FaTheaterMasks, type: CategoryType.EXPENSE, color: '#800080' },
  { id: 'museum', name: 'Museum', icon: Fa.FaLandmark, type: CategoryType.EXPENSE, color: '#BC8F8F' },
  { id: 'theme_park', name: 'Theme Park', icon: Fa.FaTicketAlt, type: CategoryType.EXPENSE, color: '#FF4500' },
  { id: 'movie', name: 'Movie', icon: Fa.FaVideo, type: CategoryType.EXPENSE, color: '#8B0000' },
  { id: 'streaming', name: 'Streaming', icon: Fa.FaPlay, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'casino', name: 'Casino', icon: Gi.GiDiceSixFacesSix, type: CategoryType.EXPENSE, color: '#B22222' },

  // Health
  { id: 'health', name: 'Health', icon: Fa.FaHeartbeat, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'medicine', name: 'Medicine', icon: Fa.FaPills, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'doctor', name: 'Doctor', icon: Fa.FaUserMd, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'fitness', name: 'Fitness', icon: Fa.FaDumbbell, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'dentist', name: 'Dentist', icon: Fa.FaTooth, type: CategoryType.EXPENSE, color: '#FFFFFF' },
  { id: 'therapy', name: 'Therapy', icon: Fa.FaBrain, type: CategoryType.EXPENSE, color: '#8A2BE2' },
  { id: 'pharmacy', name: 'Pharmacy', icon: Fa.FaPrescriptionBottleAlt, type: CategoryType.EXPENSE, color: '#00CED1' },
  { id: 'vision', name: 'Vision', icon: Fa.FaEye, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'gym', name: 'Gym', icon: Io.IoFitness, type: CategoryType.EXPENSE, color: '#B22222' },
  { id: 'spa', name: 'Spa', icon: Fa.FaSpa, type: CategoryType.EXPENSE, color: '#20B2AA' },
  { id: 'medical_equipment', name: 'Medical Equipment', icon: Fa.FaStethoscope, type: CategoryType.EXPENSE, color: '#708090' },

  // Housing
  { id: 'housing', name: 'Housing', icon: Fa.FaHome, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'rent', name: 'Rent', icon: Fa.FaKey, type: CategoryType.EXPENSE, color: '#A0522D' },
  { id: 'furniture', name: 'Furniture', icon: Fa.FaCouch, type: CategoryType.EXPENSE, color: '#DAA520' },
  { id: 'maintenance', name: 'Maintenance', icon: Fa.FaTools, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'utilities', name: 'Utilities', icon: Fa.FaBolt, type: CategoryType.EXPENSE, color: '#FFD700' },
  { id: 'mortgage', name: 'Mortgage', icon: Fa.FaHouseUser, type: CategoryType.EXPENSE, color: '#8B0000' },
  { id: 'property_tax', name: 'Property Tax', icon: Fa.FaFileInvoiceDollar, type: CategoryType.EXPENSE, color: '#B8860B' },
  { id: 'home_improvement', name: 'Home Improvement', icon: Fa.FaHammer, type: CategoryType.EXPENSE, color: '#D2691E' },
  { id: 'home_insurance', name: 'Home Insurance', icon: Fa.FaShieldAlt, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'lawn', name: 'Lawn & Garden', icon: Fa.FaLeaf, type: CategoryType.EXPENSE, color: '#32CD32' },
  { id: 'cleaning', name: 'Cleaning', icon: Fa.FaBroom, type: CategoryType.EXPENSE, color: '#87CEEB' },
  { id: 'moving', name: 'Moving', icon: Fa.FaTruckMoving, type: CategoryType.EXPENSE, color: '#CD853F' },
  { id: 'storage', name: 'Storage', icon: Fa.FaWarehouse, type: CategoryType.EXPENSE, color: '#A9A9A9' },

  // Bills
  { id: 'bills', name: 'Bills', icon: Fa.FaFileInvoiceDollar, type: CategoryType.EXPENSE, color: '#3CB371' },
  { id: 'internet', name: 'Internet', icon: Fa.FaWifi, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'phone', name: 'Phone', icon: Fa.FaMobileAlt, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'tv', name: 'TV', icon: Fa.FaTv, type: CategoryType.EXPENSE, color: '#000000' },
  { id: 'electricity', name: 'Electricity', icon: Fa.FaLightbulb, type: CategoryType.EXPENSE, color: '#FFD700' },
  { id: 'water', name: 'Water', icon: Fa.FaWater, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'gas', name: 'Gas', icon: Fa.FaFire, type: CategoryType.EXPENSE, color: '#FF4500' },
  { id: 'trash', name: 'Trash', icon: Fa.FaTrashAlt, type: CategoryType.EXPENSE, color: '#696969' },
  { id: 'cable', name: 'Cable', icon: Fa.FaNetworkWired, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'subscriptions', name: 'Subscriptions', icon: Fa.FaRegCalendarAlt, type: CategoryType.EXPENSE, color: '#20B2AA' },

  // Education
  { id: 'education', name: 'Education', icon: Fa.FaGraduationCap, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'courses', name: 'Courses', icon: Fa.FaChalkboardTeacher, type: CategoryType.EXPENSE, color: '#9370DB' },
  { id: 'books_education', name: 'Books', icon: Fa.FaBookOpen, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'tuition', name: 'Tuition', icon: Fa.FaUniversity, type: CategoryType.EXPENSE, color: '#800000' },
  { id: 'school_supplies', name: 'School Supplies', icon: Fa.FaPencilAlt, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'student_loan', name: 'Student Loan', icon: Fa.FaUserGraduate, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'research', name: 'Research', icon: Fa.FaMicroscope, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'workshop', name: 'Workshop', icon: Fa.FaLaptopCode, type: CategoryType.EXPENSE, color: '#9932CC' },
  { id: 'library', name: 'Library', icon: Fa.FaBookReader, type: CategoryType.EXPENSE, color: '#8B4513' },

  // Personal
  { id: 'personal', name: 'Personal', icon: Fa.FaUser, type: CategoryType.EXPENSE, color: '#FF6347' },
  { id: 'beauty', name: 'Beauty', icon: Fa.FaSmile, type: CategoryType.EXPENSE, color: '#FF1493' },
  { id: 'clothing_personal', name: 'Clothing', icon: Fa.FaTshirt, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'haircut', name: 'Haircut', icon: Fa.FaCut, type: CategoryType.EXPENSE, color: '#800000' },
  { id: 'laundry', name: 'Laundry', icon: Fa.FaTshirt, type: CategoryType.EXPENSE, color: '#1E90FF' },
  { id: 'manicure', name: 'Manicure', icon: Md.MdOutlineCleanHands, type: CategoryType.EXPENSE, color: '#FF69B4' },
  { id: 'massage', name: 'Massage', icon: Fa.FaHandsWash, type: CategoryType.EXPENSE, color: '#CD853F' },
  { id: 'wellness', name: 'Wellness', icon: Fa.FaYinYang, type: CategoryType.EXPENSE, color: '#2F4F4F' },
  { id: 'self_care', name: 'Self Care', icon: Gi.GiHeartInside, type: CategoryType.EXPENSE, color: '#FF1493' },

  // Travel
  { id: 'travel', name: 'Travel', icon: Fa.FaSuitcase, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'hotel', name: 'Hotel', icon: Fa.FaHotel, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'adventure', name: 'Adventure', icon: Fa.FaMountain, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'vacation', name: 'Vacation', icon: Fa.FaUmbrellaBeach, type: CategoryType.EXPENSE, color: '#FF8C00' },
  { id: 'backpacking', name: 'Backpacking', icon: Fa.FaHiking, type: CategoryType.EXPENSE, color: '#556B2F' },
  { id: 'sightseeing', name: 'Sightseeing', icon: Fa.FaCamera, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'travel_insurance', name: 'Travel Insurance', icon: Fa.FaShieldAlt, type: CategoryType.EXPENSE, color: '#483D8B' },
  { id: 'visa', name: 'Visa', icon: Fa.FaPassport, type: CategoryType.EXPENSE, color: '#800000' },
  { id: 'luggage', name: 'Luggage', icon: Fa.FaLuggageCart, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'resort', name: 'Resort', icon: Fa.FaCocktail, type: CategoryType.EXPENSE, color: '#FF1493' },

  // Financial
  { id: 'financial', name: 'Financial', icon: Fa.FaMoneyBillWave, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'insurance', name: 'Insurance', icon: Fa.FaShieldAlt, type: CategoryType.EXPENSE, color: '#4169E1' },
  { id: 'taxes', name: 'Taxes', icon: Fa.FaPercentage, type: CategoryType.EXPENSE, color: '#8B0000' },
  { id: 'investments', name: 'Investments', icon: Fa.FaChartLine, type: CategoryType.BOTH, color: '#4169E1' },
  { id: 'bank_fee', name: 'Bank Fee', icon: Fa.FaUniversity, type: CategoryType.EXPENSE, color: '#800000' },
  { id: 'atm_fee', name: 'ATM Fee', icon: Fa.FaMoneyBill, type: CategoryType.EXPENSE, color: '#2E8B57' },
  { id: 'credit_card_fee', name: 'Credit Card Fee', icon: Fa.FaCreditCard, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'loan_payment', name: 'Loan Payment', icon: Fa.FaHandHoldingUsd, type: CategoryType.EXPENSE, color: '#A52A2A' },
  { id: 'financial_advice', name: 'Financial Advice', icon: Fa.FaUserTie, type: CategoryType.EXPENSE, color: '#2F4F4F' },
  { id: 'brokerage_fee', name: 'Brokerage Fee', icon: Fa.FaExchangeAlt, type: CategoryType.EXPENSE, color: '#800080' },
  { id: 'forex', name: 'Forex', icon: Fa.FaExchangeAlt, type: CategoryType.BOTH, color: '#4682B4' },
  { id: 'cryptocurrency', name: 'Cryptocurrency', icon: Fa.FaBitcoin, type: CategoryType.BOTH, color: '#FFA500' },
  { id: 'retirement', name: 'Retirement', icon: Fa.FaPiggyBank, type: CategoryType.BOTH, color: '#DA70D6' },
  { id: 'stock', name: 'Stock', icon: Fa.FaChartBar, type: CategoryType.BOTH, color: '#228B22' },
  { id: 'bonds', name: 'Bonds', icon: Fa.FaFileContract, type: CategoryType.BOTH, color: '#4169E1' },
  { id: 'mutual_funds', name: 'Mutual Funds', icon: Fa.FaLayerGroup, type: CategoryType.BOTH, color: '#8A2BE2' },

  // Credit Cards
  { id: 'credit_card', name: 'Credit Card', icon: Fa.FaCreditCard, type: CategoryType.EXPENSE, color: '#800080' },
  { id: 'visa_card', name: 'Visa Card', icon: Fa.FaCcVisa, type: CategoryType.EXPENSE, color: '#1A1F71' },
  { id: 'mastercard', name: 'Mastercard', icon: Fa.FaCcMastercard, type: CategoryType.EXPENSE, color: '#EB001B' },
  { id: 'amex', name: 'American Express', icon: Fa.FaCcAmex, type: CategoryType.EXPENSE, color: '#2E77BC' },
  { id: 'discover', name: 'Discover', icon: Fa.FaCcDiscover, type: CategoryType.EXPENSE, color: '#FF6600' },
  { id: 'diners', name: 'Diners Club', icon: Fa.FaCcDinersClub, type: CategoryType.EXPENSE, color: '#0079BE' },
  { id: 'jcb', name: 'JCB', icon: Fa.FaCcJcb, type: CategoryType.EXPENSE, color: '#0B4EA2' },
  { id: 'apple_pay', name: 'Apple Pay', icon: Fa.FaApplePay, type: CategoryType.EXPENSE, color: '#000000' },
  { id: 'google_pay', name: 'Google Pay', icon: Fa.FaGooglePay, type: CategoryType.EXPENSE, color: '#4285F4' },
  { id: 'paypal', name: 'PayPal', icon: Fa.FaPaypal, type: CategoryType.EXPENSE, color: '#003087' },
  { id: 'bank_card', name: 'Bank Card', icon: Fa.FaMoneyCheck, type: CategoryType.EXPENSE, color: '#006400' },

  // Income Categories
  { id: 'salary', name: 'Salary', icon: Fa.FaMoneyCheckAlt, type: CategoryType.INCOME, color: '#2E8B57' },
  { id: 'freelance', name: 'Freelance', icon: Fa.FaLaptopCode, type: CategoryType.INCOME, color: '#4169E1' },
  { id: 'bonus', name: 'Bonus', icon: Fa.FaAward, type: CategoryType.INCOME, color: '#FFD700' },
  { id: 'gifts_income', name: 'Gifts', icon: Fa.FaGift, type: CategoryType.INCOME, color: '#FF1493' },
  { id: 'refunds', name: 'Refunds', icon: Fa.FaUndo, type: CategoryType.INCOME, color: '#FF8C00' },
  { id: 'rental', name: 'Rental', icon: Fa.FaBuilding, type: CategoryType.INCOME, color: '#8B4513' },
  { id: 'dividends', name: 'Dividends', icon: Fa.FaPercent, type: CategoryType.INCOME, color: '#4169E1' },
  { id: 'interest', name: 'Interest', icon: Fa.FaUniversity, type: CategoryType.INCOME, color: '#2E8B57' },
  { id: 'pension', name: 'Pension', icon: Fa.FaClock, type: CategoryType.INCOME, color: '#696969' },
  { id: 'child_support', name: 'Child Support', icon: Fa.FaChild, type: CategoryType.INCOME, color: '#FFB6C1' },
  { id: 'alimony', name: 'Alimony', icon: Fa.FaHandHoldingHeart, type: CategoryType.INCOME, color: '#DA70D6' },
  { id: 'government', name: 'Government', icon: Fa.FaLandmark, type: CategoryType.INCOME, color: '#6495ED' },
  { id: 'unemployment', name: 'Unemployment', icon: Fa.FaUserTie, type: CategoryType.INCOME, color: '#778899' },
  { id: 'social_security', name: 'Social Security', icon: Fa.FaIdCard, type: CategoryType.INCOME, color: '#708090' },
  { id: 'royalties', name: 'Royalties', icon: Fa.FaCopyright, type: CategoryType.INCOME, color: '#800080' },
  { id: 'selling', name: 'Selling', icon: Fa.FaStore, type: CategoryType.INCOME, color: '#B22222' },
  { id: 'commission', name: 'Commission', icon: Fa.FaHandshake, type: CategoryType.INCOME, color: '#8B0000' },
  { id: 'business', name: 'Business', icon: Fa.FaBriefcase, type: CategoryType.INCOME, color: '#2F4F4F' },
  { id: 'prizes', name: 'Prizes', icon: Fa.FaTrophy, type: CategoryType.INCOME, color: '#DAA520' },
  { id: 'investment_income', name: 'Investment Income', icon: Fa.FaMoneyBillWave, type: CategoryType.INCOME, color: '#006400' },
  { id: 'capital_gains', name: 'Capital Gains', icon: Fa.FaChartLine, type: CategoryType.INCOME, color: '#228B22' },
  { id: 'tax_refund', name: 'Tax Refund', icon: Fa.FaFileInvoiceDollar, type: CategoryType.INCOME, color: '#4682B4' },
  { id: 'scholarship', name: 'Scholarship', icon: Fa.FaGraduationCap, type: CategoryType.INCOME, color: '#FF4500' },
  { id: 'grant', name: 'Grant', icon: Fa.FaHandHoldingUsd, type: CategoryType.INCOME, color: '#9ACD32' },
  { id: 'lottery', name: 'Lottery', icon: Fa.FaTicketAlt, type: CategoryType.INCOME, color: '#9932CC' },

  // Banking
  { id: 'bank', name: 'Bank', icon: Fa.FaUniversity, type: CategoryType.BOTH, color: '#4682B4' },
  { id: 'savings', name: 'Savings', icon: Fa.FaPiggyBank, type: CategoryType.BOTH, color: '#FF8C00' },
  { id: 'checking', name: 'Checking', icon: Fa.FaMoneyCheck, type: CategoryType.BOTH, color: '#2E8B57' },
  { id: 'deposit', name: 'Deposit', icon: Fa.FaArrowDown, type: CategoryType.INCOME, color: '#32CD32' },
  { id: 'withdrawal', name: 'Withdrawal', icon: Fa.FaArrowUp, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'money_transfer', name: 'Money Transfer', icon: Fa.FaExchangeAlt, type: CategoryType.BOTH, color: '#4169E1' },
  { id: 'wallet', name: 'Wallet', icon: Fa.FaWallet, type: CategoryType.BOTH, color: '#8B4513' },

  // Miscellaneous
  { id: 'miscellaneous', name: 'Miscellaneous', icon: Fa.FaEllipsisH, type: CategoryType.BOTH, color: '#808080' },
  { id: 'pets', name: 'Pets', icon: Fa.FaPaw, type: CategoryType.EXPENSE, color: '#8B4513' },
  { id: 'charity', name: 'Charity', icon: Fa.FaHandHoldingHeart, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'childcare', name: 'Childcare', icon: Fa.FaBaby, type: CategoryType.EXPENSE, color: '#FF69B4' },
  { id: 'pet_food', name: 'Pet Food', icon: Fa.FaBone, type: CategoryType.EXPENSE, color: '#D2691E' },
  { id: 'pet_grooming', name: 'Pet Grooming', icon: Fa.FaCut, type: CategoryType.EXPENSE, color: '#DAA520' },
  { id: 'pet_vet', name: 'Vet', icon: Md.MdPets, type: CategoryType.EXPENSE, color: '#B22222' },
  { id: 'donation', name: 'Donation', icon: Fa.FaHandsHelping, type: CategoryType.EXPENSE, color: '#9932CC' },
  { id: 'legal', name: 'Legal', icon: Fa.FaGavel, type: CategoryType.EXPENSE, color: '#4B0082' },
  { id: 'gifts_charity', name: 'Gifts & Charity', icon: Fa.FaGift, type: CategoryType.EXPENSE, color: '#FF1493' },
  { id: 'toys', name: 'Toys', icon: Gi.GiTeddyBear, type: CategoryType.EXPENSE, color: '#FF4500' },
  { id: 'wedding', name: 'Wedding', icon: Gi.GiDiamondRing, type: CategoryType.EXPENSE, color: '#9932CC' },
  { id: 'fines', name: 'Fines', icon: Fa.FaExclamationTriangle, type: CategoryType.EXPENSE, color: '#DC143C' },
  { id: 'postage', name: 'Postage', icon: Fa.FaEnvelope, type: CategoryType.EXPENSE, color: '#4682B4' },
  { id: 'printing', name: 'Printing', icon: Fa.FaPrint, type: CategoryType.EXPENSE, color: '#2F4F4F' },
  { id: 'office', name: 'Office', icon: Fa.FaRegStickyNote, type: CategoryType.EXPENSE, color: '#CD853F' },
];

// Function to get icon by ID
export const getCategoryIconById = (id: string): CategoryIcon | undefined => {
  // Ensure case-insensitive matching to handle potential case issues
  // since some code might pass lowercase ids
  return categoryIcons.find(icon => icon.id.toLowerCase() === id.toLowerCase());
};

// Function to get filtered icons by type
export const getCategoryIconsByType = (type: CategoryType): CategoryIcon[] => {
  if (type === CategoryType.BOTH) {
    return categoryIcons;
  }
  return categoryIcons.filter(icon => icon.type === type || icon.type === CategoryType.BOTH);
};

// Function to render an icon with proper styling
export const renderCategoryIcon = (
  iconId: string, 
  size: number = 24, 
  className: string = '',
  showLabel: boolean = false,
  categoryName?: string
): JSX.Element => {
  const iconData = getCategoryIconById(iconId);

  if (!iconData || !iconData.icon) {
    // Fallback icon
    return showLabel ? (
      <div className="flex items-center gap-2">
        <Fa.FaQuestion size={size} className={className} color="#808080" />
        {showLabel && <span>{categoryName || 'Unknown'}</span>}
      </div>
    ) : (
      <Fa.FaQuestion size={size} className={className} color="#808080" />
    );
  }

  const IconComponent = iconData.icon;
  
  try {
    // Return icon with label if requested
    if (showLabel) {
      return (
        <div className="flex items-center gap-2">
          <IconComponent 
            size={size} 
            className={className} 
            color={iconData.color} 
            title={categoryName || iconData.name}
          />
          {showLabel && <span>{categoryName || iconData.name}</span>}
        </div>
      );
    }

    // Return just the icon if no label is needed
    return (
      <IconComponent 
        size={size} 
        className={className} 
        color={iconData.color} 
        title={iconData.name}
      />
    );
  } catch (error) {
    // If there's an error rendering the icon, return the fallback
    console.warn(`Error rendering icon ${iconId}:`, error);
    return showLabel ? (
      <div className="flex items-center gap-2">
        <Fa.FaQuestion size={size} className={className} color="#808080" />
        {showLabel && <span>{categoryName || iconData?.name || 'Unknown'}</span>}
      </div>
    ) : (
      <Fa.FaQuestion size={size} className={className} color="#808080" />
    );
  }
};

// Default category icons by transaction type
export const getDefaultCategoryIcon = (type: 'expense' | 'income' | 'reimbursement'): string => {
  switch (type) {
    case 'expense':
      return 'miscellaneous';
    case 'income':
      return 'salary';
    case 'reimbursement':
      return 'refunds';
    default:
      return 'miscellaneous';
  }
};