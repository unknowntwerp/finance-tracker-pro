
/**
 * Format date to DD-MM-YYYY format
 */
export const formatDate = (date: Date | string) => {
  const dateObj = new Date(date);
  const day = String(dateObj.getDate()).padStart(2, '0');
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const year = dateObj.getFullYear();
  
  return `${day}-${month}-${year}`;
}

/**
 * Format a date string into a human-readable format for Indian audience
 * @param date Date to format
 * @param format Optional format type ('short', 'medium', 'long')
 * @returns Formatted date string
 */
export const formatDateFriendly = (date: Date | string, format: 'short' | 'medium' | 'long' = 'medium') => {
  const dateObj = new Date(date);
  const day = String(dateObj.getDate()).padStart(2, '0');
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthShort = monthNames[dateObj.getMonth()];
  const year = dateObj.getFullYear();
  
  switch (format) {
    case 'short':
      // DD-MMM format (15-Apr)
      return `${day}-${monthShort}`;
    case 'long':
      // Full format with weekday
      const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const weekday = weekdays[dateObj.getDay()];
      return `${weekday}, ${day}-${monthShort}-${year}`;
    case 'medium':
    default:
      // DD-MMM-YYYY format (15-Apr-2025)
      return `${day}-${monthShort}-${year}`;
  }
}

/**
 * Format a currency amount with INR symbol
 * @param amount Numeric amount to format
 * @param showSign Whether to show the sign (+ or -) before the amount
 * @param useBrackets Whether to show negative values in brackets instead of with a minus sign
 * @returns Formatted currency string
 */
export const formatCurrency = (amount: number, showSign: boolean = false, useBrackets: boolean = false) => {
  // Format with INR symbol
  const formatted = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(Math.abs(amount));
  
  // Add sign if requested
  if (showSign) {
    return `${amount >= 0 ? '+' : '-'}${formatted}`;
  }
  
  // Use brackets for negative values if requested
  if (useBrackets && amount < 0) {
    return `(${formatted})`;
  }
  
  return amount < 0 ? `-${formatted}` : formatted;
}

/**
 * Format a percentage value
 * @param value Value to format as percentage
 * @param digits Number of decimal digits
 * @returns Formatted percentage string
 */
export const formatPercent = (value: number, digits: number = 1) => {
  return new Intl.NumberFormat('en-US', {
    style: 'percent',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(value);
}
