import { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { useFinanceStore } from '@/lib/transactionStore';
import { renderCategoryIcon, getDefaultCategoryIcon } from '@/lib/categoryIcons';
import { formatCurrency } from '@/lib/formatters';
import { useToast } from '@/hooks/use-toast';

interface AddTransactionFormProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'expense' | 'income' | 'reimbursement' | 'payment' | 'transfer';
}

export default function AddTransactionForm({ isOpen, onClose, initialType = 'expense' }: AddTransactionFormProps) {
  // Access store functionality
  const { 
    addTransaction,
    bankAccountsData,
    creditCards,
    people,
    expenseCategories,
    incomeCategories,
    categoryIcons
  } = useFinanceStore();
  
  const { toast } = useToast();

  // Form state
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<'expense' | 'income' | 'reimbursement' | 'payment' | 'transfer'>(initialType);
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionPerson, setTransactionPerson] = useState('');
  const [selectedCategoryIcon, setSelectedCategoryIcon] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);
  
  // Payment-specific state
  const [selectedCardForPayment, setSelectedCardForPayment] = useState<string>('');
  const [paymentBankAccount, setPaymentBankAccount] = useState<string>('');
  
  // Transfer-specific state
  const [transferSource, setTransferSource] = useState<string>('');
  const [transferDestination, setTransferDestination] = useState<string>('');

  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType(initialType);
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setTransactionPerson('');
    setSelectedCategoryIcon('');
    setFormError(null);
    
    // Reset payment and transfer specific fields
    setSelectedCardForPayment('');
    setPaymentBankAccount('');
    setTransferSource('');
    setTransferDestination('');
  };

  // Update when initialType changes
  useEffect(() => {
    setTransactionType(initialType);
  }, [initialType]);

  // Set defaults based on available data
  useEffect(() => {
    // Only set default account for standard transaction types
    if ((transactionType === 'expense' || transactionType === 'income' || transactionType === 'reimbursement') && 
        transactionAccount === '' && bankAccountsData.length > 0) {
      setTransactionAccount(bankAccountsData[0].name);
    }

    // Set default category based on type if available
    if (transactionCategory === '') {
      if (transactionType === 'expense' && expenseCategories.length > 0) {
        setTransactionCategory(expenseCategories[0]);
      } else if (transactionType === 'income' && incomeCategories.length > 0) {
        setTransactionCategory(incomeCategories[0]);
      }
    }

    // Set default person if needed
    if (transactionType === 'reimbursement' && transactionPerson === '' && people.length > 0) {
      setTransactionPerson(people[0]);
    }
    
    // For payment type, set CC and bank account defaults
    if (transactionType === 'payment') {
      if (selectedCardForPayment === '' && creditCards.length > 0) {
        setSelectedCardForPayment(creditCards[0].name);
      }
      if (paymentBankAccount === '' && bankAccountsData.length > 0) {
        setPaymentBankAccount(bankAccountsData[0].name);
      }
    }
    
    // For transfer type, set source and destination defaults
    if (transactionType === 'transfer') {
      if (transferSource === '' && bankAccountsData.length > 0) {
        setTransferSource(bankAccountsData[0].name);
      }
      if (transferDestination === '' && bankAccountsData.length > 1) {
        // Find the first account that's not the source
        const destinationAccount = bankAccountsData.find(account => account.name !== transferSource);
        if (destinationAccount) {
          setTransferDestination(destinationAccount.name);
        }
      }
    }
  }, [
    transactionType, 
    transactionAccount, 
    transactionCategory, 
    transactionPerson, 
    selectedCardForPayment,
    paymentBankAccount,
    transferSource,
    transferDestination,
    bankAccountsData, 
    creditCards,
    expenseCategories, 
    incomeCategories, 
    people
  ]);

  // Handle type change
  const handleTypeChange = (type: 'expense' | 'income' | 'reimbursement' | 'payment' | 'transfer') => {
    setTransactionType(type);
    setTransactionCategory('');
    setTransactionPerson('');
    setSelectedCategoryIcon('');
    
    // Reset specific form states based on type
    if (type === 'payment') {
      if (creditCards.length > 0) {
        setSelectedCardForPayment(creditCards[0].name);
      }
      if (bankAccountsData.length > 0) {
        setPaymentBankAccount(bankAccountsData[0].name);
      }
    } else if (type === 'transfer') {
      if (bankAccountsData.length > 0) {
        setTransferSource(bankAccountsData[0].name);
        if (bankAccountsData.length > 1) {
          setTransferDestination(bankAccountsData[1].name);
        }
      }
    } else {
      // Reset payment and transfer specific fields
      setSelectedCardForPayment('');
      setPaymentBankAccount('');
      setTransferSource('');
      setTransferDestination('');
      
      // Set default categories for expense and income
      if (type === 'expense' && expenseCategories.length > 0) {
        setTransactionCategory(expenseCategories[0]);
      } else if (type === 'income' && incomeCategories.length > 0) {
        setTransactionCategory(incomeCategories[0]);
      }
    }
  };

  // Handle form submission
  const handleAddTransaction = () => {
    // Clear previous errors
    setFormError(null);
    
    // Common validations
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }

    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }
    
    const amount = parseFloat(transactionAmount);
    
    // Type-specific validations and actions
    if (transactionType === 'payment') {
      // Credit Card Payment validation
      if (!selectedCardForPayment) {
        setFormError("Please select a credit card");
        return;
      }
      
      if (!paymentBankAccount) {
        setFormError("Please select a bank account to pay from");
        return;
      }
      
      // Set the description automatically
      const paymentDescription = `Credit Card Payment`;
      
      // Handle credit card payment (create two transactions)
      // For bank account: negative amount (money goes out)
      addTransaction({
        date: transactionDate,
        type: "expense",
        description: `Payment to ${selectedCardForPayment}`,
        amount: amount,
        account: paymentBankAccount,
        category: "Credit Card Payment"
      });
      
      // For credit card: negative amount (reduces outstanding debt)
      addTransaction({
        date: transactionDate, 
        type: "expense",
        description: `Payment received from ${paymentBankAccount}`,
        amount: -amount, // Negative for credit card (reduces outstanding debt)
        account: selectedCardForPayment,
        category: "Credit Card Payment"
      });
      
      toast({
        title: "Payment Recorded",
        description: `Successfully recorded payment of ${formatCurrency(amount)} to ${selectedCardForPayment}.`,
        duration: 3000,
      });
    } 
    else if (transactionType === 'transfer') {
      // Bank Transfer validation
      if (!transferSource) {
        setFormError("Please select a source account");
        return;
      }
      
      if (!transferDestination) {
        setFormError("Please select a destination account");
        return;
      }
      
      if (transferSource === transferDestination) {
        setFormError("Source and destination accounts must be different");
        return;
      }
      
      // Add outgoing transaction from source account
      addTransaction({
        date: transactionDate,
        type: "contra",
        description: `Transfer to ${transferDestination}`,
        amount: amount,
        account: transferSource,
        category: "Transfer"
      });
      
      // Add incoming transaction to destination account
      addTransaction({
        date: transactionDate,
        type: "contra",
        description: `Transfer from ${transferSource}`,
        amount: -amount, // Negative for destination to match contra pattern
        account: transferDestination,
        category: "Transfer"
      });
      
      toast({
        title: "Transfer Complete",
        description: `Successfully transferred ${formatCurrency(amount)} from ${transferSource} to ${transferDestination}.`,
        duration: 3000,
      });
    }
    else {
      // Normal transaction validation
      if (!transactionDescription.trim()) {
        setFormError("Description is required");
        return;
      }
      
      if (!transactionAccount) {
        setFormError("Account is required");
        return;
      }
      
      if (transactionType === 'reimbursement' && !transactionPerson.trim()) {
        setFormError("Person's name is required for reimbursements");
        return;
      }
      
      if ((transactionType === 'expense' || transactionType === 'income') && !transactionCategory) {
        setFormError("Category is required");
        return;
      }
      
      // Create and add the standard transaction
      addTransaction({
        date: transactionDate,
        type: transactionType,
        description: transactionDescription,
        amount: amount,
        account: transactionAccount,
        category: transactionCategory,
        categoryIcon: selectedCategoryIcon || getDefaultCategoryIcon(transactionType),
        person: transactionType === 'reimbursement' ? transactionPerson : undefined
      });
      
      toast({
        title: "Transaction Added",
        description: "Your transaction has been successfully added.",
        duration: 3000,
      });
    }

    // Close the modal and reset form
    onClose();
    resetForm();
  };

  // When dialog is opened, reset form if needed
  useEffect(() => {
    if (isOpen) {
      resetForm();
    }
  }, [isOpen]);

  // Get appropriate style based on transaction type
  const getHeaderStyle = () => {
    switch (transactionType) {
      case 'expense':
        return {
          background: 'linear-gradient(135deg, #FFB3BA 0%, #FFDAC1 100%)',
          color: '#333333' // Changed to dark text for better visibility
        };
      case 'income':
        return {
          background: 'linear-gradient(135deg, #B5EAD7 0%, #C7F0BD 100%)',
          color: '#333333' // Changed to dark text for better visibility
        };
      case 'reimbursement':
        return {
          background: 'linear-gradient(135deg, #D8B4FE 0%, #E8CBF8 100%)',
          color: '#333333' // Changed to dark text for better visibility
        };
      case 'payment':
        return {
          background: 'linear-gradient(135deg, #A2D2FF 0%, #BDE0FE 100%)',
          color: '#333333' // Changed to dark text for better visibility
        };
      case 'transfer':
        return {
          background: 'linear-gradient(135deg, #C1C8E4 0%, #D4D8F5 100%)',
          color: '#333333' // Changed to dark text for better visibility
        };
      default:
        return {};
    }
  };

  // Get appropriate transaction type title
  const getTransactionTypeTitle = () => {
    switch (transactionType) {
      case 'expense':
        return 'Add Expense';
      case 'income':
        return 'Add Income';
      case 'reimbursement':
        return 'Add Reimbursement';
      case 'payment':
        return 'Add Credit Card Payment';
      case 'transfer':
        return 'Add Bank Transfer';
      default:
        return 'Add New Transaction';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="modal-content p-0 sm:max-w-[550px]">
        <div className="modal-header" style={getHeaderStyle()}>
          <DialogTitle className="modal-title" style={{color: getHeaderStyle().color}}>{getTransactionTypeTitle()}</DialogTitle>
        </div>

        <div className="p-6 grid gap-4">
          {formError && (
            <div className="bg-red-50 text-red-800 p-3 rounded-md text-sm">
              {formError}
            </div>
          )}
          
          <div className="p-3 rounded-md text-sm flex items-center gap-2" style={{
            backgroundColor: transactionType === 'expense' ? 'rgba(255, 179, 186, 0.2)' : 
                             transactionType === 'income' ? 'rgba(181, 234, 215, 0.2)' :
                             transactionType === 'reimbursement' ? 'rgba(216, 180, 254, 0.2)' :
                             transactionType === 'payment' ? 'rgba(162, 210, 255, 0.2)' :
                             transactionType === 'transfer' ? 'rgba(193, 200, 228, 0.2)' : '',
            color: transactionType === 'expense' ? '#FF6B6B' : 
                   transactionType === 'income' ? '#00B894' :
                   transactionType === 'reimbursement' ? '#9B59B6' :
                   transactionType === 'payment' ? '#3D8BCF' :
                   transactionType === 'transfer' ? '#6866A8' : ''
          }}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
            <span>Press <kbd className="px-2 py-0.5 rounded bg-white border shadow-sm mx-1 text-xs font-mono">Alt + A</kbd> anywhere in the app to open this form</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <Select
                value={transactionType}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                  <SelectItem value="reimbursement">Reimbursement</SelectItem>
                  <SelectItem value="payment">Credit Card Payment</SelectItem>
                  <SelectItem value="transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Description field only for regular transactions */}
          {(transactionType === 'expense' || transactionType === 'income' || transactionType === 'reimbursement') && (
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="amount">Amount (₹)</Label>
            <Input
              id="amount"
              type="number"
              min="0"
              step="0.01"
              placeholder="Enter amount"
              value={transactionAmount}
              onChange={(e) => setTransactionAmount(e.target.value)}
            />
          </div>

          {/* Account field only for regular transactions */}
          {(transactionType === 'expense' || transactionType === 'income' || transactionType === 'reimbursement') && (
            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select
                value={transactionAccount}
                onValueChange={(value) => setTransactionAccount(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData && bankAccountsData.map((account: any) => (
                    <SelectItem key={account.id} value={account.name}>
                      {account.name}
                    </SelectItem>
                  ))}
                  {creditCards && creditCards.map((card: any) => (
                    <SelectItem key={card.id} value={card.name}>
                      {card.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

{/* Credit Card Payment Fields */}
          {transactionType === 'payment' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="creditCard">Credit Card</Label>
                <Select
                  value={selectedCardForPayment}
                  onValueChange={(value) => setSelectedCardForPayment(value)}
                >
                  <SelectTrigger id="credit-card">
                    <SelectValue placeholder="Select credit card" />
                  </SelectTrigger>
                  <SelectContent>
                    {creditCards.map((card: any) => (
                      <SelectItem key={card.id} value={card.name}>
                        {card.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentBankAccount">Pay From</Label>
                <Select
                  value={paymentBankAccount}
                  onValueChange={(value) => setPaymentBankAccount(value)}
                >
                  <SelectTrigger id="payment-bank-account">
                    <SelectValue placeholder="Select bank account" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccountsData.map((account: any) => (
                      <SelectItem key={account.id} value={account.name}>
                        {account.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="p-3 rounded-md text-sm" style={{ 
                background: 'rgba(162, 210, 255, 0.2)',
                color: '#3D8BCF'
              }}>
                <p>This will create a payment transaction from your bank account to your credit card.</p>
              </div>
            </>
          )}

          {/* Bank Transfer Fields */}
          {transactionType === 'transfer' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="transferSource">Transfer From</Label>
                <Select
                  value={transferSource}
                  onValueChange={(value) => setTransferSource(value)}
                >
                  <SelectTrigger id="transfer-source">
                    <SelectValue placeholder="Select source account" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccountsData.map((account: any) => (
                      <SelectItem key={account.id} value={account.name}>
                        {account.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="transferDestination">Transfer To</Label>
                <Select
                  value={transferDestination}
                  onValueChange={(value) => setTransferDestination(value)}
                >
                  <SelectTrigger id="transfer-destination">
                    <SelectValue placeholder="Select destination account" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccountsData
                      .filter(account => account.name !== transferSource)
                      .map((account: any) => (
                        <SelectItem key={account.id} value={account.name}>
                          {account.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="p-3 rounded-md text-sm" style={{ 
                background: 'rgba(193, 200, 228, 0.2)',
                color: '#6866A8'
              }}>
                <p>This will create a pair of transactions to transfer money between accounts.</p>
              </div>
            </>
          )}

          {/* Standard Transaction Fields for expense, income, reimbursement */}
          {(transactionType === 'expense' || transactionType === 'income' || transactionType === 'reimbursement') && (
            <div className="space-y-2">
              <Label htmlFor="category">
                {transactionType === 'reimbursement' ? 'Person' : 'Category'}
              </Label>
              {transactionType === 'reimbursement' ? (
                <Select
                  value={transactionPerson}
                  onValueChange={(value) => setTransactionPerson(value)}
                >
                  <SelectTrigger id="quick-person">
                    <SelectValue placeholder="Select person" />
                  </SelectTrigger>
                  <SelectContent>
                    {people.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Select
                  value={transactionCategory}
                  onValueChange={(value) => setTransactionCategory(value)}
                >
                  <SelectTrigger id="quick-category">
                    <SelectValue placeholder={`Select ${transactionType === 'expense' ? 'expense' : 'income'} category`} />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionType === 'expense' ? (
                      expenseCategories.map((category: string) => {
                        // Get icon ID for this category
                        const iconInfo = useFinanceStore.getState().categoryIcons?.find((c: any) => 
                          c.category === category && c.type === 'expense'
                        );
                        const iconId = iconInfo?.iconId || getDefaultCategoryIcon('expense');

                        return (
                          <SelectItem key={category} value={category}>
                            <div className="flex items-center gap-2">
                              {renderCategoryIcon(iconId, 16)}
                              <span>{category}</span>
                            </div>
                          </SelectItem>
                        );
                      })
                    ) : (
                      incomeCategories.map((category: string) => {
                        // Get icon ID for this category
                        const iconInfo = useFinanceStore.getState().categoryIcons?.find((c: any) => 
                          c.category === category && c.type === 'income'
                        );
                        const iconId = iconInfo?.iconId || getDefaultCategoryIcon('income');

                        return (
                          <SelectItem key={category} value={category}>
                            <div className="flex items-center gap-2">
                              {renderCategoryIcon(iconId, 16)}
                              <span>{category}</span>
                            </div>
                          </SelectItem>
                        );
                      })
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}
        </div>

        <div className="modal-footer">
          <Button 
            variant="outline" 
            onClick={() => {
              onClose();
              resetForm();
            }}
            className="modal-button-secondary"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleAddTransaction}
            className="modal-button-primary text-white border-none"
            style={
              transactionType === 'expense' ? 
                { background: 'linear-gradient(135deg, #FFB3BA 0%, #FFDAC1 100%)' } :
              transactionType === 'income' ? 
                { background: 'linear-gradient(135deg, #B5EAD7 0%, #C7F0BD 100%)' } :
              transactionType === 'reimbursement' ? 
                { background: 'linear-gradient(135deg, #D8B4FE 0%, #E8CBF8 100%)' } :
              transactionType === 'payment' ? 
                { background: 'linear-gradient(135deg, #A2D2FF 0%, #BDE0FE 100%)' } :
              transactionType === 'transfer' ? 
                { background: 'linear-gradient(135deg, #C1C8E4 0%, #D4D8F5 100%)' } :
                {}
            }
          >
            Add Transaction
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}