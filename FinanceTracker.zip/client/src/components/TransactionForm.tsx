import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { insertTransactionSchema, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend the transaction schema to include validation
const transactionFormSchema = insertTransactionSchema.extend({
  amount: z.number().positive("Amount must be positive"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
});

type TransactionFormValues = z.infer<typeof transactionFormSchema>;

export default function TransactionForm() {
  const [transactionType, setTransactionType] = useState<"expense" | "income">("expense");
  const { toast } = useToast();

  // Set up form with validation
  const form = useForm<TransactionFormValues>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      amount: 0,
      description: "",
      category: "",
      type: "expense",
      userId: 1, // Default user ID for demo
      date: new Date(),
    },
  });

  // Handle transaction mutation
  const mutation = useMutation({
    mutationFn: async (data: TransactionFormValues) => {
      const response = await apiRequest("POST", "/api/transactions", data);
      return response.json();
    },
    onSuccess: () => {
      // Reset form
      form.reset({
        amount: 0,
        description: "",
        category: "",
        type: transactionType,
        userId: 1,
        date: new Date(),
      });
      
      // Show success message
      toast({
        title: "Transaction Added",
        description: "Your transaction has been added successfully.",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/summary'] });
      queryClient.invalidateQueries({ queryKey: ['/api/category-breakdown'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add transaction: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: TransactionFormValues) => {
    mutation.mutate(data);
  };

  // Handle transaction type change
  const handleTransactionTypeChange = (value: "expense" | "income") => {
    setTransactionType(value);
    form.setValue("type", value);
    form.setValue("category", ""); // Reset category when type changes
  };

  // Format category for display
  const formatCategoryName = (category: string) => {
    return category
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  return (
    <Card>
      <CardHeader className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold">Add Transaction</h2>
      </CardHeader>
      <CardContent className="p-4">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {/* Transaction Type Selection */}
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Transaction Type</Label>
            <RadioGroup 
              value={transactionType} 
              onValueChange={(value) => handleTransactionTypeChange(value as "expense" | "income")}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="expense" id="expense" />
                <Label htmlFor="expense">Expense</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="income" id="income" />
                <Label htmlFor="income">Income</Label>
              </div>
            </RadioGroup>
          </div>
          
          {/* Amount Field */}
          <div>
            <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">Amount</Label>
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">$</span>
              </div>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                className="pl-7 pr-12"
                {...form.register("amount", { valueAsNumber: true })}
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">USD</span>
              </div>
            </div>
            {form.formState.errors.amount && (
              <p className="mt-1 text-sm text-red-600">{form.formState.errors.amount.message}</p>
            )}
          </div>
          
          {/* Description Field */}
          <div>
            <Label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</Label>
            <Input 
              id="description" 
              {...form.register("description")}
            />
            {form.formState.errors.description && (
              <p className="mt-1 text-sm text-red-600">{form.formState.errors.description.message}</p>
            )}
          </div>
          
          {/* Category Field */}
          <div>
            <Label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category</Label>
            <Select 
              onValueChange={(value) => form.setValue("category", value)}
              value={form.watch("category")}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {transactionType === "expense" ? (
                  EXPENSE_CATEGORIES.map((category) => (
                    <SelectItem key={category} value={category}>
                      {formatCategoryName(category)}
                    </SelectItem>
                  ))
                ) : (
                  INCOME_CATEGORIES.map((category) => (
                    <SelectItem key={category} value={category}>
                      {formatCategoryName(category)}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            {form.formState.errors.category && (
              <p className="mt-1 text-sm text-red-600">{form.formState.errors.category.message}</p>
            )}
          </div>
          
          {/* Date Field */}
          <div>
            <Label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Date</Label>
            <Input 
              id="date" 
              type="date" 
              {...form.register("date", { 
                valueAsDate: true,
                value: new Date().toISOString().split('T')[0]
              })}
            />
          </div>
          
          {/* Submit Button */}
          <Button 
            type="submit" 
            className="w-full justify-center py-2 px-4 bg-primary hover:bg-primary-dark"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Adding..." : "Add Transaction"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
