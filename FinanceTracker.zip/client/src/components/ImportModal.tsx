import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { parseExcelFile, Transaction, generateExcelTemplate } from "@/lib/excelUtils";
import { useFinanceStore } from "@/lib/transactionStore";
import { CheckCircle, AlertCircle, X, FileText, Download, FileWarning } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import * as ExcelJS from 'exceljs';
import * as FileSaver from 'file-saver';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: File | null;
}

interface ImportSummary {
  totalRows: number;
  successRows: number;
  errorRows: number;
  errors: string[];
}

export default function ImportModal({ isOpen, onClose, file }: ImportModalProps) {
  const [isImporting, setIsImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const { addTransactions } = useFinanceStore();
  const { toast } = useToast();

  useEffect(() => {
    // Start import process when modal is opened
    if (isOpen && file && !summary) {
      processImport();
    }
  }, [isOpen, file, summary]);

  async function processImport() {
    if (!file) return;

    try {
      setIsImporting(true);
      setProgress(10);

      let transactions: Transaction[] = [];
      let importErrors: string[] = [];
      
      try {
        // Parse Excel file - validation of all rows happens inside parseExcelFile now
        transactions = await parseExcelFile(file);
        setProgress(50);
      } catch (parseError) {
        console.error("Excel parsing error:", parseError);
        
        // Extract error messages if available
        if (parseError instanceof Error && parseError.message.includes("Validation errors")) {
          const errorMsg = parseError.message;
          importErrors = errorMsg.split('\n').filter(line => line.trim() !== "Validation errors in the Excel file:");
          
          // Check if there are any valid transactions despite the errors
          if ((parseError as any).validTransactions && Array.isArray((parseError as any).validTransactions)) {
            // Still get the valid transactions even though there were errors
            transactions = (parseError as any).validTransactions;
            console.log(`Found ${transactions.length} valid transactions despite validation errors`);
          }
          
          // If we have direct access to the errors list, use that
          if ((parseError as any).errorsList && Array.isArray((parseError as any).errorsList)) {
            importErrors = (parseError as any).errorsList;
          }
        } else {
          importErrors = [parseError instanceof Error ? parseError.message : "Unknown error during file parsing"];
        }
      }

      if ((!transactions || transactions.length === 0) && importErrors.length === 0) {
        setSummary({
          totalRows: 0,
          successRows: 0,
          errorRows: 0,
          errors: ["No valid transactions found in the file."]
        });
        setIsImporting(false);
        return;
      }

      setProgress(70);

      // Now that validation is done in parseExcelFile, we just need to add the transactions
      // All transactions in the array are already validated and ready to import
      if (transactions.length > 0) {
        // Import transactions
        addTransactions(transactions);
      }

      setProgress(100);
      setSummary({
        totalRows: transactions.length + importErrors.length,
        successRows: transactions.length,
        errorRows: importErrors.length,
        errors: importErrors
      });
    } catch (error) {
      console.error("Import error:", error);
      setSummary({
        totalRows: 0,
        successRows: 0,
        errorRows: 1,
        errors: [error instanceof Error ? error.message : "Unknown error occurred"]
      });
    } finally {
      setIsImporting(false);
    }
  }

  const resetAndClose = () => {
    setSummary(null);
    setProgress(0);
    onClose();
  };
  
  // Create our own template for error rows with the actual data from the original file
  const generateErrorTemplate = async () => {
    if (!file || !summary?.errors) return;

    try {
      setIsDownloading(true);

      // Extract row numbers from error messages
      const errorRowNumbers = summary.errors
        .map(error => {
          const match = error.match(/Row (\d+):/);
          return match ? parseInt(match[1]) : null;
        })
        .filter(rowNum => rowNum !== null) as number[];
        
      if (errorRowNumbers.length === 0) {
        toast({
          title: "Cannot Generate Error Template",
          description: "No specific rows identified in the error messages.",
          variant: "destructive",
        });
        return;
      }

      // Read the file to extract the data from the error rows
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        try {
          if (!e.target || !e.target.result) {
            throw new Error("Failed to read file content");
          }

          const fileBuffer = e.target.result;
          const originalWorkbook = new ExcelJS.Workbook();
          await originalWorkbook.xlsx.load(fileBuffer as ArrayBuffer);
          
          // Get the worksheet from the original file
          let originalWorksheet = originalWorkbook.getWorksheet("Transaction Import");
          if (!originalWorksheet) {
            originalWorksheet = originalWorkbook.getWorksheet(1);
          }
          
          if (!originalWorksheet) {
            throw new Error("Could not find worksheet in the original file");
          }

          // Get data from our store
          const state = useFinanceStore.getState();
          const bankAccounts = state.bankAccountsData.map(account => account.name);
          const creditCards = state.creditCards;
          const expenseCategories = state.expenseCategories;
          const incomeCategories = state.incomeCategories;
          const peopleData = state.people;
          
          // Combine bank accounts and credit card names
          const allAccounts = [...bankAccounts, ...creditCards.map(card => card.name)];
          
          // Create a new workbook for the error template
          const workbook = new ExcelJS.Workbook();
          workbook.creator = "Finance Tracker Pro";
          workbook.lastModifiedBy = "Finance Tracker Pro";
          workbook.created = new Date();
          workbook.modified = new Date();
          
          // Create the Transaction Import worksheet FIRST so it appears as the active/default sheet when opening
          const transactionSheet = workbook.addWorksheet("Transaction Import", {
            properties: { tabColor: { argb: "FFC0000" } }
          });
          
          // Create a hidden Data Sheet for dropdowns
          const dataSheet = workbook.addWorksheet('Data', { state: 'hidden' });
          
          // Set up columns in data sheet for each dropdown type
          dataSheet.getColumn('A').header = 'Transaction Types';
          dataSheet.getColumn('B').header = 'Accounts';
          dataSheet.getColumn('C').header = 'Expense Categories';
          dataSheet.getColumn('D').header = 'Income Categories';
          dataSheet.getColumn('E').header = 'People';
          
          // Add transaction types
          const transactionTypes = ["expense", "income", "reimbursement"];
          transactionTypes.forEach((type, index) => {
            dataSheet.getCell(`A${index + 2}`).value = type;
          });
          
          // Add account options
          allAccounts.forEach((account, index) => {
            dataSheet.getCell(`B${index + 2}`).value = account;
          });
          
          // Add expense category options
          expenseCategories.forEach((category, index) => {
            dataSheet.getCell(`C${index + 2}`).value = category;
          });
          
          // Add income category options
          incomeCategories.forEach((category, index) => {
            dataSheet.getCell(`D${index + 2}`).value = category;
          });
          
          // Add people options
          peopleData.forEach((person, index) => {
            dataSheet.getCell(`E${index + 2}`).value = person;
          });
          
          // Create instructions worksheet
          const instructionsSheet = workbook.addWorksheet("Instructions", {
            properties: { tabColor: { argb: "FF0000FF" } }
          });
          
          // Add instructions to the Instructions sheet
          instructionsSheet.getColumn('A').width = 100;
          
          // Add header
          const instructionsHeader = instructionsSheet.addRow(["Transaction Import Template Instructions"]);
          instructionsHeader.font = { bold: true, size: 14 };
          instructionsHeader.height = 30;
          
          // Add detailed instructions
          instructionsSheet.addRow(["INSTRUCTIONS: Fill in transaction details in the Transaction Import sheet. The template validates your entries."]);
          instructionsSheet.addRow([""]);
          instructionsSheet.addRow(["How to use this template:"]);
          instructionsSheet.addRow(["1. Fill in transaction details in the Transaction Import sheet"]);
          instructionsSheet.addRow(["2. Use the dropdown lists to select valid options"]);
          instructionsSheet.addRow(["3. For income transactions, use income categories"]);
          instructionsSheet.addRow(["4. For expense transactions, use expense categories"]);
          instructionsSheet.addRow(["5. For reimbursements, select a person in the category field"]);
          instructionsSheet.addRow([""]);
          instructionsSheet.addRow(["Category/Person field:"]);
          instructionsSheet.addRow(["- Use expense categories for expenses"]);
          instructionsSheet.addRow(["- Use income categories for income"]);
          instructionsSheet.addRow(["- Use person names for reimbursements"]);
          
          // Add column headers with formatting
          const headers = [
            { header: "Date (DD-MM-YYYY)", key: "date", width: 20 },
            { header: "Type", key: "type", width: 15 },
            { header: "Description", key: "description", width: 30 },
            { header: "Amount (Positive)", key: "amount", width: 15 },
            { header: "Account", key: "account", width: 20 },
            { header: "Category/Person", key: "category", width: 25 }
          ];
          
          transactionSheet.columns = headers;
          
          // Format headers - now in row 1
          const worksheetHeaderRow = transactionSheet.getRow(1);
          worksheetHeaderRow.eachCell(cell => {
            cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
            cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF333333" } };
          });
          
          // Add error rows with actual data from the original file
          for (const rowNum of errorRowNumbers) {
            const originalRow = originalWorksheet.getRow(rowNum);
            
            // Extract values from the original row with proper type handling
            let dateValue = originalRow.getCell(1).value;
            
            // Handle date specifically to ensure it's preserved correctly
            if (dateValue instanceof Date) {
              // Keep as a Date object for Excel
              // No need to convert - Excel will handle it properly
              console.log("Found date value:", dateValue);
            } else if (typeof dateValue === 'string' && dateValue.includes('-')) {
              // Try to parse string dates like "DD-MM-YYYY" or "YYYY-MM-DD" to proper Date objects
              try {
                const parts = dateValue.split('-');
                // Check format based on part lengths
                if (parts.length === 3) {
                  if (parts[0].length === 4) {
                    // YYYY-MM-DD format
                    dateValue = new Date(parseInt(parts[0]), parseInt(parts[1])-1, parseInt(parts[2]));
                  } else if (parts[2].length === 4) {
                    // DD-MM-YYYY format
                    dateValue = new Date(parseInt(parts[2]), parseInt(parts[1])-1, parseInt(parts[0]));
                  }
                  console.log("Converted string date to Date object:", dateValue);
                }
              } catch (e) {
                console.log("Failed to parse date string:", dateValue, e);
                // If parsing fails, keep original string value
              }
            }
            
            const type = originalRow.getCell(2).value?.toString() || '';
            const description = originalRow.getCell(3).value?.toString() || '';
            const amount = Number(originalRow.getCell(4).value) || 0;
            const account = originalRow.getCell(5).value?.toString() || '';
            const category = originalRow.getCell(6).value?.toString() || '';
            
            // Add a row to the new template worksheet
            const errorRow = transactionSheet.addRow({
              date: dateValue,
              type,
              description,
              amount,
              account,
              category
            });
            
            // Highlight the row with light red background to indicate it had an error
            errorRow.eachCell(cell => {
              cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFDDDD" } };
            });
            
            // Apply formatting
            errorRow.getCell(1).numFmt = 'dd-mm-yyyy';
            errorRow.getCell(4).numFmt = '#,##0.00';
          }
          
          // Add an error section to the instructions sheet
          instructionsSheet.addRow([""]);
          instructionsSheet.addRow([""]);
          
          // Add error-specific instructions 
          const errorInstructionsRow = instructionsSheet.addRow(["Error Template Information"]);
          errorInstructionsRow.font = { bold: true, size: 14 };
          errorInstructionsRow.height = 30;
          
          // Add detailed instructions about errors
          instructionsSheet.addRow(["This template contains only the rows that had validation errors during import."]);
          instructionsSheet.addRow(["The rows are formatted with a light red background to indicate they need correction."]);
          instructionsSheet.addRow(["Please fix these rows and try importing again."]);
          instructionsSheet.addRow([""]);
          
          const errorTitle = instructionsSheet.addRow(["Common Import Errors:"]);
          errorTitle.font = { bold: true };
          
          instructionsSheet.addRow(["1. Invalid transaction type: Must be 'expense', 'income', or 'reimbursement'"]);
          instructionsSheet.addRow(["2. Invalid account: Must match one of your existing accounts"]);
          instructionsSheet.addRow(["3. Invalid category: Must match existing categories based on transaction type"]);
          instructionsSheet.addRow(["4. Amount must be a positive number"]);
          instructionsSheet.addRow([""]);
          
          const importNote = instructionsSheet.addRow(["Note: Rows already successfully imported will not appear in this template to prevent duplication."]);
          importNote.font = { italic: true };
          
          // Define dropdown references
          const typeRef = `Data!$A$2:$A$${transactionTypes.length + 1}`;
          const accountRef = `Data!$B$2:$B$${allAccounts.length + 1}`;
          const expenseCategoryRef = `Data!$C$2:$C$${expenseCategories.length + 1}`;
          const incomeCategoryRef = `Data!$D$2:$D$${incomeCategories.length + 1}`;
          const peopleRef = `Data!$E$2:$E$${peopleData.length + 1}`;
          
          // Set validation for rows (starting after header row)
          for (let i = 2; i <= errorRowNumbers.length + 10; i++) {
            // Date column (A)
            const dateCell = transactionSheet.getCell(`A${i}`);
            dateCell.numFmt = 'dd-mm-yyyy';
            dateCell.dataValidation = {
              type: 'date',
              allowBlank: false,
              showErrorMessage: true,
              errorStyle: 'stop',
              error: 'Please enter a valid date in DD-MM-YYYY format',
              errorTitle: 'Invalid Date',
              showInputMessage: true,
              promptTitle: 'Date',
              prompt: 'Enter date in DD-MM-YYYY format',
              formulae: [new Date(2000, 0, 1), new Date(2050, 11, 31)]
            };
            
            // Type column (B)
            transactionSheet.getCell(`B${i}`).dataValidation = {
              type: 'list',
              allowBlank: false,
              showErrorMessage: true,
              errorStyle: 'stop',
              error: 'Please select a transaction type from the dropdown list',
              errorTitle: 'Invalid Transaction Type',
              showInputMessage: true,
              promptTitle: 'Transaction Type',
              prompt: 'Select expense, income, or reimbursement',
              formulae: [typeRef]
            };
            
            // Amount column (D)
            const amountCell = transactionSheet.getCell(`D${i}`);
            amountCell.numFmt = '#,##0.00';
            amountCell.dataValidation = {
              type: 'decimal',
              operator: 'greaterThan',
              allowBlank: false,
              showErrorMessage: true,
              errorStyle: 'stop',
              error: 'Amount must be a positive number',
              errorTitle: 'Invalid Amount',
              showInputMessage: true,
              promptTitle: 'Amount',
              prompt: 'Enter a positive amount',
              formulae: [0]
            };
            
            // Account column (E)
            transactionSheet.getCell(`E${i}`).dataValidation = {
              type: 'list',
              allowBlank: false,
              showErrorMessage: true,
              errorStyle: 'stop',
              error: 'Please select a value from the dropdown list',
              errorTitle: 'Invalid Entry',
              showInputMessage: true,
              promptTitle: 'Account',
              prompt: 'Select an account from the dropdown list',
              formulae: [accountRef]
            };
            
            // Category/Person column (F) with conditional validation
            const categoryCell = transactionSheet.getCell(`F${i}`);
            const formulaText = `=IF(B${i}="income",${incomeCategoryRef},IF(B${i}="expense",${expenseCategoryRef},${peopleRef}))`;
            categoryCell.dataValidation = {
              type: 'list',
              allowBlank: false,
              showErrorMessage: true,
              errorStyle: 'stop',
              error: 'Please select a valid option for your transaction type',
              errorTitle: 'Invalid Selection',
              showInputMessage: true,
              promptTitle: 'Category/Person',
              prompt: 'For income use income categories, for expenses use expense categories, for reimbursements select a person',
              formulae: [formulaText]
            };
          }
          
          // Generate Excel buffer and trigger download
          const outputBuffer = await workbook.xlsx.writeBuffer();
          const blob = new Blob([outputBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
          const filename = `finance_tracker_fix_errors_${new Date().toISOString().slice(0, 10)}.xlsx`;
          
          // Use FileSaver to trigger the download
          FileSaver.saveAs(blob, filename);
          
          toast({
            title: "Error Template Downloaded",
            description: "Template with problematic rows has been downloaded. Fix these rows and re-import.",
            variant: "default",
          });
        } catch (err) {
          console.error("Error creating error template:", err);
          toast({
            title: "Download Failed",
            description: "There was an error processing the file. Please try downloading a fresh template instead.",
            variant: "destructive",
          });
        } finally {
          setIsDownloading(false);
        }
      };
      
      reader.onerror = () => {
        toast({
          title: "Download Failed",
          description: "There was an error reading the file. Please try downloading a fresh template instead.",
          variant: "destructive",
        });
        setIsDownloading(false);
      };
      
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("Top-level error:", error);
      toast({
        title: "Download Failed",
        description: "There was an error downloading the template. Please try again.",
        variant: "destructive",
      });
      setIsDownloading(false);
    }
  };
  
  const handleDownloadTemplate = async (errorRowsOnly = false) => {
    try {
      setIsDownloading(true);
      if (errorRowsOnly && summary?.errors) {
        // Use our custom error template generator instead
        await generateErrorTemplate();
      } else {
        // Download fresh template
        await generateExcelTemplate();
        toast({
          title: "Template Downloaded",
          description: "Fresh Excel template has been downloaded with data validations.",
          variant: "default",
        });
        setIsDownloading(false);
      }
    } catch (error) {
      console.error("Error downloading template:", error);
      toast({
        title: "Download Failed",
        description: "There was an error downloading the template. Please try again.",
        variant: "destructive",
      });
      setIsDownloading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && resetAndClose()}>
      <DialogContent className="sm:max-w-md md:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isImporting
              ? "Importing Transactions..."
              : summary
                ? summary.errorRows === 0
                  ? "Import Completed"
                  : "Import Results"
                : "Processing File"}
          </DialogTitle>
        </DialogHeader>

        <div className="py-6">
          {isImporting && (
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
              <Progress value={progress} className="w-full h-2" />
              <p className="text-center text-sm text-gray-600">
                {progress < 20
                  ? "Reading Excel file..."
                  : progress < 60
                    ? "Processing transactions..."
                    : "Saving transactions..."}
              </p>
            </div>
          )}

          {!isImporting && summary && (
            <div className="space-y-4">
              {summary.successRows > 0 && (
                <Alert variant="default" className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-800">Import successful</AlertTitle>
                  <AlertDescription className="text-green-700">
                    Successfully imported {summary.successRows} {summary.successRows === 1 ? "transaction" : "transactions"}.
                  </AlertDescription>
                </Alert>
              )}

              {summary.errorRows > 0 && (
                <Alert variant="destructive" className="bg-red-50 border-red-200 text-red-800">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertTitle>Import issues</AlertTitle>
                  <AlertDescription>
                    <p className="mb-2">
                      {summary.errorRows} {summary.errorRows === 1 ? "row" : "rows"} couldn't be imported due to errors.
                    </p>
                    {summary.errors.length > 0 && (
                      <div className="mt-2 text-xs max-h-40 overflow-y-auto bg-red-100 p-2 rounded">
                        <p className="mb-2 font-medium text-red-700">Validation errors:</p>
                        <ul className="list-disc pl-4 space-y-1">
                          {/* Only show max 3 errors to keep it concise */}
                          {summary.errors.slice(0, 3).map((error, index) => {
                            // Make errors more concise by trimming long lists
                            let shortenedError = error;
                            if (error.includes("Must be one of:")) {
                              shortenedError = error.split("Must be one of:")[0] + "Must be a valid value from the app.";
                            }
                            return <li key={index} className="text-xs">{shortenedError}</li>;
                          })}
                          {summary.errors.length > 3 && (
                            <li className="text-xs text-red-700 font-medium">
                              And {summary.errors.length - 3} more errors...
                            </li>
                          )}
                        </ul>
                        <div className="mt-3 pt-2 border-t border-red-200">
                          <p className="font-medium text-red-700">Common fixes:</p>
                          <ul className="list-disc pl-4 mt-1">
                            <li>Use only valid categories from the app</li>
                            <li>Use only existing account names</li> 
                            <li>Make sure Transaction Type is correct</li>
                          </ul>
                        </div>
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                <h4 className="text-sm font-medium mb-2">Import Summary</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-gray-600">Total rows processed:</span>
                    <span className="font-medium">{summary.totalRows}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Successfully imported:</span>
                    <span className="font-medium text-green-600">{summary.successRows}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Failed rows:</span>
                    <span className="font-medium text-red-600">{summary.errorRows}</span>
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex flex-col-reverse sm:flex-row sm:justify-between sm:space-x-2">
          {isImporting ? (
            <Button disabled>
              Processing...
            </Button>
          ) : (
            <>
              {/* Show template buttons when there are errors */}
              {summary && summary.errorRows > 0 && (
                <div className="flex flex-col sm:flex-row gap-2 mb-2 sm:mb-0">
                  <Button 
                    variant="outline" 
                    onClick={() => handleDownloadTemplate(true)} 
                    disabled={isDownloading}
                  >
                    <FileWarning className="mr-2 h-4 w-4" />
                    {isDownloading ? "Downloading..." : "Fix Error Rows"}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleDownloadTemplate(false)} 
                    disabled={isDownloading}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {isDownloading ? "Downloading..." : "New Template"}
                  </Button>
                </div>
              )}
              <Button onClick={resetAndClose}>
                {summary && summary.successRows > 0 ? "Done" : "Close"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}