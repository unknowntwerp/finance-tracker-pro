import React, { useState, useEffect } from 'react';
import { 
  categoryIcons, 
  getCategoryIconsByType, 
  CategoryType, 
  renderCategoryIcon, 
  CategoryIcon,
  getCategoryIconById
} from '@/lib/categoryIcons';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Search } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CategoryIconSelectorProps {
  selectedIcon: string;
  onSelectIcon: (iconId: string) => void;
  type?: 'expense' | 'income' | 'both';
}

export default function CategoryIconSelector({
  selectedIcon,
  onSelectIcon,
  type = 'expense'
}: CategoryIconSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredIcons, setFilteredIcons] = useState<CategoryIcon[]>([]);
  const [currentTab, setCurrentTab] = useState('all');
  
  // Set category type based on transaction type
  const categoryType = type === 'expense' 
    ? CategoryType.EXPENSE 
    : type === 'income' 
      ? CategoryType.INCOME 
      : CategoryType.BOTH;
  
  // Define icon categories for better organization
  const iconCategories = {
    'all': 'All Icons',
    'finance': 'Finance & Banking',
    'food': 'Food & Dining',
    'shopping': 'Shopping',
    'transport': 'Transportation',
    'home': 'Home & Utilities',
    'health': 'Health & Wellness',
    'personal': 'Personal & Lifestyle',
    'entertainment': 'Entertainment',
    'travel': 'Travel',
    'education': 'Education',
    'other': 'Other'
  };
  
  // Group icons by category
  const getIconsByCategory = (category: string): CategoryIcon[] => {
    const icons = getCategoryIconsByType(categoryType);
    
    if (category === 'all') {
      return icons;
    }
    
    // Map categories to related icon IDs
    const categoryMap: {[key: string]: string[]} = {
      'finance': ['financial', 'insurance', 'taxes', 'investments', 'bank', 'savings', 
                  'checking', 'deposit', 'withdrawal', 'money_transfer', 'wallet', 
                  'credit_card', 'visa_card', 'mastercard', 'amex', 'discover', 'diners', 
                  'jcb', 'apple_pay', 'google_pay', 'paypal', 'bank_card', 'bank_fee',
                  'atm_fee', 'credit_card_fee', 'loan_payment', 'financial_advice',
                  'brokerage_fee', 'forex', 'cryptocurrency', 'retirement', 'stock',
                  'bonds', 'mutual_funds'],
      'food': ['food', 'restaurant', 'coffee', 'groceries', 'bakery', 'bar', 
               'ice_cream', 'smoothie'],
      'shopping': ['shopping', 'clothing', 'electronics', 'gifts', 'jewelry', 'shoes',
                  'eyewear', 'accessories', 'cosmetics', 'luxury'],
      'transport': ['transport', 'fuel', 'taxi', 'parking', 'flight', 'train', 
                   'bike', 'scooter', 'car_rental', 'cruise', 'toll', 'car_service'],
      'home': ['housing', 'rent', 'furniture', 'maintenance', 'utilities', 'mortgage',
              'property_tax', 'home_improvement', 'home_insurance', 'lawn', 'cleaning',
              'moving', 'storage', 'bills', 'internet', 'phone', 'tv', 'electricity',
              'water', 'gas', 'trash', 'cable', 'subscriptions'],
      'health': ['health', 'medicine', 'doctor', 'fitness', 'dentist', 'therapy',
                'pharmacy', 'vision', 'gym', 'spa', 'medical_equipment'],
      'personal': ['personal', 'beauty', 'clothing_personal', 'haircut', 'laundry',
                  'manicure', 'massage', 'wellness', 'self_care'],
      'entertainment': ['entertainment', 'games', 'sports', 'books', 'music', 'concert',
                       'theater', 'museum', 'theme_park', 'movie', 'streaming', 'casino'],
      'travel': ['travel', 'hotel', 'adventure', 'vacation', 'backpacking', 'sightseeing',
                'travel_insurance', 'visa', 'luggage', 'resort'],
      'education': ['education', 'courses', 'books_education', 'tuition', 'school_supplies',
                   'student_loan', 'research', 'workshop', 'library'],
      'other': ['miscellaneous', 'pets', 'charity', 'childcare', 'pet_food', 'pet_grooming',
               'pet_vet', 'donation', 'legal', 'gifts_charity', 'toys', 'wedding', 'fines',
               'postage', 'printing', 'office']
    };
    
    // If income type, include these income-specific categories
    if (type === 'income' || type === 'both') {
      categoryMap['finance'].push(...['salary', 'freelance', 'bonus', 'gifts_income', 'refunds',
                                     'rental', 'dividends', 'interest', 'pension', 'child_support',
                                     'alimony', 'government', 'unemployment', 'social_security',
                                     'royalties', 'selling', 'commission', 'business', 'prizes',
                                     'investment_income', 'capital_gains', 'tax_refund', 'scholarship',
                                     'grant', 'lottery']);
    }
    
    return icons.filter(icon => 
      categoryMap[category]?.includes(icon.id.toLowerCase())
    );
  };
  
  // Filter icons based on search term and current tab
  useEffect(() => {
    let icons = getIconsByCategory(currentTab);
    
    if (searchTerm.trim() !== '') {
      icons = icons.filter(icon => 
        icon.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        icon.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredIcons(icons);
  }, [searchTerm, categoryType, currentTab]);
  
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
        <Input
          placeholder="Search icons..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-8"
        />
      </div>
      
      <Tabs defaultValue="all" value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid grid-cols-4 mb-2">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="finance">Finance</TabsTrigger>
          <TabsTrigger value="food">Food</TabsTrigger>
          <TabsTrigger value="shopping">Shopping</TabsTrigger>
        </TabsList>
        <TabsList className="grid grid-cols-4 mb-2">
          <TabsTrigger value="transport">Transport</TabsTrigger>
          <TabsTrigger value="home">Home</TabsTrigger>
          <TabsTrigger value="health">Health</TabsTrigger>
          <TabsTrigger value="entertainment">Entertainment</TabsTrigger>
        </TabsList>
      </Tabs>
      
      <ScrollArea className="h-64 rounded-md border">
        <div className="grid grid-cols-6 gap-2 p-2">
          {filteredIcons.map((icon) => (
            <div
              key={icon.id}
              className={cn(
                "flex flex-col items-center justify-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer transition-colors",
                selectedIcon === icon.id && "bg-blue-100 dark:bg-blue-900 ring-2 ring-blue-500"
              )}
              onClick={() => onSelectIcon(icon.id)}
              title={icon.name}
            >
              {renderCategoryIcon(icon.id, 28)}
              <span className="mt-1 text-xs text-center truncate w-full max-w-[60px]">
                {icon.name}
              </span>
            </div>
          ))}
          
          {filteredIcons.length === 0 && (
            <div className="col-span-6 py-8 text-center text-gray-500">
              No icons found matching "{searchTerm}"
            </div>
          )}
        </div>
      </ScrollArea>
      
      <style jsx>{`
        .grid-cols-6 {
          grid-template-columns: repeat(6, minmax(0, 1fr));
        }
        @media (max-width: 640px) {
          .grid-cols-6 {
            grid-template-columns: repeat(4, minmax(0, 1fr));
          }
        }
      `}</style>
    </div>
  );
}