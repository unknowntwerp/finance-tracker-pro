import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CategoryBreakdown as CategoryBreakdownType } from "@shared/schema";

interface CategoryBreakdownProps {
  categoryBreakdown: CategoryBreakdownType[];
  isLoading: boolean;
}

export default function CategoryBreakdown({ 
  categoryBreakdown,
  isLoading
}: CategoryBreakdownProps) {
  // Format currency for display
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  // Format percentage for display
  const formatPercentage = (percentage: number) => {
    return Math.round(percentage) + '%';
  };

  // Format category name for display
  const formatCategoryName = (category: string) => {
    return category
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  return (
    <Card>
      <CardHeader className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold">Category Breakdown</h2>
      </CardHeader>
      <CardContent className="p-4">
        {isLoading ? (
          // Skeleton loader for category breakdown
          <div className="space-y-4">
            {Array(5).fill(null).map((_, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-2 w-full rounded-full" />
              </div>
            ))}
          </div>
        ) : categoryBreakdown.length === 0 ? (
          <div className="text-center text-gray-500 py-4">
            No expense data available. Add expenses to see the breakdown.
          </div>
        ) : (
          <div className="space-y-4">
            {categoryBreakdown.map((category, index) => (
              <div key={index}>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full mr-2" 
                      style={{ backgroundColor: category.color }}
                    ></div>
                    <span className="text-sm">{formatCategoryName(category.category)}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{formatCurrency(category.amount)}</span>
                    <span className="text-xs text-gray-500 ml-2">({formatPercentage(category.percentage)})</span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                  <div 
                    className="h-2 rounded-full" 
                    style={{ 
                      backgroundColor: category.color,
                      width: `${category.percentage}%`
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
