import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useFinanceStore } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, ListIcon, X, Building, CreditCard as CreditCardIcon, Tag } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ManageLists() {
  const { 
    bankAccounts, addBankAccount, removeBankAccount,
    creditAccounts, addCreditAccount, removeCreditAccount,
    expenseCategories, addExpenseCategory, removeExpenseCategory,
    incomeCategories, addIncomeCategory, removeIncomeCategory
  } = useFinanceStore();

  const [activeTab, setActiveTab] = useState("bank-accounts");
  const [newBankAccount, setNewBankAccount] = useState("");
  const [newCreditAccount, setNewCreditAccount] = useState("");
  const [newExpenseCategory, setNewExpenseCategory] = useState("");
  const [newIncomeCategory, setNewIncomeCategory] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleAddBankAccount = () => {
    if (!newBankAccount.trim()) {
      setErrors(prev => ({ ...prev, bankAccount: "Bank account name is required" }));
      return;
    }

    if (bankAccounts.includes(newBankAccount)) {
      setErrors(prev => ({ ...prev, bankAccount: "Bank account already exists" }));
      return;
    }

    addBankAccount(newBankAccount);
    setNewBankAccount("");
    setErrors(prev => ({ ...prev, bankAccount: "" }));
  };

  const handleAddCreditAccount = () => {
    if (!newCreditAccount.trim()) {
      setErrors(prev => ({ ...prev, creditAccount: "Credit account name is required" }));
      return;
    }

    if (creditAccounts.includes(newCreditAccount)) {
      setErrors(prev => ({ ...prev, creditAccount: "Credit account already exists" }));
      return;
    }

    addCreditAccount(newCreditAccount);
    setNewCreditAccount("");
    setErrors(prev => ({ ...prev, creditAccount: "" }));
  };

  const handleAddExpenseCategory = () => {
    if (!newExpenseCategory.trim()) {
      setErrors(prev => ({ ...prev, expenseCategory: "Category name is required" }));
      return;
    }

    if (expenseCategories.includes(newExpenseCategory)) {
      setErrors(prev => ({ ...prev, expenseCategory: "Category already exists" }));
      return;
    }

    addExpenseCategory(newExpenseCategory);
    setNewExpenseCategory("");
    setErrors(prev => ({ ...prev, expenseCategory: "" }));
  };

  const handleAddIncomeCategory = () => {
    if (!newIncomeCategory.trim()) {
      setErrors(prev => ({ ...prev, incomeCategory: "Category name is required" }));
      return;
    }

    if (incomeCategories.includes(newIncomeCategory)) {
      setErrors(prev => ({ ...prev, incomeCategory: "Category already exists" }));
      return;
    }

    addIncomeCategory(newIncomeCategory);
    setNewIncomeCategory("");
    setErrors(prev => ({ ...prev, incomeCategory: "" }));
  };

  const getEmptyMessage = (type: string) => {
    switch (type) {
      case "bank-accounts":
        return "No bank accounts added yet.";
      case "credit-accounts":
        return "No credit accounts added yet.";
      case "expense-categories":
        return "No expense categories added yet.";
      case "income-categories":
        return "No income categories added yet.";
      default:
        return "No items added yet.";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <ListIcon className="h-6 w-6" /> Manage Lists
        </h1>
      </div>

      <Card>
        <CardContent className="py-6">
          <Tabs defaultValue="bank-accounts" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-6">
              <TabsTrigger value="bank-accounts" className="flex items-center gap-2">
                <Building className="h-4 w-4" /> 
                <span className="hidden md:inline">Bank Accounts</span>
                <span className="md:hidden">Banks</span>
              </TabsTrigger>
              <TabsTrigger value="credit-accounts" className="flex items-center gap-2">
                <CreditCardIcon className="h-4 w-4" /> 
                <span className="hidden md:inline">Credit Accounts</span>
                <span className="md:hidden">Credit</span>
              </TabsTrigger>
              <TabsTrigger value="expense-categories" className="flex items-center gap-2">
                <Tag className="h-4 w-4" /> 
                <span className="hidden md:inline">Expense Categories</span>
                <span className="md:hidden">Expenses</span>
              </TabsTrigger>
              <TabsTrigger value="income-categories" className="flex items-center gap-2">
                <Tag className="h-4 w-4" /> 
                <span className="hidden md:inline">Income Categories</span>
                <span className="md:hidden">Income</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="bank-accounts" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddBankAccount();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter bank account name (e.g., ICICI 1234)"
                    value={newBankAccount}
                    onChange={(e) => setNewBankAccount(e.target.value)}
                    className={cn(errors.bankAccount && "border-red-500")}
                  />
                  {errors.bankAccount && (
                    <p className="text-xs text-red-500 mt-1">{errors.bankAccount}</p>
                  )}
                </div>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Bank Accounts</h3>
                <div className="flex flex-wrap gap-2">
                  {bankAccounts.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("bank-accounts")}</p>
                  ) : (
                    bankAccounts.map((account, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3"
                      >
                        <Building className="h-3 w-3 mr-1" />
                        {account}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeBankAccount(account)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="credit-accounts" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddCreditAccount();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter credit account name (e.g., AMEX 5678)"
                    value={newCreditAccount}
                    onChange={(e) => setNewCreditAccount(e.target.value)}
                    className={cn(errors.creditAccount && "border-red-500")}
                  />
                  {errors.creditAccount && (
                    <p className="text-xs text-red-500 mt-1">{errors.creditAccount}</p>
                  )}
                </div>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Credit Accounts</h3>
                <div className="flex flex-wrap gap-2">
                  {creditAccounts.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("credit-accounts")}</p>
                  ) : (
                    creditAccounts.map((account, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3"
                      >
                        <CreditCardIcon className="h-3 w-3 mr-1" />
                        {account}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeCreditAccount(account)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="expense-categories" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddExpenseCategory();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter expense category (e.g., Food, Transport)"
                    value={newExpenseCategory}
                    onChange={(e) => setNewExpenseCategory(e.target.value)}
                    className={cn(errors.expenseCategory && "border-red-500")}
                  />
                  {errors.expenseCategory && (
                    <p className="text-xs text-red-500 mt-1">{errors.expenseCategory}</p>
                  )}
                </div>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Expense Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {expenseCategories.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("expense-categories")}</p>
                  ) : (
                    expenseCategories.map((category, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3 bg-red-50"
                      >
                        <Tag className="h-3 w-3 mr-1" />
                        {category}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeExpenseCategory(category)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="income-categories" className="space-y-4">
              <form 
                className="flex gap-3" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAddIncomeCategory();
                }}
              >
                <div className="flex-1">
                  <Input
                    placeholder="Enter income category (e.g., Salary, Bonus)"
                    value={newIncomeCategory}
                    onChange={(e) => setNewIncomeCategory(e.target.value)}
                    className={cn(errors.incomeCategory && "border-red-500")}
                  />
                  {errors.incomeCategory && (
                    <p className="text-xs text-red-500 mt-1">{errors.incomeCategory}</p>
                  )}
                </div>
                <Button type="submit" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" /> Add
                </Button>
              </form>

              <div className="mt-4">
                <h3 className="text-sm font-medium mb-3">Income Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {incomeCategories.length === 0 ? (
                    <p className="text-sm text-gray-500">{getEmptyMessage("income-categories")}</p>
                  ) : (
                    incomeCategories.map((category, index) => (
                      <Badge 
                        key={index} 
                        variant="outline"
                        className="flex items-center gap-1 py-1.5 pl-3 bg-green-50"
                      >
                        <Tag className="h-3 w-3 mr-1" />
                        {category}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeIncomeCategory(category)}
                          className="h-5 w-5 ml-1 p-0 rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}