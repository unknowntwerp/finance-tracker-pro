import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, useFinanceStore } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Plus, CreditCard as CreditCardIcon, Calendar, DollarSign, Trash2, AlertCircle } from "lucide-react";

// Generate a unique ID
const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};

export default function CreditCards() {
  const { creditCards, transactions, addCreditCard, removeCreditCard, bankAccounts, addTransaction } = useFinanceStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CreditCard | null>(null);
  const [paymentBankAccount, setPaymentBankAccount] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [name, setName] = useState("");
  const [statementDay, setStatementDay] = useState("");
  const [daysAfter, setDaysAfter] = useState("");
  const [creditLimit, setCreditLimit] = useState("");
  const [merchantRules, setMerchantRules] = useState("");
  const [selectedCardForExport, setSelectedCardForExport] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const calculateCycleTotal = (card: CreditCard) => {
    return transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      })
      .reduce((sum, tx) => sum + tx.amount, 0);
  };

  const exportCardTransactions = (card: CreditCard) => {
    const cycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      });

    const csv = [
      ['Date', 'Description', 'Amount', 'Category'].join(','),
      ...cycleTransactions.map(t => 
        [t.date, t.description, t.amount, t.category].join(',')
      )
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}-statement.csv`;
    a.click();
  };

  const resetForm = () => {
    setName("");
    setStatementDay("");
    setDaysAfter("");
    setCreditLimit("");
    setFormError(null);
  };

  const handlePayment = () => {
    if (!selectedCard || !paymentBankAccount || !paymentAmount) return;

    const amount = parseFloat(paymentAmount);
    const date = new Date().toISOString().split('T')[0];

    // Add contra transaction pair for credit card payment
    addTransaction({
      id: generateId(),
      date,
      type: "contra",
      description: `Payment to ${selectedCard.name}`,
      amount: -amount,
      account: paymentBankAccount,
      category: "Credit Card Payment"
    });

    addTransaction({
      id: generateId(),
      date, 
      type: "contra",
      description: `Payment received from ${paymentBankAccount}`,
      amount: -amount, // Negative to reduce credit card balance
      account: selectedCard.name,
      category: "Credit Card Payment"
    });

    // Reset payment form
    setIsPaymentDialogOpen(false);
    setSelectedCard(null);
    setPaymentBankAccount("");
    setPaymentAmount("");
  };

  const getPaymentStatus = (card: CreditCard) => {
    const now = new Date();
    const dueDate = new Date(card.dueDate);
    
    if (card.statementBalance <= 0) return "paid";
    if (now > dueDate) return "overdue";
    return "pending";
  };

  const handleAddCard = () => {
    // Form validation
    if (!name.trim()) {
      setFormError("Card name is required");
      return;
    }

    const statementDayNum = parseInt(statementDay);
    if (isNaN(statementDayNum) || statementDayNum < 1 || statementDayNum > 31) {
      setFormError("Statement day must be between 1 and 31");
      return;
    }

    const daysAfterNum = parseInt(daysAfter);
    if (isNaN(daysAfterNum) || daysAfterNum < 1 || daysAfterNum > 60) {
      setFormError("Days after must be between 1 and 60");
      return;
    }

    const creditLimitNum = parseFloat(creditLimit);
    if (isNaN(creditLimitNum) || creditLimitNum <= 0) {
      setFormError("Credit limit must be a positive number");
      return;
    }

    // Add the card
    addCreditCard({
      name,
      statementDay: statementDayNum,
      daysAfter: daysAfterNum,
      creditLimit: creditLimitNum
    });

    // Close dialog and reset form
    setIsDialogOpen(false);
    resetForm();
  };

  const handleOpenDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).replace(/\//g, '-');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <CreditCardIcon className="h-6 w-6" /> Credit Cards
        </h1>
        <Button onClick={handleOpenDialog} className="flex items-center gap-2">
          <Plus className="h-4 w-4" /> Add Credit Card
        </Button>
      </div>

      {creditCards.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <CreditCardIcon className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Credit Cards Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-6">
              Add your credit cards to track statement dates, payment due dates, and balances.
            </p>
            <Button onClick={handleOpenDialog} className="flex items-center gap-2">
              <Plus className="h-4 w-4" /> Add Credit Card
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {creditCards.map((card) => (
            <Card key={card.id} className="bg-gradient-to-br from-white to-gray-50 border-2">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl font-bold tracking-tight">{card.name}</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCreditCard(card.id)}
                    className="p-1 h-auto text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex justify-between mt-3">
                  <Badge variant="outline" className="px-3 py-1 text-sm font-medium bg-white border-2 flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    {formatCurrency(card.creditLimit)}
                  </Badge>
                  <Badge 
                    className={`px-3 py-1 text-sm font-medium ${
                      card.paymentStatus === "paid" ? "bg-green-100 text-green-800 border-green-200" :
                      card.paymentStatus === "pending" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                      "bg-red-100 text-red-800 border-red-200"
                    }`}
                  >
                    {card.paymentStatus.charAt(0).toUpperCase() + card.paymentStatus.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 py-3 bg-gray-50 rounded-lg px-3">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Statement Date</div>
                      <div className="font-medium">{formatDate(card.currentStatementDate)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Next Statement</div>
                      <div className="font-medium">{formatDate(card.nextStatementDate)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Payment Due</div>
                      <div className="font-medium">{formatDate(card.dueDate)}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-3 pt-2">
                    <div className="flex justify-between items-center py-2">
                      <span className="text-gray-600">Statement Balance</span>
                      <span className="font-semibold text-lg">{formatCurrency(card.statementBalance)}</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-gray-600">Current Cycle</span>
                      <span className="font-semibold text-lg text-blue-600">{formatCurrency(calculateCycleTotal(card))}</span>
                    </div>
                    <div className="flex justify-between items-center py-2">
                      <span className="text-gray-600">Total Outstanding</span>
                      <span className="font-semibold text-lg text-red-600">{formatCurrency(card.totalOutstanding)}</span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-t">
                      <span className="font-medium">Available Credit</span>
                      <span className="font-bold text-xl text-green-600">
                        {formatCurrency(card.creditLimit - (card.totalOutstanding + calculateCycleTotal(card)))}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 mt-4">
                    <Button
                      onClick={() => exportCardTransactions(card)}
                      variant="outline"
                      size="default"
                      className="flex-1 border-2 hover:bg-gray-50"
                    >
                      Export Transactions
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedCard(card);
                        setIsPaymentDialogOpen(true);
                      }}
                      variant="default"
                      size="default"
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      Make Payment
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Make Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedCard && (
              <>
                <div className="space-y-2">
                  <Label>Card</Label>
                  <p className="text-sm font-medium">{selectedCard.name}</p>
                </div>
                <div className="space-y-2">
                  <Label>Statement Balance</Label>
                  <p className="text-sm font-medium">{formatCurrency(selectedCard.statementBalance)}</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bankAccount">Pay From Account</Label>
                  <Select
                    value={paymentBankAccount}
                    onValueChange={setPaymentBankAccount}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccounts.map(account => (
                        <SelectItem key={account} value={account}>{account}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Payment Amount</Label>
                  <Input
                    id="paymentAmount"
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    placeholder="Enter amount"
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePayment} disabled={!selectedCard || !paymentBankAccount || !paymentAmount}>
              Submit Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Credit Card</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="name">Card Name</Label>
              <Input
                id="name"
                placeholder="e.g., AMEX Gold, Chase Sapphire"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="statementDay">
                  Statement Day
                  <span className="ml-1 text-xs text-gray-500">(1-31)</span>
                </Label>
                <Input
                  id="statementDay"
                  type="number"
                  min="1"
                  max="31"
                  placeholder="e.g., 15"
                  value={statementDay}
                  onChange={(e) => setStatementDay(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="daysAfter">
                  Days Until Due
                  <span className="ml-1 text-xs text-gray-500">(after statement)</span>
                </Label>
                <Input
                  id="daysAfter"
                  type="number"
                  min="1"
                  max="60"
                  placeholder="e.g., 21"
                  value={daysAfter}
                  onChange={(e) => setDaysAfter(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="creditLimit">Credit Limit</Label>
              <Input
                id="creditLimit"
                type="number"
                min="0"
                step="0.01"
                placeholder="e.g., 10000"
                value={creditLimit}
                onChange={(e) => setCreditLimit(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="merchantRules">
                Merchant Keywords
                <span className="ml-1 text-xs text-gray-500">(comma-separated)</span>
              </Label>
              <Input
                id="merchantRules"
                placeholder="e.g., amazon, netflix, spotify"
                value={merchantRules}
                onChange={(e) => setMerchantRules(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Transactions containing these keywords will be automatically tagged to this card
              </p>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddCard}>
              Add Card
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}