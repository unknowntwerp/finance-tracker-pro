import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, useFinanceStore } from "@/lib/transactionStore";
import { Badge } from "@/components/ui/badge";
import { Plus, CreditCard as CreditCardIcon, Calendar, DollarSign, Trash2, AlertCircle } from "lucide-react";

export default function CreditCards() {
  const { creditCards, transactions, addCreditCard, removeCreditCard } = useFinanceStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [name, setName] = useState("");
  const [statementDay, setStatementDay] = useState("");
  const [daysAfter, setDaysAfter] = useState("");
  const [creditLimit, setCreditLimit] = useState("");
  const [merchantRules, setMerchantRules] = useState("");
  const [selectedCardForExport, setSelectedCardForExport] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const calculateCycleTotal = (card: CreditCard) => {
    return transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      })
      .reduce((sum, tx) => sum + tx.amount, 0);
  };

  const exportCardTransactions = (card: CreditCard) => {
    const cycleTransactions = transactions
      .filter(t => t.account === card.name)
      .filter(t => {
        const txDate = new Date(t.date);
        const cycleStart = new Date(card.currentStatementDate);
        const cycleEnd = new Date(card.nextStatementDate);
        return txDate >= cycleStart && txDate < cycleEnd;
      });

    const csv = [
      ['Date', 'Description', 'Amount', 'Category'].join(','),
      ...cycleTransactions.map(t => 
        [t.date, t.description, t.amount, t.category].join(',')
      )
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}-statement.csv`;
    a.click();
  };

  const resetForm = () => {
    setName("");
    setStatementDay("");
    setDaysAfter("");
    setCreditLimit("");
    setFormError(null);
  };

  const handleAddCard = () => {
    // Form validation
    if (!name.trim()) {
      setFormError("Card name is required");
      return;
    }

    const statementDayNum = parseInt(statementDay);
    if (isNaN(statementDayNum) || statementDayNum < 1 || statementDayNum > 31) {
      setFormError("Statement day must be between 1 and 31");
      return;
    }

    const daysAfterNum = parseInt(daysAfter);
    if (isNaN(daysAfterNum) || daysAfterNum < 1 || daysAfterNum > 60) {
      setFormError("Days after must be between 1 and 60");
      return;
    }

    const creditLimitNum = parseFloat(creditLimit);
    if (isNaN(creditLimitNum) || creditLimitNum <= 0) {
      setFormError("Credit limit must be a positive number");
      return;
    }

    // Add the card
    addCreditCard({
      name,
      statementDay: statementDayNum,
      daysAfter: daysAfterNum,
      creditLimit: creditLimitNum
    });

    // Close dialog and reset form
    setIsDialogOpen(false);
    resetForm();
  };

  const handleOpenDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).replace(/\//g, '-');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <CreditCardIcon className="h-6 w-6" /> Credit Cards
        </h1>
        <Button onClick={handleOpenDialog} className="flex items-center gap-2">
          <Plus className="h-4 w-4" /> Add Credit Card
        </Button>
      </div>

      {creditCards.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <CreditCardIcon className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Credit Cards Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-6">
              Add your credit cards to track statement dates, payment due dates, and balances.
            </p>
            <Button onClick={handleOpenDialog} className="flex items-center gap-2">
              <Plus className="h-4 w-4" /> Add Credit Card
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {creditCards.map((card) => (
            <Card key={card.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg font-semibold">{card.name}</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCreditCard(card.id)}
                    className="p-1 h-auto text-red-600 hover:text-red-800 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex justify-between mt-2">
                  <Badge variant="outline" className="text-xs font-normal flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    Limit: {formatCurrency(card.creditLimit)}
                  </Badge>
                  <Badge 
                    className={`text-xs font-normal ${getPaymentStatusColor(card.paymentStatus)}`}
                  >
                    {card.paymentStatus.charAt(0).toUpperCase() + card.paymentStatus.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Statement Date:</span>
                    <span className="font-medium">{formatDate(card.currentStatementDate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Next Statement:</span>
                    <span className="font-medium">{formatDate(card.nextStatementDate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Payment Due:</span>
                    <span className="font-medium">{formatDate(card.dueDate)}</span>
                  </div>
                  <div className="border-t pt-3 mt-3">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Statement Balance:</span>
                      <span className="font-medium">{formatCurrency(card.statementBalance)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Current Cycle Spent:</span>
                      <span className="font-medium text-blue-600">{formatCurrency(calculateCycleTotal(card))}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Total Outstanding:</span>
                      <span className="font-medium text-red-600">{formatCurrency(card.totalOutstanding)}</span>
                    </div>
                    <div className="flex justify-between font-semibold">
                      <span>Available Credit:</span>
                      <span className="text-green-600">{formatCurrency(card.creditLimit - card.totalOutstanding)}</span>
                    </div>
                    <Button
                      onClick={() => exportCardTransactions(card)}
                      variant="outline"
                      size="sm"
                      className="w-full mt-2"
                    >
                      Export Cycle Transactions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Credit Card</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="name">Card Name</Label>
              <Input
                id="name"
                placeholder="e.g., AMEX Gold, Chase Sapphire"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="statementDay">
                  Statement Day
                  <span className="ml-1 text-xs text-gray-500">(1-31)</span>
                </Label>
                <Input
                  id="statementDay"
                  type="number"
                  min="1"
                  max="31"
                  placeholder="e.g., 15"
                  value={statementDay}
                  onChange={(e) => setStatementDay(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="daysAfter">
                  Days Until Due
                  <span className="ml-1 text-xs text-gray-500">(after statement)</span>
                </Label>
                <Input
                  id="daysAfter"
                  type="number"
                  min="1"
                  max="60"
                  placeholder="e.g., 21"
                  value={daysAfter}
                  onChange={(e) => setDaysAfter(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="creditLimit">Credit Limit</Label>
              <Input
                id="creditLimit"
                type="number"
                min="0"
                step="0.01"
                placeholder="e.g., 10000"
                value={creditLimit}
                onChange={(e) => setCreditLimit(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="merchantRules">
                Merchant Keywords
                <span className="ml-1 text-xs text-gray-500">(comma-separated)</span>
              </Label>
              <Input
                id="merchantRules"
                placeholder="e.g., amazon, netflix, spotify"
                value={merchantRules}
                onChange={(e) => setMerchantRules(e.target.value)}
              />
              <p className="text-xs text-gray-500">
                Transactions containing these keywords will be automatically tagged to this card
              </p>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddCard}>
              Add Card
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}