import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useFinanceStore, Transaction } from "@/lib/transactionStore";
import { ChartBarIcon, PieChartIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";


export default function Analytics() {
  const { transactions } = useFinanceStore();
  const [periodFilter, setPeriodFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  // Define colors for charts
  const COLORS = [
    "#4f46e5", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", 
    "#8b5cf6", "#06b6d4", "#84cc16", "#f97316", "#ec4899"
  ];

  // Filter transactions based on user selections
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      // Type filter
      if (typeFilter !== "all" && transaction.type !== typeFilter) {
        return false;
      }

      // Period filter
      if (periodFilter !== "all") {
        const txDate = new Date(transaction.date);
        const now = new Date();

        switch (periodFilter) {
          case "thisMonth":
            return txDate.getMonth() === now.getMonth() && 
                   txDate.getFullYear() === now.getFullYear();
          case "lastMonth":
            const lastMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
            const lastMonthYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
            return txDate.getMonth() === lastMonth && 
                   txDate.getFullYear() === lastMonthYear;
          case "thisYear":
            return txDate.getFullYear() === now.getFullYear();
          case "lastYear":
            return txDate.getFullYear() === now.getFullYear() - 1;
          default:
            return true;
        }
      }
      return true;
    });
  }, [transactions, periodFilter, typeFilter]);

  // Calculate category data for pie chart
  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};

    filteredTransactions.forEach(transaction => {
      const { category, amount } = transaction;
      if (!categories[category]) {
        categories[category] = 0;
      }
      categories[category] += amount;
    });

    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value); // Sort by amount desc
  }, [filteredTransactions]);

  // Calculate monthly data for bar chart
  const monthlyData = useMemo(() => {
    const months: Record<string, { income: number; expense: number }> = {};

    // Initialize all months
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    // Create data for last 6 months
    for (let i = 0; i < 6; i++) {
      let monthIndex = currentMonth - i;
      let year = currentYear;

      if (monthIndex < 0) {
        monthIndex += 12;
        year -= 1;
      }

      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const monthKey = `${monthNames[monthIndex]} ${year}`;

      months[monthKey] = { income: 0, expense: 0 };
    }

    // Aggregate transaction data
    filteredTransactions.forEach(transaction => {
      const { date, type, amount } = transaction;
      const txDate = new Date(date);
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const monthKey = `${monthNames[txDate.getMonth()]} ${txDate.getFullYear()}`;

      if (months[monthKey]) {
        if (type === "income") {
          months[monthKey].income += amount;
        } else {
          months[monthKey].expense += amount;
        }
      }
    });

    // Convert to array and reverse to show oldest month first
    return Object.entries(months)
      .map(([name, data]) => ({ name, ...data }))
      .reverse();
  }, [filteredTransactions]);

  // Calculate summary data
  const summaryData = useMemo(() => {
    let income = 0;
    let expense = 0;

    filteredTransactions.forEach(transaction => {
      if (transaction.type === "income") {
        income += transaction.amount;
      } else {
        expense += transaction.amount;
      }
    });

    return {
      income,
      expense,
      balance: income - expense
    };
  }, [filteredTransactions]);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border shadow-sm rounded-md">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const handleBarClick = (data: any) => {
    toast({ title: "Month Details", description: `${data.name}: Income - ${formatCurrency(data.income)}, Expenses - ${formatCurrency(data.expense)}` });
  };

  const handlePieClick = (data: any) => {
    toast({ title: "Category Details", description: `${data.name}: ${formatCurrency(data.value)}` });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <ChartBarIcon className="h-6 w-6" /> Financial Analytics
        </h1>
        <div className="flex flex-col md:flex-row gap-3">
          <div className="flex items-center gap-2">
            <Label htmlFor="periodFilter" className="text-sm">Period:</Label>
            <Select value={periodFilter} onValueChange={setPeriodFilter}>
              <SelectTrigger id="periodFilter" className="w-36">
                <SelectValue placeholder="Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="thisMonth">This Month</SelectItem>
                <SelectItem value="lastMonth">Last Month</SelectItem>
                <SelectItem value="thisYear">This Year</SelectItem>
                <SelectItem value="lastYear">Last Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Label htmlFor="typeFilter" className="text-sm">Type:</Label>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger id="typeFilter" className="w-36">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="income">Income Only</SelectItem>
                <SelectItem value="expense">Expenses Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-col items-center text-center">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Income</h3>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(summaryData.income)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-col items-center text-center">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Expenses</h3>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(summaryData.expense)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-col items-center text-center">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Balance</h3>
              <p className={`text-2xl font-bold ${summaryData.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatCurrency(summaryData.balance)}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      {transactions.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <ChartBarIcon className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Transaction Data</h3>
            <p className="text-gray-500 text-center max-w-md">
              Add transactions to see charts and analytics about your spending.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Monthly Income/Expense */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <ChartBarIcon className="h-5 w-5 text-primary" /> Monthly Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }} onClick={(e)=>{handleBarClick(e.activePayload[0].payload)}}>
                      <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar name="Income" dataKey="income" fill="#10b981" barSize={30} />
                      <Bar name="Expenses" dataKey="expense" fill="#ef4444" barSize={30} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Category Breakdown */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <PieChartIcon className="h-5 w-5 text-primary" /> Spending by Category
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart margin={{ top: 10, right: 10, left: 10, bottom: 10 }} onClick={(e)=>{handlePieClick(e.activePayload[0].payload)}}>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        labelLine={false}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                      <Legend layout="horizontal" verticalAlign="bottom" align="center" />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}