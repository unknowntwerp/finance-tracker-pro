import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useFinanceStore } from "@/lib/transactionStore";
import { 
  Download, Upload, AlertTriangle, Database, UploadCloud, DownloadCloud, Shield, FileJson, Info 
} from "lucide-react";

export default function Backup() {
  const { toast } = useToast();
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get all store data
  const storeData = useFinanceStore();

  const handleExport = () => {
    try {
      setIsExporting(true);
      
      // Prepare data for export
      const exportData = {
        transactions: storeData.transactions,
        creditCards: storeData.creditCards,
        bankAccounts: storeData.bankAccounts,
        creditAccounts: storeData.creditAccounts,
        expenseCategories: storeData.expenseCategories,
        incomeCategories: storeData.incomeCategories,
        exportDate: new Date().toISOString(),
        version: "1.0"
      };
      
      // Convert to JSON and create Blob
      const dataStr = JSON.stringify(exportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      
      // Create download link and trigger download
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(dataBlob);
      downloadLink.download = `finance_tracker_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      
      toast({
        title: "Backup Exported",
        description: "Your data has been successfully exported to a JSON file.",
        duration: 3000,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "There was an error exporting your data. Please try again.",
        duration: 5000,
      });
      console.error('Export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setImportFile(file);
    setError(null);
  };

  const handleImport = () => {
    if (!importFile) {
      setError("No file selected");
      return;
    }

    if (!importFile.type.includes('json')) {
      setError("File must be a JSON file");
      return;
    }

    // Open confirmation dialog
    setIsConfirmDialogOpen(true);
  };

  const confirmImport = () => {
    if (!importFile) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const result = e.target?.result as string;
        const importData = JSON.parse(result);

        // Validate imported data
        if (!importData.transactions || !Array.isArray(importData.transactions)) {
          throw new Error("Invalid backup file format: missing transactions array");
        }

        // In a real implementation, we would handle the import through the store
        // For now, we'll just simulate success
        setIsConfirmDialogOpen(false);
        setIsImportDialogOpen(false);
        setImportFile(null);

        toast({
          title: "Backup Imported",
          description: "Your data has been successfully imported.",
          duration: 3000,
        });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setError(`Failed to parse import file: ${message}`);
        setIsConfirmDialogOpen(false);
      }
    };

    reader.onerror = () => {
      setError("Error reading file");
      setIsConfirmDialogOpen(false);
    };

    reader.readAsText(importFile);
  };

  const checkBackupStats = () => {
    const stats = {
      transactions: storeData.transactions.length,
      creditCards: storeData.creditCards.length,
      accounts: storeData.bankAccounts.length + storeData.creditAccounts.length,
      categories: storeData.expenseCategories.length + storeData.incomeCategories.length
    };
    
    return stats;
  };

  const stats = checkBackupStats();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Database className="h-6 w-6" /> Backup & Restore
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <DownloadCloud className="h-5 w-5 text-primary" /> Export Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <p className="text-gray-500">
                Export all your financial data to a backup file that you can store safely or import later.
              </p>
              
              <div className="bg-gray-50 rounded-md p-4 flex gap-4 mb-2">
                <div className="flex-shrink-0">
                  <Info className="h-5 w-5 text-gray-500" />
                </div>
                <div className="text-sm text-gray-600">
                  <p className="font-medium mb-1">Your backup will include:</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>{stats.transactions} transactions</li>
                    <li>{stats.creditCards} credit cards</li>
                    <li>{stats.accounts} accounts</li>
                    <li>{stats.categories} categories</li>
                  </ul>
                </div>
              </div>
              
              <Button 
                variant="default" 
                className="w-full md:w-auto flex items-center gap-2 self-end"
                disabled={isExporting}
                onClick={handleExport}
              >
                {isExporting ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    Export Backup
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <UploadCloud className="h-5 w-5 text-primary" /> Import Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <p className="text-gray-500">
                Restore your data from a previously exported backup file.
              </p>
              
              <Alert className="bg-amber-50 border-amber-200 mb-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertTitle className="text-amber-800">Warning</AlertTitle>
                <AlertDescription className="text-amber-700">
                  Importing will replace all your current data with the data from the backup file.
                  Make sure to export your current data first if you want to keep it.
                </AlertDescription>
              </Alert>
              
              <Button 
                variant="outline" 
                className="w-full md:w-auto flex items-center gap-2 self-end"
                onClick={() => setIsImportDialogOpen(true)}
              >
                <Upload className="h-4 w-4" />
                Import Backup
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" /> Data Security
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-gray-500">
                Your data is stored securely in your browser's local storage. Here are some tips to keep your data safe:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-md p-4 flex gap-4">
                  <div className="flex-shrink-0">
                    <Download className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Regular Backups</h3>
                    <p className="text-sm text-gray-500">
                      Make regular backups of your data and keep them in a safe place.
                    </p>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 flex gap-4">
                  <div className="flex-shrink-0">
                    <FileJson className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Multiple Copies</h3>
                    <p className="text-sm text-gray-500">
                      Store copies of your backup file in different locations for added safety.
                    </p>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 flex gap-4">
                  <div className="flex-shrink-0">
                    <AlertTriangle className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Browser Clearing</h3>
                    <p className="text-sm text-gray-500">
                      Clearing browser data will erase your stored information. Export before clearing.
                    </p>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 flex gap-4">
                  <div className="flex-shrink-0">
                    <Database className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Device Changes</h3>
                    <p className="text-sm text-gray-500">
                      When changing devices, export your data first and import it on the new device.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Import Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Import Backup</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-gray-500">
              Select a backup file to import. The file should be a JSON file previously exported from this application.
            </p>
            
            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
              <input 
                type="file" 
                id="import-file" 
                accept=".json" 
                className="hidden"
                onChange={handleFileChange}
              />
              <label 
                htmlFor="import-file" 
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                <Upload className="h-8 w-8 text-gray-400 mb-2" />
                <span className="text-sm font-medium text-gray-700">
                  {importFile ? importFile.name : 'Click to select backup file'}
                </span>
                <span className="text-xs text-gray-500 mt-1">
                  {importFile ? `${(importFile.size / 1024).toFixed(1)} KB` : '.json files only'}
                </span>
              </label>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              disabled={!importFile}
              onClick={handleImport}
            >
              Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Import</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Alert className="bg-amber-50 border-amber-200">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800">Warning</AlertTitle>
              <AlertDescription className="text-amber-700">
                This will replace all your current data with the data from the backup file.
                This action cannot be undone.
              </AlertDescription>
            </Alert>
            <p className="text-sm text-gray-500">
              Are you sure you want to proceed with the import?
            </p>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive"
              onClick={confirmImport}
            >
              Yes, Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}