import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileUp, Plus, Clipboard, Trash2, AlertCircle } from "lucide-react";
import { useFinanceStore, Transaction, ImportTransaction } from "@/lib/transactionStore";
import { formatDate } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { 
    transactions, 
    removeTransaction, 
    addTransaction,
    bankAccounts,
    creditAccounts,
    expenseCategories,
    incomeCategories 
  } = useFinanceStore();
  const { toast } = useToast();
  
  // Transaction modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<string>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  
  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('expense');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setFormError(null);
  };
  
  // Handle opening the add transaction modal
  const handleOpenAddModal = () => {
    resetForm();
    
    // Set default values
    if (bankAccounts.length > 0) {
      setTransactionAccount(bankAccounts[0]);
    }
    if (expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    }
    
    setIsAddModalOpen(true);
  };
  
  // Handle creating a new transaction
  const handleAddTransaction = () => {
    // Validate form fields
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }
    
    if (!transactionDescription.trim()) {
      setFormError("Description is required");
      return;
    }
    
    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }
    
    if (!transactionAccount) {
      setFormError("Account is required");
      return;
    }
    
    if (!transactionCategory) {
      setFormError("Category is required");
      return;
    }
    
    // Validate that expense categories are used for expense transactions
    // and income categories are used for income transactions
    if (transactionType === 'expense' && !expenseCategories.includes(transactionCategory)) {
      setFormError("Please select an expense category for expense transactions");
      return;
    }
    
    if (transactionType === 'income' && !incomeCategories.includes(transactionCategory)) {
      setFormError("Please select an income category for income transactions");
      return;
    }
    
    // Create and add the transaction
    const newTransaction: ImportTransaction = {
      date: transactionDate,
      type: transactionType,
      description: transactionDescription,
      amount: parseFloat(transactionAmount),
      account: transactionAccount,
      category: transactionCategory
    };
    
    addTransaction(newTransaction);
    
    // Show success toast
    toast({
      title: "Transaction Added",
      description: "Your transaction has been successfully added.",
      duration: 3000,
    });
    
    // Close the modal and reset form
    setIsAddModalOpen(false);
    resetForm();
  };
  
  // Update available category options based on transaction type
  const handleTypeChange = (type: string) => {
    setTransactionType(type);
    
    // Reset category when type changes
    setTransactionCategory('');
    
    // Set default category based on type
    if (type === 'expense' && expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    } else if (type === 'income' && incomeCategories.length > 0) {
      setTransactionCategory(incomeCategories[0]);
    }
  };
  
  // Format amount for display
  const formatAmount = (amount: number, type: string) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
    }).format(amount);
  };
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Clipboard className="h-6 w-6" /> Finance Tracker Pro
        </h1>
        <div className="flex gap-2">
          <Link href="/bulk-import">
            <Button variant="default" className="flex items-center gap-2">
              <FileUp className="h-4 w-4" /> Bulk Import
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" /> Quick Add Transaction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 items-center md:justify-between">
              <div>
                <p className="text-gray-500 mb-2">
                  Add individual transactions to track your expenses and income.
                </p>
              </div>
              <div>
                <Button 
                  variant="default" 
                  className="flex items-center gap-2"
                  onClick={handleOpenAddModal}
                >
                  <Plus className="h-4 w-4" />
                  Add Transaction
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Date</th>
                  <th className="text-left p-3">Type</th>
                  <th className="text-left p-3">Category</th>
                  <th className="text-left p-3">Description</th>
                  <th className="text-left p-3">Account</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.length === 0 ? (
                  <tr className="border-b">
                    <td className="p-3 text-sm" colSpan={7}>
                      No transactions found. Add a transaction or import from Excel.
                    </td>
                  </tr>
                ) : (
                  transactions.map((transaction: Transaction) => (
                    <tr key={transaction.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">{formatDate(transaction.date)}</td>
                      <td className="p-3 capitalize">{transaction.type}</td>
                      <td className="p-3">{transaction.category}</td>
                      <td className="p-3 font-medium">{transaction.description}</td>
                      <td className="p-3">{transaction.account}</td>
                      <td className={`p-3 ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                        {formatAmount(transaction.amount, transaction.type)}
                      </td>
                      <td className="p-3">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeTransaction(transaction.id)}
                          className="p-1 h-auto text-red-600 hover:text-red-800 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Transaction Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Transaction</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="type">Transaction Type</Label>
              <Select 
                value={transactionType}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select transaction type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter transaction description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                min="0.01"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select 
                value={transactionAccount}
                onValueChange={setTransactionAccount}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select an account</div>
                  {bankAccounts.length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Bank Accounts</div>
                      {bankAccounts.map((account) => (
                        <SelectItem key={account} value={account}>{account}</SelectItem>
                      ))}
                    </>
                  )}
                  {creditAccounts.length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Credit Accounts</div>
                      {creditAccounts.map((account) => (
                        <SelectItem key={account} value={account}>{account}</SelectItem>
                      ))}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select 
                value={transactionCategory}
                onValueChange={setTransactionCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select a category</div>
                  {transactionType === 'expense' ? (
                    expenseCategories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))
                  ) : (
                    incomeCategories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddTransaction}>
              Add Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
