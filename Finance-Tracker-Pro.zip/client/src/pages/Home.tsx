import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileUp, Plus, Clipboard, Trash2, AlertCircle } from "lucide-react";
import { useFinanceStore, Transaction, ImportTransaction } from "@/lib/transactionStore";
import { formatDate } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { 
    transactions, 
    removeTransaction, 
    addTransaction,
    bankAccounts,
    creditCards, // Added creditCards
    expenseCategories,
    incomeCategories 
  } = useFinanceStore();
  const { toast } = useToast();

  // Transaction modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [transactionType, setTransactionType] = useState<string>('expense');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionAccount, setTransactionAccount] = useState('');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [editingIndex, setEditingIndex] = useState<number>(-1); // Added editingIndex state

  //Sort and filter states
  const [sortField, setSortField] = useState<'date' | 'amount' | 'category'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filterText, setFilterText] = useState('');


  // Reset form fields
  const resetForm = () => {
    setTransactionDate(new Date().toISOString().split('T')[0]);
    setTransactionType('expense');
    setTransactionDescription('');
    setTransactionAmount('');
    setTransactionAccount('');
    setTransactionCategory('');
    setFormError(null);
  };

  // Handle opening the add transaction modal
  const handleOpenAddModal = () => {
    resetForm();

    // Set default values
    if (bankAccounts.length > 0) {
      setTransactionAccount(bankAccounts[0]);
    }
    if (expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    }

    setIsAddModalOpen(true);
  };

  // Handle creating a new transaction
  const handleAddTransaction = () => {
    // Validate form fields
    if (!transactionDate) {
      setFormError("Date is required");
      return;
    }

    if (!transactionDescription.trim()) {
      setFormError("Description is required");
      return;
    }

    if (!transactionAmount || isNaN(parseFloat(transactionAmount)) || parseFloat(transactionAmount) <= 0) {
      setFormError("Amount must be a positive number");
      return;
    }

    if (!transactionAccount) {
      setFormError("Account is required");
      return;
    }

    if (!transactionCategory) {
      setFormError("Category is required");
      return;
    }

    // Validate that expense categories are used for expense transactions
    // and income categories are used for income transactions
    if (transactionType === 'expense' && !expenseCategories.includes(transactionCategory)) {
      setFormError("Please select an expense category for expense transactions");
      return;
    }

    if (transactionType === 'income' && !incomeCategories.includes(transactionCategory)) {
      setFormError("Please select an income category for income transactions");
      return;
    }

    // Create and add the transaction
    const newTransaction: ImportTransaction = {
      date: transactionDate,
      type: transactionType,
      description: transactionDescription,
      amount: parseFloat(transactionAmount),
      account: transactionAccount,
      category: transactionCategory
    };

    if (editingIndex === -1) {
      addTransaction(newTransaction);
    } else {
      transactions[editingIndex] = newTransaction;
    }

    // Show success toast
    toast({
      title: "Transaction Added",
      description: "Your transaction has been successfully added.",
      duration: 3000,
    });

    // Close the modal and reset form
    setIsAddModalOpen(false);
    resetForm();
    setEditingIndex(-1); // Reset editing index
  };

  // Update available category options based on transaction type
  const handleTypeChange = (type: string) => {
    setTransactionType(type);
    setTransactionCategory('');

    if (type === 'expense' && expenseCategories.length > 0) {
      setTransactionCategory(expenseCategories[0]);
    } else if (type === 'income' && incomeCategories.length > 0) {
      setTransactionCategory(incomeCategories[0]);
    }
  };

  const handleAccountChange = (account: string) => {
    setTransactionAccount(account);
    // Auto-label as credit card expense if account is a credit card
    if (creditCards.map(card => card.name).includes(account)) { //Updated to use creditCards
      setTransactionType('expense');
      setTransactionCategory('Credit Card Expense');
    }
  };

  // Format amount for display
  const formatAmount = (amount: number, type: string) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const filteredTransactions = transactions
    .filter((transaction) => 
      transaction.description.toLowerCase().includes(filterText.toLowerCase())
    )
    .sort((a, b) => {
      if (sortField === 'date') {
        return sortOrder === 'asc' 
          ? new Date(a.date).getTime() - new Date(b.date).getTime()
          : new Date(b.date).getTime() - new Date(a.date).getTime()
      }
      if (sortField === 'amount') {
        return sortOrder === 'asc' ? a.amount - b.amount : b.amount - a.amount
      }
      return sortOrder === 'asc' 
        ? a.category.localeCompare(b.category)
        : b.category.localeCompare(a.category)
    });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Clipboard className="h-6 w-6" /> Finance Tracker Pro
        </h1>
        <div className="flex gap-2">
          <Link href="/bulk-import">
            <Button variant="default" className="flex items-center gap-2">
              <FileUp className="h-4 w-4" /> Bulk Import
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" /> Quick Add Transaction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 items-center md:justify-between">
              <div>
                <p className="text-gray-500 mb-2">
                  Add individual transactions to track your expenses and income.
                </p>
              </div>
              <div>
                <Button 
                  variant="default" 
                  className="flex items-center gap-2"
                  onClick={handleOpenAddModal}
                >
                  <Plus className="h-4 w-4" />
                  Add Transaction
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <Input type="text" placeholder="Filter transactions..." value={filterText} onChange={(e) => setFilterText(e.target.value)} />
            <div className="flex gap-2">
              <Select value={sortField} onValueChange={setSortField}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="amount">Amount</SelectItem>
                  <SelectItem value="category">Category</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortOrder} onValueChange={setSortOrder}>
                <SelectTrigger>
                  <SelectValue placeholder="Order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">Ascending</SelectItem>
                  <SelectItem value="desc">Descending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Date</th>
                  <th className="text-left p-3">Type</th>
                  <th className="text-left p-3">Category</th>
                  <th className="text-left p-3">Description</th>
                  <th className="text-left p-3">Account</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.length === 0 ? (
                  <tr className="border-b">
                    <td className="p-3 text-sm" colSpan={7}>
                      No transactions found. Add a transaction or import from Excel.
                    </td>
                  </tr>
                ) : (
                  filteredTransactions.map((transaction: Transaction) => (
                    <tr key={transaction.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">{new Date(transaction.date).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                      }).replace(/\//g, '-')}</td>
                      <td className="p-3 capitalize">{transaction.type}</td>
                      <td className="p-3">{transaction.category}</td>
                      <td className="p-3 font-medium">{transaction.description}</td>
                      <td className="p-3">{transaction.account}</td>
                      <td className={`p-3 ${
                        transaction.type === 'transfer' 
                          ? transaction.amount > 0
                            ? 'text-green-600'  // Receiving account shows green
                            : 'text-red-600'    // Paying account shows red
                          : transaction.type === 'income' 
                            ? 'text-green-600' 
                            : 'text-red-600'
                      }`}>
                        {transaction.type === 'transfer' 
                          ? formatAmount(Math.abs(transaction.amount), transaction.type)
                          : formatAmount(transaction.amount, transaction.type)}
                      </td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setTransactionDate(transaction.date);
                              setTransactionType(transaction.type);
                              setTransactionDescription(transaction.description);
                              setTransactionAmount(transaction.amount.toString());
                              setTransactionAccount(transaction.account);
                              setTransactionCategory(transaction.category);
                              setEditingIndex(transactions.indexOf(transaction)); // Correctly sets editingIndex
                              setIsAddModalOpen(true);
                            }}
                            className="p-1 h-auto text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeTransaction(transaction.id)}
                            className="p-1 h-auto text-red-600 hover:text-red-800 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Transaction Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Transaction</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Transaction Type</Label>
              <Select 
                value={transactionType}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select transaction type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter transaction description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                min="0.01"
                step="0.01"
                placeholder="Enter amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Select 
                value={transactionAccount}
                onValueChange={handleAccountChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select an account</div>
                  {bankAccounts.length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Bank Accounts</div>
                      {bankAccounts.map((account) => (
                        <SelectItem key={account} value={account}>{account}</SelectItem>
                      ))}
                    </>
                  )}
                  {creditCards.map(card => card.name).length > 0 && (
                    <>
                      <div className="font-semibold text-xs px-2 py-1.5 text-gray-700">Credit Cards</div>
                      {creditCards.map(card => (
                        <SelectItem key={card.name} value={card.name}>{card.name}</SelectItem>
                      ))}
                    </>
                  )}
                  {bankAccounts.length === 0 && creditCards.length === 0 && (
                    <div className="text-xs text-gray-500 px-2 py-1.5">
                      No accounts added yet. Add them from Bank Accounts or Credit Cards page.
                    </div>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select 
                value={transactionCategory}
                onValueChange={setTransactionCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <div className="text-xs font-medium text-gray-500 px-2 py-1.5">Select a category</div>
                  {transactionType === 'expense' ? (
                    expenseCategories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))
                  ) : (
                    incomeCategories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddTransaction}>
              Add Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}