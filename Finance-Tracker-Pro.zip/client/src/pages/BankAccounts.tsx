import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useFinanceStore } from "@/lib/transactionStore";
import { Building, Plus, ArrowDown, ArrowUp, FileText, AlertCircle, Trash2 } from "lucide-react";
import { formatCurrency } from "@/lib/formatters";

export default function BankAccounts() {
  const { bankAccounts, transactions, addBankAccount, removeBankAccount, addTransaction } = useFinanceStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false); // Added state for transfer dialog
  const [newBankAccount, setNewBankAccount] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [transferSource, setTransferSource] = useState(""); // Added state for transfer source
  const [transferDestination, setTransferDestination] = useState(""); // Added state for transfer destination
  const [transferAmount, setTransferAmount] = useState(""); // Added state for transfer amount


  // Calculate balances and transactions for each bank account
  const bankBalances = bankAccounts.reduce((acc, account) => {
    const accountTransactions = transactions.filter(t => t.account === account);
    const balance = accountTransactions.reduce((sum, t) => {
      if (t.type === "income" || t.type === "payment") return sum + t.amount;
      if (t.type === "expense" || t.type === "transfer") return sum - t.amount;
      return sum;
    }, 0);

    const monthlyIncome = accountTransactions
      .filter(t => t.type === "income" && new Date(t.date).getMonth() === new Date().getMonth())
      .reduce((sum, t) => sum + t.amount, 0);

    const monthlyExpense = accountTransactions
      .filter(t => t.type === "expense" && new Date(t.date).getMonth() === new Date().getMonth())
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      ...acc,
      [account]: {
        balance,
        transactions: accountTransactions.length,
        monthlyIncome,
        monthlyExpense
      }
    };
  }, {});

  const totalBalance = Object.values(bankBalances).reduce((sum, account: any) => sum + account.balance, 0);

  const handleAddAccount = () => {
    if (!newBankAccount.trim()) {
      setFormError("Bank account name is required");
      return;
    }

    if (bankAccounts.includes(newBankAccount)) {
      setFormError("Bank account already exists");
      return;
    }

    addBankAccount(newBankAccount);
    setNewBankAccount("");
    setFormError(null);
    setIsDialogOpen(false);
  };

  const handleTransfer = () => {
    if (!transferSource || !transferDestination || !transferAmount) {
      return;
    }

    const amount = parseFloat(transferAmount);
    if (isNaN(amount) || amount <= 0) {
      return;
    }

    // Add withdrawal transaction from source account
    addTransaction({
      date: new Date().toISOString().split('T')[0],
      type: "transfer",
      description: `Transfer to ${transferDestination}`,
      amount: -amount,
      account: transferSource,
      category: "Transfer"
    });

    // Add deposit transaction to destination account
    addTransaction({
      date: new Date().toISOString().split('T')[0],
      type: "transfer",
      description: `Transfer from ${transferSource}`,
      amount: amount,
      account: transferDestination,
      category: "Transfer"
    });

    setTransferAmount("");
    setTransferSource("");
    setTransferDestination("");
    setIsTransferDialogOpen(false);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Building className="h-6 w-6" /> Bank Accounts
        </h1>
        <div className="flex gap-2">
          <Button onClick={() => setIsTransferDialogOpen(true)} variant="outline" className="flex items-center gap-2">
            <ArrowDown className="h-4 w-4" /> Transfer Funds
          </Button>
          <Button onClick={() => setIsDialogOpen(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" /> Add Bank Account
          </Button>
        </div>
      </div>

      {/* Total Balance Card */}
      <Card className="mb-6">
        <CardContent className="py-6">
          <div className="flex flex-col items-center">
            <h2 className="text-lg font-medium text-gray-500 mb-2">Total Balance</h2>
            <p className={`text-3xl font-bold ${totalBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalBalance)}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Across {bankAccounts.length} bank {bankAccounts.length === 1 ? 'account' : 'accounts'}
            </p>
          </div>
        </CardContent>
      </Card>

      {bankAccounts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <Building className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Bank Accounts Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-6">
              Add your bank accounts to track their balances and transactions.
            </p>
            <div className="flex gap-2">
              <Button onClick={() => setIsTransferDialogOpen(true)} variant="outline" className="flex items-center gap-2">
                <ArrowDown className="h-4 w-4" /> Transfer Funds
              </Button>
              <Button onClick={() => setIsDialogOpen(true)} className="flex items-center gap-2">
                <Plus className="h-4 w-4" /> Add Bank Account
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bankAccounts.map((account) => {
            const accountData = bankBalances[account];
            return (
              <Card key={account}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-semibold">{account}</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBankAccount(account)}
                      className="p-1 h-auto text-red-600 hover:text-red-800 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex flex-col items-center mb-4">
                      <p className={`text-2xl font-bold ${accountData.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(accountData.balance)}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {accountData.transactions} transactions
                      </p>
                    </div>

                    <div className="border-t pt-3">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Monthly Income:</span>
                        <span className="font-medium text-green-600">
                          {formatCurrency(accountData.monthlyIncome)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Monthly Expense:</span>
                        <span className="font-medium text-red-600">
                          {formatCurrency(accountData.monthlyExpense)}
                        </span>
                      </div>
                      <div className="flex justify-between font-semibold mt-2">
                        <span>Net Flow:</span>
                        <span className={accountData.monthlyIncome - accountData.monthlyExpense >= 0 ? 'text-green-600' : 'text-red-600'}>
                          {formatCurrency(accountData.monthlyIncome - accountData.monthlyExpense)}
                        </span>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-4"
                      onClick={() => window.location.href = '/transactions?account=' + account}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      View Transactions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Bank Account</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="name">Account Name</Label>
              <Input
                id="name"
                placeholder="e.g., HDFC Savings, SBI Current"
                value={newBankAccount}
                onChange={(e) => setNewBankAccount(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddAccount}>
              Add Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {/* Transfer Dialog */}
      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Transfer Funds</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="transferSource">Source Account</Label>
              <Select value={transferSource} onValueChange={setTransferSource}>
                <SelectTrigger>
                  <SelectValue placeholder="Select source account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((account) => (
                    <SelectItem key={account} value={account}>{account}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferDestination">Destination Account</Label>
              <Select value={transferDestination} onValueChange={setTransferDestination}>
                <SelectTrigger>
                  <SelectValue placeholder="Select destination account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.filter(account => account !== transferSource).map((account) => (
                    <SelectItem key={account} value={account}>{account}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transferAmount">Amount</Label>
              <Input
                id="transferAmount"
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsTransferDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleTransfer}>
              Transfer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}