
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useFinanceStore } from "@/lib/transactionStore";
import { formatCurrency } from "@/lib/formatters";
import { Scale } from "lucide-react";

export default function Reconciliations() {
  const { bankAccounts, creditCards, transactions } = useFinanceStore();
  const [actualBalances, setActualBalances] = useState<Record<string, string>>({});

  // Calculate current balance for each account
  const calculateBalance = (account: string) => {
    return transactions
      .filter(t => t.account === account)
      .reduce((sum, t) => {
        if (t.type === "income" || t.type === "payment") return sum + t.amount;
        if (t.type === "expense" || t.type === "transfer") return sum - t.amount;
        return sum;
      }, 0);
  };

  // Calculate difference
  const getDifference = (account: string, currentBalance: number) => {
    const actualBalance = parseFloat(actualBalances[account] || "0");
    return !isNaN(actualBalance) ? actualBalance - currentBalance : 0;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Scale className="h-6 w-6" /> Reconciliations
        </h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Bank Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 font-medium text-sm text-gray-500 mb-2">
            <div>Current Balance</div>
            <div>Actual Balance</div>
            <div>Difference</div>
          </div>
          {bankAccounts.map(account => {
            const currentBalance = calculateBalance(account);
            const difference = getDifference(account, currentBalance);
            return (
              <div key={account} className="grid grid-cols-3 gap-4 py-2 border-t">
                <div className="flex items-center">
                  <span className="font-medium">{account}</span>
                  <span className="ml-2">{formatCurrency(currentBalance)}</span>
                </div>
                <div>
                  <Input
                    type="number"
                    value={actualBalances[account] || ""}
                    onChange={(e) => setActualBalances(prev => ({
                      ...prev,
                      [account]: e.target.value
                    }))}
                    placeholder="Enter actual balance"
                  />
                </div>
                <div className={`font-medium ${difference > 0 ? 'text-green-600' : difference < 0 ? 'text-red-600' : ''}`}>
                  {formatCurrency(difference)}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Credit Cards</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 font-medium text-sm text-gray-500 mb-2">
            <div>Current Balance</div>
            <div>Actual Balance</div>
            <div>Difference</div>
          </div>
          {creditCards.map(card => {
            const currentBalance = calculateBalance(card.name);
            const difference = getDifference(card.name, currentBalance);
            return (
              <div key={card.name} className="grid grid-cols-3 gap-4 py-2 border-t">
                <div className="flex items-center">
                  <span className="font-medium">{card.name}</span>
                  <span className="ml-2">{formatCurrency(currentBalance)}</span>
                </div>
                <div>
                  <Input
                    type="number"
                    value={actualBalances[card.name] || ""}
                    onChange={(e) => setActualBalances(prev => ({
                      ...prev,
                      [card.name]: e.target.value
                    }))}
                    placeholder="Enter actual balance"
                  />
                </div>
                <div className={`font-medium ${difference > 0 ? 'text-green-600' : difference < 0 ? 'text-red-600' : ''}`}>
                  {formatCurrency(difference)}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
