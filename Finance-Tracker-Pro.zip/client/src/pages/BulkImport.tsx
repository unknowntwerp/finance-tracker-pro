import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FileDown, FileUp, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import BulkImportForm from "@/components/BulkImportForm";
import ImportModal from "@/components/ImportModal";
import { generateExcelTemplate } from "@/lib/excelUtils";

export default function BulkImport() {
  const { toast } = useToast();
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDownloadTemplate = async () => {
    try {
      await generateExcelTemplate();
      toast({
        title: "Template Downloaded",
        description: "Excel template has been downloaded with data validations.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "There was an error downloading the template. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFileSelected = (file: File | null) => {
    setSelectedFile(file);
  };
  
  const handleImportClick = () => {
    if (selectedFile) {
      setIsImportModalOpen(true);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/">
          <Button variant="outline" size="sm" className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Bulk Transaction Import</h1>
      </div>

      <Card className="mb-8">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <FileDown className="h-5 w-5 text-primary" /> Step 1: Download Template
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 mb-4">
            Download our Excel template with data validation. Fill it with your transaction data.
          </p>
          <Button 
            variant="default" 
            className="flex items-center gap-2"
            onClick={handleDownloadTemplate}
          >
            <FileDown className="h-4 w-4" /> Download Excel Template
          </Button>
          <p className="text-xs text-gray-500 mt-2">
            Template includes data validation for Type, Account, and Category fields
          </p>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <FileUp className="h-5 w-5 text-primary" /> Step 2: Upload Filled Template
          </CardTitle>
        </CardHeader>
        <CardContent>
          <BulkImportForm onFileSelected={handleFileSelected} />
          
          <div className="mt-4">
            <Button 
              variant="default" 
              className="flex items-center gap-2"
              disabled={!selectedFile}
              onClick={handleImportClick}
            >
              <FileUp className="h-4 w-4" /> Import Transactions
            </Button>
          </div>
        </CardContent>
      </Card>

      <ImportModal 
        isOpen={isImportModalOpen} 
        onClose={() => setIsImportModalOpen(false)} 
        file={selectedFile}
      />
    </div>
  );
}
