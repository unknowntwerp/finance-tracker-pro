import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { FileUp, RefreshCw, X, AlertTriangle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { generateExcelTemplate } from "@/lib/excelUtils";
import { useToast } from "@/hooks/use-toast";

interface BulkImportFormProps {
  onFileSelected?: (file: File | null) => void;
}

export default function BulkImportForm({ onFileSelected }: BulkImportFormProps) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Reset error when component mounts or when file changes
  useEffect(() => {
    setError(null);
  }, [file]);

  const validateFile = (selectedFile: File | null): boolean => {
    if (!selectedFile) {
      setError("No file selected");
      return false;
    }

    // Check file extension
    if (!selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls')) {
      setError("File must be an Excel file (.xlsx or .xls)");
      return false;
    }

    // Check file size (max 5MB)
    if (selectedFile.size > 5 * 1024 * 1024) {
      setError("File size exceeds 5MB limit");
      return false;
    }

    setError(null);
    return true;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    
    if (validateFile(selectedFile)) {
      setFile(selectedFile);
      
      if (onFileSelected) {
        onFileSelected(selectedFile);
      }
    } else {
      // Clear the file input so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDropAreaClick = () => {
    fileInputRef.current?.click();
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      
      if (validateFile(droppedFile)) {
        setFile(droppedFile);
        
        if (onFileSelected) {
          onFileSelected(droppedFile);
        }
      }
    }
  };

  const handleRemoveFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    if (onFileSelected) {
      onFileSelected(null);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      setIsDownloading(true);
      await generateExcelTemplate();
      toast({
        title: "Template Downloaded",
        description: "The Excel template has been downloaded successfully.",
        duration: 3000,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Download Failed",
        description: "Failed to download the template. Please try again.",
        duration: 5000,
      });
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="flex-1 md:flex-none">
      <input 
        type="file" 
        ref={fileInputRef}
        id="importFile" 
        accept=".xlsx,.xls" 
        className="hidden"
        onChange={handleFileChange}
      />
      
      <div className="flex flex-col md:flex-row gap-2">
        {file ? (
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="text-green-600 border-green-500 hover:bg-green-50"
              onClick={() => onFileSelected && onFileSelected(file)}
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              {file.name.length > 15 ? `${file.name.slice(0, 15)}...` : file.name}
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-9 w-9 rounded-full text-gray-500"
              onClick={handleRemoveFile}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Button 
            variant="default" 
            className="flex items-center gap-2"
            onClick={handleDropAreaClick}
          >
            <FileUp className="h-4 w-4" /> Import
          </Button>
        )}
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleDownloadTemplate}
          disabled={isDownloading}
        >
          {isDownloading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Downloading...
            </>
          ) : (
            "Get Template"
          )}
        </Button>
      </div>
      
      {error && (
        <Alert variant="destructive" className="mt-2 py-2">
          <AlertTriangle className="h-4 w-4 mr-2" />
          <AlertDescription className="text-xs">{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}
