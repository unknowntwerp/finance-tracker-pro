import { useState, useEffect } from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { parseExcelFile } from "@/lib/excelUtils";
import { useFinanceStore, ImportTransaction } from "@/lib/transactionStore";

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: File | null;
}

interface ImportSummary {
  totalRows: number;
  successRows: number;
  errorRows: number;
  errors: string[];
}

export default function ImportModal({ isOpen, onClose, file }: ImportModalProps) {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("Preparing to import...");
  const [importSummary, setImportSummary] = useState<ImportSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<ImportTransaction[]>([]);
  const { toast } = useToast();
  const addTransactions = useFinanceStore(state => state.addTransactions);

  useEffect(() => {
    let isMounted = true;
    
    if (isOpen && file) {
      // Reset state for new import
      setProgress(0);
      setStatus("Preparing to import...");
      setImportSummary(null);
      setError(null);
      
      // Start actual import process instead of simulation
      processImport();
    }
    
    async function processImport() {
      try {
        if (!file) return;
        
        // Reading file
        setStatus("Reading file...");
        setProgress(20);
        
        // Validating data
        setStatus("Validating data...");
        setProgress(40);
        
        try {
          // Attempt to parse the Excel file
          const parsedTransactions = await parseExcelFile(file);
          
          // If we get here, validation passed
          setStatus("Importing transactions...");
          setProgress(70);
          
          // Store the transactions to use later
          setTransactions(parsedTransactions);
          
          // Wait a moment to show progress
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          if (isMounted) {
            setProgress(100);
            setStatus("Import complete!");
            
            // Set import summary
            setImportSummary({
              totalRows: parsedTransactions.length,
              successRows: parsedTransactions.length,
              errorRows: 0,
              errors: []
            });
          }
        } catch (err) {
          if (isMounted) {
            setProgress(100);
            setStatus("Import failed");
            
            // Handle validation errors from the Excel parser
            const errorMsg = err instanceof Error ? err.message : String(err);
            
            // If it's a validation error list, parse it into an array
            if (errorMsg.startsWith("Validation errors in the Excel file:")) {
              const errorLines = errorMsg.split("\n").slice(1); // Skip the first line which is just the header
              
              setImportSummary({
                totalRows: errorLines.length + 1, // Add 1 to account for at least one successful row
                successRows: 0,
                errorRows: errorLines.length,
                errors: errorLines
              });
            } else {
              // Generic error
              setError(errorMsg);
            }
          }
        }
      } catch (err) {
        if (isMounted) {
          setProgress(100);
          setStatus("Import failed");
          setError(err instanceof Error ? err.message : String(err));
        }
      }
    }
    
    return () => {
      isMounted = false;
    };
  }, [isOpen, file]);

  const handleComplete = () => {
    if (importSummary && importSummary.successRows > 0 && transactions.length > 0) {
      // Save transactions to the store
      addTransactions(transactions);
      
      toast({
        title: "Import Successful",
        description: `${importSummary.successRows} transactions imported successfully.`,
        variant: "default",
      });
    }
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Import Progress</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <Progress value={progress} className="h-2 mb-2" />
          <p className="text-center text-sm text-gray-500">{status}</p>
          
          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {importSummary && (
            <>
              <div className="mt-4 p-3 bg-gray-100 rounded-md">
                <p className="mb-1 text-sm">
                  <span className="font-medium">Total Rows:</span> {importSummary.totalRows}
                </p>
                <p className="mb-1 text-sm">
                  <span className="font-medium">Successfully Imported:</span> {importSummary.successRows}
                </p>
                <p className="mb-1 text-sm">
                  <span className="font-medium">Errors:</span> {importSummary.errorRows}
                </p>
              </div>
              
              {importSummary.errorRows > 0 && (
                <div className="mt-4 max-h-40 overflow-y-auto">
                  <h4 className="font-medium mb-2 text-destructive text-sm">Error Details:</h4>
                  <ul className="list-disc pl-5 text-sm space-y-1">
                    {importSummary.errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
        
        <DialogFooter className="sm:justify-between">
          <Button variant="outline" onClick={onClose} disabled={progress < 100}>
            Cancel
          </Button>
          {(importSummary || error) && progress === 100 && (
            <Button onClick={handleComplete}>
              {importSummary && importSummary.successRows > 0 ? "Complete Import" : "Close"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
