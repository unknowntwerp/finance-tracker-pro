import { Link, useLocation } from "wouter";
import { 
  FileText, 
  CreditCard, 
  BarChart2, 
  Database, 
  Settings, 
  Building, 
  FileUp, 
  Menu,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const navigation = [
    { name: "Transactions", href: "/", icon: FileText },
    { name: "Credit Cards", href: "/credit-cards", icon: CreditCard },
    { name: "Bank Accounts", href: "/bank-accounts", icon: Building }, 
    { name: "Analytics", href: "/analytics", icon: BarChart2 },
    { name: "Reconciliations", href: "/reconciliations", icon: Settings }, // Added Reconciliations
    { name: "Backup", href: "/backup", icon: Database },
    { name: "Manage Lists", href: "/manage-lists", icon: Settings },
    { name: "Bulk Import", href: "/bulk-import", icon: FileUp }
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile menu button */}
      <button 
        className="md:hidden p-4 fixed top-0 right-0 z-20 text-gray-600"
        onClick={toggleMobileMenu}
      >
        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <div 
        className={cn(
          "bg-white shadow-md w-64 flex-shrink-0 md:flex flex-col",
          isMobileMenuOpen ? "fixed inset-y-0 left-0 z-10 flex" : "hidden"
        )}
      >
        <div className="p-4 flex items-center border-b">
          <h1 className="text-xl font-bold text-primary">Finance Tracker Pro</h1>
        </div>
        <nav className="flex-1 py-4">
          <ul>
            {navigation.map((item) => (
              <li key={item.name}>
                <Link href={item.href}>
                  <div className={cn(
                    "flex items-center px-6 py-3 text-sm font-medium rounded-md hover:bg-gray-100 transition-colors cursor-pointer",
                    location === item.href ? "text-primary bg-gray-100" : "text-gray-700"
                  )}>
                    <item.icon className="mr-3 h-5 w-5" />
                    {item.name}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-6 md:px-6 lg:px-8">
          {children}
        </div>
      </main>
    </div>
  );
}


function ReconciliationsPage() {
  return (
    <div>
      <h1>Reconciliations</h1>
      <table>
        <thead>
          <tr>
            <th>Account</th>
            <th>Current Balance</th>
            <th>Entered Balance</th>
            <th>Difference</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Credit Card 1</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
          <tr>
            <td>Credit Card 2</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
          <tr>
            <td>Bank Account 1</td>
            <td>0</td>
            <td><input type="number" /></td>
            <td>0</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export {ReconciliationsPage};