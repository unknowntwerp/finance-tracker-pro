import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useFinanceStore, Transaction } from "@/lib/transactionStore";
import { Building, AlertCircle, Plus, RefreshCw, ArrowDown, ArrowUp } from "lucide-react";

export default function BankBalances() {
  const { bankAccounts, transactions } = useFinanceStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newBalance, setNewBalance] = useState("");
  const [selectedAccount, setSelectedAccount] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  // Calculate current balance for each bank account
  const bankBalances = useMemo(() => {
    const balances: Record<string, { balance: number; transactions: number }> = {};
    
    // Initialize balances for all bank accounts
    bankAccounts.forEach(account => {
      balances[account] = { balance: 0, transactions: 0 };
    });
    
    // Calculate balances based on transactions
    transactions.forEach(transaction => {
      const { account, type, amount } = transaction;
      
      if (balances[account]) {
        if (type === "income") {
          balances[account].balance += amount;
        } else {
          balances[account].balance -= amount;
        }
        balances[account].transactions += 1;
      }
    });
    
    return balances;
  }, [bankAccounts, transactions]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
    }).format(amount);
  };

  const handleOpenDialog = (account: string) => {
    setSelectedAccount(account);
    setNewBalance("");
    setFormError(null);
    setIsDialogOpen(true);
  };

  const handleUpdateBalance = () => {
    // Validate input
    if (!newBalance.trim()) {
      setFormError("Balance is required");
      return;
    }

    const balanceValue = parseFloat(newBalance);
    if (isNaN(balanceValue)) {
      setFormError("Balance must be a valid number");
      return;
    }

    // In a real implementation, we would update the balance in the database
    // For now, we'll just close the dialog
    setIsDialogOpen(false);
    setFormError(null);
  };

  const getTotalBalance = () => {
    return Object.values(bankBalances).reduce((sum, account) => sum + account.balance, 0);
  };

  const totalBalance = getTotalBalance();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0 flex items-center gap-2">
          <Building className="h-6 w-6" /> Bank Balances
        </h1>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
        </div>
      </div>

      {/* Total Balance Card */}
      <Card className="mb-6">
        <CardContent className="py-6">
          <div className="flex flex-col items-center">
            <h2 className="text-lg font-medium text-gray-500 mb-2">Total Balance</h2>
            <p className={`text-3xl font-bold ${totalBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalBalance)}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Across {bankAccounts.length} bank {bankAccounts.length === 1 ? 'account' : 'accounts'}
            </p>
          </div>
        </CardContent>
      </Card>

      {bankAccounts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <Building className="h-10 w-10 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Bank Accounts Added</h3>
            <p className="text-gray-500 text-center max-w-md mb-6">
              Add bank accounts in the Manage Lists section to track their balances.
            </p>
            <Button variant="outline" className="flex items-center gap-2" asChild>
              <a href="/manage-lists">
                <Plus className="h-4 w-4" /> Add Bank Account
              </a>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bankAccounts.map((account) => {
            const accountData = bankBalances[account] || { balance: 0, transactions: 0 };
            return (
              <Card key={account}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <Building className="h-5 w-5 text-primary" /> 
                    {account}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center">
                    <p className={`text-2xl font-bold ${accountData.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(accountData.balance)}
                    </p>
                    
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                      <span>
                        {accountData.transactions} {accountData.transactions === 1 ? 'transaction' : 'transactions'}
                      </span>
                    </div>
                    
                    <div className="mt-4 grid grid-cols-2 gap-3 w-full">
                      <Button 
                        variant="outline" 
                        className="text-green-600 border-green-500 hover:bg-green-50"
                        onClick={() => handleOpenDialog(account)}
                      >
                        <ArrowUp className="h-4 w-4 mr-1" />
                        Deposit
                      </Button>
                      <Button 
                        variant="outline" 
                        className="text-red-600 border-red-500 hover:bg-red-50"
                        onClick={() => handleOpenDialog(account)}
                      >
                        <ArrowDown className="h-4 w-4 mr-1" />
                        Withdraw
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Bank Balance</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {formError && (
              <div className="bg-red-50 p-3 rounded-md flex items-start gap-2 text-sm text-red-700">
                <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="account">Account</Label>
              <Input id="account" value={selectedAccount} readOnly disabled />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="balance">Amount</Label>
              <Input
                id="balance"
                type="number"
                min="0"
                step="0.01"
                placeholder="Enter amount"
                value={newBalance}
                onChange={(e) => setNewBalance(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateBalance}>
              Update Balance
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}