import { create } from 'zustand';

// Define the transaction interface directly here
export interface Transaction {
  id: string;
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
}

// Define source transaction without ID
export interface ImportTransaction {
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
}

// Credit Card interfaces
export interface CreditCard {
  id: string;
  name: string;
  statementDay: number;
  daysAfter: number;
  creditLimit: number;
  currentStatementDate: string;
  nextStatementDate: string;
  dueDate: string;
  statementBalance: number;
  totalOutstanding: number;
  paymentStatus: "pending" | "paid" | "overdue";
}

// Bank Account and Categories
export type BankAccount = string;
export type CreditAccount = string;
export type ExpenseCategory = string;
export type IncomeCategory = string;

interface FinanceStore {
  // Transactions
  transactions: Transaction[];
  addTransaction: (transaction: ImportTransaction) => void;
  addTransactions: (transactions: ImportTransaction[]) => void;
  removeTransaction: (id: string) => void;
  getTransactions: () => Transaction[];
  
  // Credit Cards
  creditCards: CreditCard[];
  addCreditCard: (card: Omit<CreditCard, "id" | "currentStatementDate" | "nextStatementDate" | "dueDate" | "statementBalance" | "totalOutstanding" | "paymentStatus">) => void;
  updateCreditCard: (id: string, card: Partial<CreditCard>) => void;
  removeCreditCard: (id: string) => void;
  
  // Bank Accounts
  bankAccounts: BankAccount[];
  addBankAccount: (account: BankAccount) => void;
  removeBankAccount: (account: BankAccount) => void;
  
  // Credit Accounts
  creditAccounts: CreditAccount[];
  addCreditAccount: (account: CreditAccount) => void;
  removeCreditAccount: (account: CreditAccount) => void;
  
  // Categories
  expenseCategories: ExpenseCategory[];
  addExpenseCategory: (category: ExpenseCategory) => void;
  removeExpenseCategory: (category: ExpenseCategory) => void;
  
  incomeCategories: IncomeCategory[];
  addIncomeCategory: (category: IncomeCategory) => void;
  removeIncomeCategory: (category: IncomeCategory) => void;
}

// Generate a unique ID
const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};

// Define default data
const DEFAULT_BANK_ACCOUNTS: BankAccount[] = [
  "Fi 6793", "ICICI 4592", "SBI 8645", "JUPTR 9022", "AU 5212", "KOTAK 6845", "HDFC 8492"
];

const DEFAULT_CREDIT_ACCOUNTS: CreditAccount[] = [
  "SCLICK 1131", "LEAGUE 0082", "LEGEND 4126", "EAZYDINER 3523", "HSBC 7947", "EDGE 1613", 
  "FKAXIS 9175", "MYZONE 8008", "KIWI 5784", "AXRWRD 0450", "SCPLAT 3121", "ELITE 6716", 
  "YBRUPY 9818", "IDFC 3400", "NEU 7964", "SWIGGY 5419", "CELESTA 3583", "SUPRCD 1652", 
  "SHOPRITE 3884", "BMSPLAY 8165", "HPCL 2000", "AMZN 4005"
];

const DEFAULT_EXPENSE_CATEGORIES: ExpenseCategory[] = [
  "Food", "Rent", "Shopping", "Transport", "Bills", "Entertainment", "Others"
];

const DEFAULT_INCOME_CATEGORIES: IncomeCategory[] = [
  "Salary", "Bonus", "Interest", "Others"
];

// Helper functions for local storage
const loadFromLocalStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch (error) {
    console.error(`Failed to load ${key} from localStorage:`, error);
    return defaultValue;
  }
};

const saveToLocalStorage = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Failed to save ${key} to localStorage:`, error);
  }
};

// Date utilities
const toISODate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const adjustToLastDay = (year: number, month: number, day: number): number => {
  const testDate = new Date(year, month, day);
  return testDate.getMonth() !== month ? new Date(year, month + 1, 0).getDate() : day;
};

// Calculate statement dates for credit cards
const calculateStatementDates = (statementDay: number) => {
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth();
  
  const adjustedDay = adjustToLastDay(currentYear, currentMonth, statementDay);
  let currentStatementDate = new Date(currentYear, currentMonth, adjustedDay);
  
  if (today < currentStatementDate) {
    currentStatementDate = new Date(currentYear, currentMonth - 1, adjustToLastDay(currentYear, currentMonth - 1, statementDay));
  }
  
  const nextMonth = currentStatementDate.getMonth() + 1;
  const nextYear = currentStatementDate.getFullYear() + (nextMonth === 12 ? 1 : 0);
  const nextAdjustedDay = adjustToLastDay(nextYear, nextMonth % 12, statementDay);
  
  return {
    current: toISODate(currentStatementDate),
    next: toISODate(new Date(nextYear, nextMonth % 12, nextAdjustedDay))
  };
};

export const useFinanceStore = create<FinanceStore>((set, get) => ({
  // Transactions
  transactions: loadFromLocalStorage<Transaction[]>('transactions', []),
  
  addTransaction: (transaction: ImportTransaction) => {
    const storedTransaction: Transaction = {
      ...transaction,
      id: generateId()
    };
    
    set((state: FinanceStore) => {
      const updatedTransactions = [...state.transactions, storedTransaction];
      saveToLocalStorage('transactions', updatedTransactions);
      return { transactions: updatedTransactions };
    });
  },
  
  addTransactions: (transactions: ImportTransaction[]) => {
    const storedTransactions: Transaction[] = transactions.map(transaction => ({
      ...transaction,
      id: generateId()
    }));
    
    set((state: FinanceStore) => {
      const updatedTransactions = [...state.transactions, ...storedTransactions];
      saveToLocalStorage('transactions', updatedTransactions);
      return { transactions: updatedTransactions };
    });
  },
  
  removeTransaction: (id: string) => {
    set((state: FinanceStore) => {
      const updatedTransactions = state.transactions.filter((t: Transaction) => t.id !== id);
      saveToLocalStorage('transactions', updatedTransactions);
      return { transactions: updatedTransactions };
    });
  },
  
  getTransactions: () => {
    return get().transactions;
  },
  
  // Credit Cards
  creditCards: loadFromLocalStorage<CreditCard[]>('creditCards', []),
  
  addCreditCard: (card) => {
    const dates = calculateStatementDates(card.statementDay);
    let dueDate = new Date(dates.current);
    dueDate.setDate(dueDate.getDate() + card.daysAfter);
    
    const newCard: CreditCard = {
      ...card,
      id: generateId(),
      currentStatementDate: dates.current,
      nextStatementDate: dates.next,
      dueDate: toISODate(dueDate),
      statementBalance: 0,
      totalOutstanding: 0,
      paymentStatus: "pending"
    };
    
    set((state: FinanceStore) => {
      const updatedCards = [...state.creditCards, newCard];
      saveToLocalStorage('creditCards', updatedCards);
      return { creditCards: updatedCards };
    });
  },
  
  updateCreditCard: (id, card) => {
    set((state: FinanceStore) => {
      const updatedCards = state.creditCards.map((c) => 
        c.id === id ? { ...c, ...card } : c
      );
      saveToLocalStorage('creditCards', updatedCards);
      return { creditCards: updatedCards };
    });
  },
  
  removeCreditCard: (id) => {
    set((state: FinanceStore) => {
      const updatedCards = state.creditCards.filter((c) => c.id !== id);
      saveToLocalStorage('creditCards', updatedCards);
      return { creditCards: updatedCards };
    });
  },
  
  // Bank Accounts
  bankAccounts: loadFromLocalStorage<BankAccount[]>('bankAccounts', DEFAULT_BANK_ACCOUNTS),
  
  addBankAccount: (account) => {
    set((state: FinanceStore) => {
      if (state.bankAccounts.includes(account)) return state;
      const updatedAccounts = [...state.bankAccounts, account];
      saveToLocalStorage('bankAccounts', updatedAccounts);
      return { bankAccounts: updatedAccounts };
    });
  },
  
  removeBankAccount: (account) => {
    set((state: FinanceStore) => {
      const updatedAccounts = state.bankAccounts.filter((a) => a !== account);
      saveToLocalStorage('bankAccounts', updatedAccounts);
      return { bankAccounts: updatedAccounts };
    });
  },
  
  // Credit Accounts
  creditAccounts: loadFromLocalStorage<CreditAccount[]>('creditAccounts', DEFAULT_CREDIT_ACCOUNTS),
  
  addCreditAccount: (account) => {
    set((state: FinanceStore) => {
      if (state.creditAccounts.includes(account)) return state;
      const updatedAccounts = [...state.creditAccounts, account];
      saveToLocalStorage('creditAccounts', updatedAccounts);
      return { creditAccounts: updatedAccounts };
    });
  },
  
  removeCreditAccount: (account) => {
    set((state: FinanceStore) => {
      const updatedAccounts = state.creditAccounts.filter((a) => a !== account);
      saveToLocalStorage('creditAccounts', updatedAccounts);
      return { creditAccounts: updatedAccounts };
    });
  },
  
  // Expense Categories
  expenseCategories: loadFromLocalStorage<ExpenseCategory[]>('expenseCategories', DEFAULT_EXPENSE_CATEGORIES),
  
  addExpenseCategory: (category) => {
    set((state: FinanceStore) => {
      if (state.expenseCategories.includes(category)) return state;
      const updatedCategories = [...state.expenseCategories, category];
      saveToLocalStorage('expenseCategories', updatedCategories);
      return { expenseCategories: updatedCategories };
    });
  },
  
  removeExpenseCategory: (category) => {
    set((state: FinanceStore) => {
      const updatedCategories = state.expenseCategories.filter((c) => c !== category);
      saveToLocalStorage('expenseCategories', updatedCategories);
      return { expenseCategories: updatedCategories };
    });
  },
  
  // Income Categories
  incomeCategories: loadFromLocalStorage<IncomeCategory[]>('incomeCategories', DEFAULT_INCOME_CATEGORIES),
  
  addIncomeCategory: (category) => {
    set((state: FinanceStore) => {
      if (state.incomeCategories.includes(category)) return state;
      const updatedCategories = [...state.incomeCategories, category];
      saveToLocalStorage('incomeCategories', updatedCategories);
      return { incomeCategories: updatedCategories };
    });
  },
  
  removeIncomeCategory: (category) => {
    set((state: FinanceStore) => {
      const updatedCategories = state.incomeCategories.filter((c) => c !== category);
      saveToLocalStorage('incomeCategories', updatedCategories);
      return { incomeCategories: updatedCategories };
    });
  }
}));

// For backward compatibility - now we keep both store names
export const useTransactionStore = useFinanceStore;