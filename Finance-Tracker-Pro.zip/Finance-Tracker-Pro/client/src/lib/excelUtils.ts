import * as ExcelJS from "exceljs";
import FileSaver from "file-saver";
import { useFinanceStore } from "./transactionStore";

// Function to get bank accounts from our store
const getBankAccounts = (): string[] => {
  return useFinanceStore.getState().bankAccounts;
};

// Function to get credit accounts from our store
const getCreditAccounts = (): string[] => {
  return useFinanceStore.getState().creditAccounts;
};

// Function to get expense categories from our store
const getExpenseCategories = (): string[] => {
  return useFinanceStore.getState().expenseCategories;
};

// Function to get income categories from our store
const getIncomeCategories = (): string[] => {
  return useFinanceStore.getState().incomeCategories;
};

// Transaction types remain constant
const transactionTypes = ["expense", "income", "reimbursement"];

export async function generateExcelTemplate() {
  // Get dynamic data from localStorage
  const bankAccounts = getBankAccounts();
  const creditAccounts = getCreditAccounts();
  const expenseCategories = getExpenseCategories();
  const incomeCategories = getIncomeCategories();
  
  // Combine all accounts and categories
  const allAccounts = [...bankAccounts, ...creditAccounts];
  
  // Create a new workbook
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Finance Tracker Pro";
  workbook.lastModifiedBy = "Finance Tracker Pro";
  workbook.created = new Date();
  workbook.modified = new Date();
  
  // Create a hidden Data Sheet for dropdowns
  const dataSheet = workbook.addWorksheet('Data', { state: 'hidden' });
  
  // Set up columns in data sheet for each dropdown type
  dataSheet.getColumn('A').header = 'Transaction Types';
  dataSheet.getColumn('B').header = 'Accounts';
  dataSheet.getColumn('C').header = 'Expense Categories';
  dataSheet.getColumn('D').header = 'Income Categories';
  
  // Add type options
  transactionTypes.forEach((type, index) => {
    dataSheet.getCell(`A${index + 2}`).value = type;
  });
  
  // Add account options
  allAccounts.forEach((account, index) => {
    dataSheet.getCell(`B${index + 2}`).value = account;
  });
  
  // Add expense category options
  expenseCategories.forEach((category, index) => {
    dataSheet.getCell(`C${index + 2}`).value = category;
  });
  
  // Add income category options
  incomeCategories.forEach((category, index) => {
    dataSheet.getCell(`D${index + 2}`).value = category;
  });
  
  // Create main worksheet
  const worksheet = workbook.addWorksheet("Transaction Import", {
    properties: { tabColor: { argb: "FFC0000" } }
  });
  
  // Add instructions row
  worksheet.mergeCells("A1:F1");
  const instructionCell = worksheet.getCell("A1");
  instructionCell.value = "INSTRUCTIONS: Fill in transaction details below. The template validates your entries. For income transactions, use income categories. For expense transactions, use expense categories.";
  instructionCell.font = { bold: true, color: { argb: "FF0000FF" } };
  instructionCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFEEEEEE" } };
  
  // Add column headers with formatting
  const headers = [
    { header: "Date (DD-MM-YYYY)", key: "date", width: 20 },
    { header: "Type", key: "type", width: 15 },
    { header: "Description", key: "description", width: 30 },
    { header: "Amount (Positive)", key: "amount", width: 15 },
    { header: "Account", key: "account", width: 20 },
    { header: "Category", key: "category", width: 20 }
  ];
  
  worksheet.columns = headers;
  
  // Format headers
  const headerRow = worksheet.getRow(2);
  headerRow.eachCell(cell => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF333333" } };
  });
  
  // Add a hidden helper column for category type
  worksheet.getColumn(7).header = 'Category Type';
  worksheet.getColumn(7).hidden = true;
  
  // Add expense sample row
  const today = new Date();
  const sampleRow = worksheet.addRow({
    date: today,
    type: "expense",
    description: "Grocery shopping",
    amount: 1250,
    account: bankAccounts[0] || "Bank Account",
    category: expenseCategories[0] || "Food",
    'Category Type': 'expense'  // Hidden helper column
  });
  
  // Apply formatting to date cell to ensure it shows as DD-MM-YYYY
  sampleRow.getCell(1).numFmt = 'dd-mm-yyyy';
  
  // Apply number formatting to amount cell
  sampleRow.getCell(4).numFmt = '#,##0.00';
  
  // Add income sample row
  const sampleRow2 = worksheet.addRow({
    date: today,
    type: "income",
    description: "Monthly salary",
    amount: 50000,
    account: bankAccounts[0] || "Bank Account",
    category: incomeCategories[0] || "Salary",
    'Category Type': 'income'  // Hidden helper column
  });
  
  // Apply formatting to date cell to ensure it shows as DD-MM-YYYY
  sampleRow2.getCell(1).numFmt = 'dd-mm-yyyy';
  
  // Apply number formatting to amount cell
  sampleRow2.getCell(4).numFmt = '#,##0.00';
  
  // Define dropdown references
  const typeRef = `Data!$A$2:$A$${transactionTypes.length + 1}`;
  const accountRef = `Data!$B$2:$B$${allAccounts.length + 1}`;
  const expenseCategoryRef = `Data!$C$2:$C$${expenseCategories.length + 1}`;
  const incomeCategoryRef = `Data!$D$2:$D$${incomeCategories.length + 1}`;
  
  // Set validation for 100 rows
  for (let i = 3; i <= 100; i++) {
    // Date column (A)
    const dateCell = worksheet.getCell(`A${i}`);
    
    // Set number format to DD-MM-YYYY
    dateCell.numFmt = 'dd-mm-yyyy';
    
    // Set data validation
    dateCell.dataValidation = {
      type: 'date',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please enter a valid date in DD-MM-YYYY format',
      errorTitle: 'Invalid Date',
      showInputMessage: true,
      promptTitle: 'Date',
      prompt: 'Enter date in DD-MM-YYYY format',
      formulae: [new Date(2000, 0, 1), new Date(2050, 11, 31)] // Acceptable date range
    };
    
    // Type column (B)
    worksheet.getCell(`B${i}`).dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a transaction type from the dropdown list',
      errorTitle: 'Invalid Transaction Type',
      showInputMessage: true,
      promptTitle: 'Transaction Type',
      prompt: 'Select expense, income, or reimbursement',
      formulae: [typeRef]
    };
    
    // Amount column (D)
    const amountCell = worksheet.getCell(`D${i}`);
    
    // Set number format for currency
    amountCell.numFmt = '#,##0.00';
    
    amountCell.dataValidation = {
      type: 'decimal',
      operator: 'greaterThan',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Amount must be a positive number',
      errorTitle: 'Invalid Amount',
      showInputMessage: true,
      promptTitle: 'Amount',
      prompt: 'Enter a positive amount',
      formulae: [0] // Min value (must be greater than 0)
    };
    
    // Account column (E)
    worksheet.getCell(`E${i}`).dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a value from the dropdown list',
      errorTitle: 'Invalid Entry',
      showInputMessage: true,
      promptTitle: 'Account',
      prompt: 'Select an account from the dropdown list',
      formulae: [accountRef]
    };
    
    // For the Category column (F), we'll set up conditional validation based on 
    // the transaction type. This requires Excel formulas.
    const categoryCell = worksheet.getCell(`F${i}`);
    
    // Create direct formula reference for dynamic validation based on the type selected
    const formulaText = `=IF(B${i}="income",${incomeCategoryRef},${expenseCategoryRef})`;
    
    categoryCell.dataValidation = {
      type: 'list',
      allowBlank: false,
      showErrorMessage: true,
      errorStyle: 'stop',
      error: 'Please select a category that matches your transaction type',
      errorTitle: 'Invalid Category',
      showInputMessage: true,
      promptTitle: 'Category',
      prompt: 'For income use income categories, for expenses use expense categories',
      formulae: [formulaText]
    };
    
    // Add cell formula to track transaction type for validation
    worksheet.getCell(`G${i}`).value = { formula: `B${i}` };
  }
  
  // Generate buffer and trigger download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  FileSaver.saveAs(blob, "finance_tracker_import_template.xlsx");
}

export interface Transaction {
  date: string;
  type: string;
  description: string;
  amount: number;
  account: string;
  category: string;
}

export async function parseExcelFile(file: File): Promise<Transaction[]> {
  return new Promise((resolve, reject) => {
    try {
      if (!file) {
        reject(new Error("No file provided"));
        return;
      }

      // Check if the file is an Excel file
      if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        reject(new Error("File must be an Excel file (.xlsx or .xls)"));
        return;
      }

      const reader = new FileReader();
      
      reader.onload = async (e) => {
        try {
          if (!e.target || !e.target.result) {
            reject(new Error("Failed to read file content"));
            return;
          }
          
          const buffer = e.target.result;
          const workbook = new ExcelJS.Workbook();
          
          try {
            await workbook.xlsx.load(buffer as ArrayBuffer);
          } catch (error) {
            console.error("Excel parsing error:", error);
            reject(new Error("Invalid Excel file format"));
            return;
          }
          
          // Get the right worksheet (main data sheet is usually the first one)
          // We call it "Transaction Import" in our template
          let worksheet = workbook.getWorksheet("Transaction Import");
          
          // If not found by name, try to get the first sheet
          if (!worksheet) {
            worksheet = workbook.getWorksheet(1);
          }
          
          if (!worksheet) {
            reject(new Error("Could not find worksheet in the Excel file"));
            return;
          }
          
          const transactions: Transaction[] = [];
          const errors: string[] = [];
          
          // Get income and expense categories for validation
          const incomeCategories = getIncomeCategories();
          const expenseCategories = getExpenseCategories();
          
          // Determine how many rows to skip (our template has 2 header rows)
          let headerRows = 2;
          
          // Check each row for data
          worksheet.eachRow((row, rowNumber) => {
            // Skip header rows
            if (rowNumber <= headerRows) return;
            
            // Skip completely empty rows
            let rowIsEmpty = true;
            for (let i = 1; i <= 6; i++) {
              if (row.getCell(i).value) {
                rowIsEmpty = false;
                break;
              }
            }
            if (rowIsEmpty) return;
            
            try {
              // Get date
              let dateValue = "";
              const dateCell = row.getCell(1);
              
              if (dateCell.value instanceof Date) {
                // If it's a Date object, format it as DD-MM-YYYY for display
                const date = dateCell.value as Date;
                dateValue = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
              } else {
                // Otherwise try to parse the string
                dateValue = dateCell.value?.toString() || "";
                
                // If date is in DD-MM-YYYY format, convert it to YYYY-MM-DD for storage
                if (dateValue && dateValue.includes('-')) {
                  const parts = dateValue.split('-');
                  if (parts.length === 3 && parts[0].length === 2 && parts[1].length === 2 && parts[2].length === 4) {
                    dateValue = `${parts[2]}-${parts[1]}-${parts[0]}`;
                  }
                }
              }
              
              // Get other cell values
              const type = row.getCell(2).value?.toString() || "";
              const description = row.getCell(3).value?.toString() || "";
              const amount = Number(row.getCell(4).value) || 0;
              const account = row.getCell(5).value?.toString() || "";
              const category = row.getCell(6).value?.toString() || "";
              
              // Validate required fields
              if (!dateValue) errors.push(`Row ${rowNumber}: Date is required`);
              if (!type) errors.push(`Row ${rowNumber}: Type is required`);
              if (!account) errors.push(`Row ${rowNumber}: Account is required`);
              if (!category) errors.push(`Row ${rowNumber}: Category is required`);
              
              // Validate amount
              if (amount <= 0) {
                errors.push(`Row ${rowNumber}: Amount must be a positive number`);
              }
              
              // Validate transaction type
              if (type && !transactionTypes.includes(type)) {
                errors.push(`Row ${rowNumber}: Invalid transaction type '${type}'`);
              }
              
              // Validate category is appropriate for transaction type
              if (type === "income" && !incomeCategories.includes(category)) {
                errors.push(`Row ${rowNumber}: Invalid category '${category}' for income transaction`);
              } else if (type === "expense" && !expenseCategories.includes(category)) {
                errors.push(`Row ${rowNumber}: Invalid category '${category}' for expense transaction`);
              }
              
              // Create transaction object
              const transaction: Transaction = {
                date: dateValue,
                type,
                description,
                amount,
                account,
                category
              };
              
              transactions.push(transaction);
            } catch (err) {
              errors.push(`Row ${rowNumber}: Error parsing row - ${err instanceof Error ? err.message : String(err)}`);
            }
          });
          
          // If there are validation errors, reject with the error details
          if (errors.length > 0) {
            reject(new Error("Validation errors in the Excel file:\n" + errors.join("\n")));
            return;
          }
          
          // If no transactions were found
          if (transactions.length === 0) {
            reject(new Error("No valid transactions found in the Excel file"));
            return;
          }
          
          resolve(transactions);
        } catch (error) {
          console.error("Excel parsing error:", error);
          reject(new Error(`Error processing file: ${error instanceof Error ? error.message : String(error)}`));
        }
      };
      
      reader.onerror = (event) => {
        console.error("FileReader error:", event);
        reject(new Error("Error reading file"));
      };
      
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("Overall error in parseExcelFile:", error);
      reject(new Error(`Error handling file: ${error instanceof Error ? error.message : String(error)}`));
    }
  });
}
