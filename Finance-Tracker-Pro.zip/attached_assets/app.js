"use strict";

// Data Initialization
let transactions = JSON.parse(localStorage.getItem('transactions')) || [];
let creditCards = JSON.parse(localStorage.getItem('creditCards')) || [];
let bankAccounts = JSON.parse(localStorage.getItem('bankAccounts')) || ["Fi 6793", "ICICI 4592", "SBI 8645", "JUPTR 9022", "AU 5212", "KOTAK 6845", "HDFC 8492"];
let creditAccounts = JSON.parse(localStorage.getItem('creditAccounts')) || ["SCLICK 1131", "LEAGUE 0082", "LEGEND 4126", "EAZYDINER 3523", "HSBC 7947", "EDGE 1613", "FKAXIS 9175", "MYZONE 8008", "KIWI 5784", "AXRWRD 0450", "SCPLAT 3121", "ELITE 6716", "YBRUPY 9818", "IDFC 3400", "NEU 7964", "SWIGGY 5419", "CELESTA 3583", "SUPRCD 1652", "SHOPRITE 3884", "BMSPLAY 8165", "HPCL 2000", "AMZN 4005"];
let expenseCategories = JSON.parse(localStorage.getItem('expenseCategories')) || ["Food", "Rent", "Shopping", "Transport", "Bills", "Entertainment", "Others"];
let incomeCategories = JSON.parse(localStorage.getItem('incomeCategories')) || ["Salary", "Bonus", "Interest", "Others"];

let editingIndex = -1;
let editingCardIndex = -1;
let myChart = null;
const validPages = ['transactions', 'creditCards', 'analytics', 'backup', 'manageLists', 'bankBalances'];

// Date Utilities
function toISODate(date) {
  return date.toISOString().split('T')[0];
}

function formatStatementDate(isoDate) {
  const date = new Date(isoDate);
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function adjustToLastDay(year, month, day) {
  const testDate = new Date(year, month, day);
  return testDate.getMonth() !== month ? new Date(year, month + 1, 0).getDate() : day;
}

// Page Management
function showPage(pageId) {
  if (!validPages.includes(pageId)) return;
  document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
  document.querySelectorAll('nav a').forEach(link => link.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  const activeNav = document.querySelector(`nav a[data-page="${pageId}"]`);
  if (activeNav) activeNav.classList.add('active');

  if (pageId === 'creditCards') updateCreditCardSelect();
  if (pageId === 'transactions' || pageId === 'analytics') updateDisplay();
  if (pageId === 'manageLists') renderManageLists();
  if (pageId === 'bankBalances') updateBankBalancesDisplay();
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('nav').addEventListener('click', (e) => {
    if (e.target.tagName === 'A') {
      e.preventDefault();
      showPage(e.target.getAttribute('data-page'));
    }
  });
});

// Credit Card Cycle Logic
function calculateStatementDates(statementDay) {
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth();
  
  const adjustedDay = adjustToLastDay(currentYear, currentMonth, statementDay);
  let currentStatementDate = new Date(currentYear, currentMonth, adjustedDay);
  
  if (today < currentStatementDate) {
    currentStatementDate = new Date(currentYear, currentMonth - 1, adjustToLastDay(currentYear, currentMonth - 1, statementDay));
  }
  
  const nextMonth = currentStatementDate.getMonth() + 1;
  const nextYear = currentStatementDate.getFullYear() + (nextMonth === 12 ? 1 : 0);
  const nextAdjustedDay = adjustToLastDay(nextYear, nextMonth % 12, statementDay);
  return {
    current: currentStatementDate.toISOString().split('T')[0],
    next: new Date(nextYear, nextMonth % 12, nextAdjustedDay).toISOString().split('T')[0]
  };
}

function calculatePreviousCycleDates(card) {
  let current = new Date(card.currentStatementDate);
  let prevMonth = current.getMonth() - 1;
  let year = current.getFullYear();
  if (prevMonth < 0) { 
    prevMonth = 11; 
    year--; 
  }
  let prevDay = adjustToLastDay(year, prevMonth, card.statementDay);
  let previousDate = new Date(year, prevMonth, prevDay);
  return {
    previous: previousDate.toISOString().split('T')[0],
    current: card.currentStatementDate
  };
}

function calculateStatementBalance(card, transactions) {
  const today = new Date();
  if (new Date(card.currentStatementDate) > today) return 0;

  const prevCycle = calculatePreviousCycleDates(card);
  let cycleChargeSum = transactions
    .filter(t => t.account === card.name &&
           t.date >= prevCycle.previous &&
           t.date < prevCycle.current &&
           (t.type === 'expense' || t.type === 'reimbursement'))
    .reduce((sum, t) => sum + t.amount, 0);
  let cycleCreditSum = transactions
    .filter(t => t.account === card.name &&
           t.date >= prevCycle.previous &&
           t.date < prevCycle.current &&
           (t.type === 'payment' || t.type === 'income'))
    .reduce((sum, t) => sum + t.amount, 0);
  return cycleChargeSum - cycleCreditSum;
}

function calculatePaymentStatusBalance(card, transactions) {
  const today = new Date();
  if (new Date(card.currentStatementDate) > today) return 0;

  const prevCycle = calculatePreviousCycleDates(card);
  let cycleChargeSum = transactions
    .filter(t => t.account === card.name &&
           t.date >= prevCycle.previous &&
           t.date < prevCycle.current &&
           (t.type === 'expense' || t.type === 'reimbursement'))
    .reduce((sum, t) => sum + t.amount, 0);
  let postCreditSum = transactions
    .filter(t => t.account === card.name &&
           t.date >= card.currentStatementDate &&
           (t.type === 'payment' || t.type === 'income'))
    .reduce((sum, t) => sum + t.amount, 0);
  return cycleChargeSum - postCreditSum;
}

function calculateTotalOutstanding(card, transactions) {
  return transactions
    .filter(t => t.account === card.name)
    .reduce((sum, t) => {
      if (t.type === 'expense' || t.type === 'reimbursement') return sum + t.amount;
      else if (t.type === 'income' || t.type === 'payment') return sum - t.amount;
      else return sum;
    }, 0);
}

function calculateDueDate(card) {
  let dueDate = new Date(card.currentStatementDate);
  dueDate.setDate(dueDate.getDate() + card.daysAfter);
  return dueDate;
}

function advanceCycle(card) {
  card.currentStatementDate = card.nextStatementDate;
  let newCurrent = new Date(card.currentStatementDate);
  let newMonth = newCurrent.getMonth() + 1;
  let newYear = newCurrent.getFullYear() + (newMonth === 12 ? 1 : 0);
  newMonth = newMonth % 12;
  let newAdjustedDay = adjustToLastDay(newYear, newMonth, card.statementDay);
  card.nextStatementDate = new Date(newYear, newMonth, newAdjustedDay).toISOString().split('T')[0];
  
  let dueDate = new Date(card.currentStatementDate);
  dueDate.setDate(dueDate.getDate() + card.daysAfter);
  card.dueDate = toISODate(dueDate);
}

function updatePaymentStatus(card, transactions) {
  card.statementBalance = calculateStatementBalance(card, transactions);
  let paymentStatusBalance = calculatePaymentStatusBalance(card, transactions);
  card.totalOutstanding = calculateTotalOutstanding(card, transactions);
  let dueDate = calculateDueDate(card);
  card.dueDate = toISODate(dueDate);
  
  const today = new Date();
  if (paymentStatusBalance <= 0) {
    card.paymentStatus = "paid";
    if (today >= new Date(card.currentStatementDate)) advanceCycle(card);
  } else {
    card.paymentStatus = today > dueDate ? "overdue" : "pending";
  }
}

// Transaction Functions
function validateTransaction(t) {
  let isValid = true;
  ["transactionDate", "transactionDesc", "transactionAmount", "transactionAccount", "transactionCategory"].forEach(id => {
    document.getElementById(id).classList.remove('invalid');
  });
  if (!t.date) highlightInvalidField('transactionDate');
  if (!t.description) highlightInvalidField('transactionDesc');
  if (isNaN(t.amount) || t.amount <= 0) highlightInvalidField('transactionAmount');
  if (!t.account) highlightInvalidField('transactionAccount');
  if (!t.category) highlightInvalidField('transactionCategory');
  if ([!t.date, !t.description, isNaN(t.amount), !t.account, !t.category].some(v => v)) {
    alert("Please fix highlighted fields!");
    return false;
  }
  return true;
}

function highlightInvalidField(fieldId) {
  const field = document.getElementById(fieldId);
  field.classList.add('invalid');
  setTimeout(() => field.classList.remove('invalid'), 2000);
}

function addTransaction() {
  const transaction = {
    date: document.getElementById('transactionDate').value,
    type: document.getElementById('transactionType').value,
    description: document.getElementById('transactionDesc').value.trim(),
    amount: parseFloat(document.getElementById('transactionAmount').value),
    account: document.getElementById('transactionAccount').value,
    category: document.getElementById('transactionCategory').value
  };
  
  if (!validateTransaction(transaction)) return;
  
  if (editingIndex !== -1) {
    transactions[editingIndex] = transaction;
    editingIndex = -1;
  } else {
    transactions.push(transaction);
  }
  
  updateCreditCardOutstanding();
  updateDisplay();
  saveToLocalStorage();
  clearForm();
}

function deleteTransaction(index) {
  if (confirm("Delete this transaction?")) {
    transactions.splice(index, 1);
    updateCreditCardOutstanding();
    updateDisplay();
    saveToLocalStorage();
  }
}

function startEdit(index) {
  const t = transactions[index];
  document.getElementById('transactionDate').value = t.date;
  document.getElementById('transactionType').value = t.type;
  document.getElementById('transactionDesc').value = t.description;
  document.getElementById('transactionAmount').value = t.amount;
  document.getElementById('transactionAccount').value = t.account;
  document.getElementById('transactionCategory').value = t.category;
  editingIndex = index;
  showPage('transactions');
}

// Chart Functions
function updateChart(categories) {
  const ctx = document.getElementById('spendingChart').getContext('2d');
  if (myChart) myChart.destroy();
  myChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: Object.keys(categories),
      datasets: [{
        data: Object.values(categories),
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#E7E9ED']
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } }
    }
  });
}

// Bank Balance Calculations
function calculateBankBalances() {
  const balances = {};
  bankAccounts.forEach(acc => balances[acc] = 0);
  transactions.forEach(t => {
    if (bankAccounts.includes(t.account)) {
      if (t.type === 'income' || t.type === 'reimbursement') balances[t.account] += t.amount;
      else if (t.type === 'expense' || t.type === 'transfer' || t.type === 'payment') balances[t.account] -= t.amount;
    }
  });
  return balances;
}

function updateBankBalancesDisplay() {
  const balances = calculateBankBalances();
  let html = '';
  bankAccounts.forEach(acc => {
    html += `<tr><td>${acc}</td><td>₹${balances[acc].toLocaleString()}</td></tr>`;
  });
  document.getElementById('bankBalancesList').innerHTML = html;
}

// List Management
function renderManageLists() {
  document.getElementById('bankAccountsList').innerHTML = bankAccounts
    .map((acc, i) => `<li>${acc} <button onclick="deleteBankAccount(${i})">Delete</button></li>`).join('');
  document.getElementById('creditAccountsList').innerHTML = creditAccounts
    .map((acc, i) => `<li>${acc} <button onclick="deleteCreditAccount(${i})">Delete</button></li>`).join('');
  document.getElementById('expenseCategoriesList').innerHTML = expenseCategories
    .map((cat, i) => `<li>${cat} <button onclick="deleteExpenseCategory(${i})">Delete</button></li>`).join('');
  document.getElementById('incomeCategoriesList').innerHTML = incomeCategories
    .map((cat, i) => `<li>${cat} <button onclick="deleteIncomeCategory(${i})">Delete</button></li>`).join('');
}

function deleteBankAccount(index) {
  if (confirm("Delete this bank account?")) {
    bankAccounts.splice(index, 1);
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function deleteCreditAccount(index) {
  if (confirm("Delete this credit account?")) {
    creditAccounts.splice(index, 1);
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function deleteExpenseCategory(index) {
  if (confirm("Delete this expense category?")) {
    expenseCategories.splice(index, 1);
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function deleteIncomeCategory(index) {
  if (confirm("Delete this income category?")) {
    incomeCategories.splice(index, 1);
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function addBankAccount() {
  const value = document.getElementById('newBankAccount').value.trim();
  if (value && !bankAccounts.includes(value)) {
    bankAccounts.push(value);
    document.getElementById('newBankAccount').value = "";
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function addCreditAccount() {
  const value = document.getElementById('newCreditAccount').value.trim();
  if (value && !creditAccounts.includes(value)) {
    creditAccounts.push(value);
    document.getElementById('newCreditAccount').value = "";
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function addExpenseCategory() {
  const value = document.getElementById('newExpenseCategory').value.trim();
  if (value && !expenseCategories.includes(value)) {
    expenseCategories.push(value);
    document.getElementById('newExpenseCategory').value = "";
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function addIncomeCategory() {
  const value = document.getElementById('newIncomeCategory').value.trim();
  if (value && !incomeCategories.includes(value)) {
    incomeCategories.push(value);
    document.getElementById('newIncomeCategory').value = "";
    saveListsToLocalStorage();
    renderManageLists();
    updateAccountAndCategorySelects();
  }
}

function saveListsToLocalStorage() {
  localStorage.setItem('bankAccounts', JSON.stringify(bankAccounts));
  localStorage.setItem('creditAccounts', JSON.stringify(creditAccounts));
  localStorage.setItem('expenseCategories', JSON.stringify(expenseCategories));
  localStorage.setItem('incomeCategories', JSON.stringify(incomeCategories));
}

// Credit Card Management
function addCreditCard() {
  const card = {
    name: document.getElementById('cardName').value,
    statementDay: parseInt(document.getElementById('statementDate').value),
    daysAfter: parseInt(document.getElementById('daysAfter').value),
    creditLimit: parseFloat(document.getElementById('creditLimit').value),
    outstanding: 0,
    currentStatementDate: null,
    nextStatementDate: null,
    dueDate: null,
    paymentStatus: "pending"
  };

  if (!card.name || isNaN(card.statementDay) || isNaN(card.daysAfter) || isNaN(card.creditLimit)) {
    alert("Please fill all fields correctly!");
    return;
  }

  if (creditCards.some((c, i) => c.name === card.name && i !== editingCardIndex)) {
    alert("Card already exists!");
    return;
  }

  const dates = calculateStatementDates(card.statementDay);
  card.currentStatementDate = dates.current;
  card.nextStatementDate = dates.next;
  let dueDate = new Date(card.currentStatementDate);
  dueDate.setDate(dueDate.getDate() + card.daysAfter);
  card.dueDate = toISODate(dueDate);

  if (editingCardIndex >= 0) {
    creditCards[editingCardIndex] = card;
    editingCardIndex = -1;
  } else {
    creditCards.push(card);
  }

  updateDisplay();
  saveToLocalStorage();
  clearCreditCardForm();
}

function deleteCreditCard(index) {
  if (confirm("Delete this credit card?")) {
    creditCards.splice(index, 1);
    updateDisplay();
    saveToLocalStorage();
  }
}

function startEditCard(index) {
  const card = creditCards[index];
  document.getElementById('cardName').value = card.name;
  document.getElementById('statementDate').value = card.statementDay;
  document.getElementById('daysAfter').value = card.daysAfter;
  document.getElementById('creditLimit').value = card.creditLimit;
  editingCardIndex = index;
}

// Record Payment Function
function recordPayment() {
  const cardName = document.getElementById('paymentCard').value;
  const bankAccount = document.getElementById('paymentBankAccount').value;
  const amount = parseFloat(document.getElementById('paymentAmount').value);
  const paymentDate = document.getElementById('paymentDate').value;

  if (!cardName || !bankAccount || isNaN(amount) || !paymentDate) {
    alert("Please fill all payment details!");
    return;
  }

  const cardPaymentTransaction = {
    date: paymentDate,
    type: "payment",
    description: `Payment to ${cardName}`,
    amount: amount,
    account: cardName,
    category: "Payment"
  };

  const bankTransferTransaction = {
    date: paymentDate,
    type: "transfer",
    description: `Payment from ${bankAccount} for ${cardName}`,
    amount: amount,
    account: bankAccount,
    category: "Transfer"
  };

  transactions.push(cardPaymentTransaction);
  transactions.push(bankTransferTransaction);

  updateDisplay();
  saveToLocalStorage();
}

// Backup Functions
function exportData() {
  const data = { transactions, creditCards };
  const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "finance-data.json";
  a.click();
}

function importData(event) {
  const file = event.target.files[0];
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      transactions = data.transactions || [];
      creditCards = data.creditCards || [];
      updateDisplay();
      saveToLocalStorage();
    } catch (error) {
      alert("Invalid backup file!");
    }
  };
  reader.readAsText(file);
}

// Utility Functions
function saveToLocalStorage() {
  localStorage.setItem('transactions', JSON.stringify(transactions));
  localStorage.setItem('creditCards', JSON.stringify(creditCards));
  localStorage.setItem('bankAccounts', JSON.stringify(bankAccounts));
  localStorage.setItem('creditAccounts', JSON.stringify(creditAccounts));
  localStorage.setItem('expenseCategories', JSON.stringify(expenseCategories));
  localStorage.setItem('incomeCategories', JSON.stringify(incomeCategories));
}

function clearForm() {
  document.getElementById('transactionDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('transactionType').selectedIndex = 0;
  document.getElementById('transactionDesc').value = '';
  document.getElementById('transactionAmount').value = '';
  document.getElementById('transactionAccount').selectedIndex = 0;
  document.getElementById('transactionCategory').selectedIndex = 0;
  editingIndex = -1;
}

function clearCreditCardForm() {
  document.getElementById('cardName').value = '';
  document.getElementById('statementDate').value = '';
  document.getElementById('daysAfter').value = '';
  document.getElementById('creditLimit').value = '';
  editingCardIndex = -1;
}

// Display Update
function updateDisplay() {
  updateCreditCardOutstanding();

  const filteredTransactions = getFilteredTransactions()
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  document.getElementById('transactionsList').innerHTML = filteredTransactions
    .map((t, i) => `
      <tr>
        <td>${t.date}</td>
        <td>${t.type}</td>
        <td>${t.category}</td>
        <td>${t.description}</td>
        <td>${t.account}</td>
        <td>₹${t.amount.toLocaleString()}</td>
        <td>
          <div class="action-buttons">
            <button class="icon-btn edit-btn" onclick="startEdit(${transactions.indexOf(t)})">
              <i class="fas fa-pencil-alt"></i>
            </button>
            <button class="icon-btn delete-btn" onclick="deleteTransaction(${transactions.indexOf(t)})">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </td>
      </tr>`)
    .join('');

  creditCards.forEach(card => {
    if (!card.currentStatementDate || !card.nextStatementDate) {
      const dates = calculateStatementDates(card.statementDay);
      card.currentStatementDate = dates.current;
      card.nextStatementDate = dates.next;
      let dueDate = new Date(card.currentStatementDate);
      dueDate.setDate(dueDate.getDate() + card.daysAfter);
      card.dueDate = toISODate(dueDate);
    }
    updatePaymentStatus(card, transactions);
  });

  document.getElementById('creditCardsList').innerHTML = creditCards
    .map((card, i) => `
      <tr>
        <td>${card.name}</td>
        <td>${formatStatementDate(card.currentStatementDate)}</td>
        <td>${formatStatementDate(card.dueDate)}</td>
        <td>₹${card.creditLimit.toLocaleString()}</td>
        <td>₹${card.statementBalance.toLocaleString()}</td>
        <td>₹${card.totalOutstanding.toLocaleString()}</td>
        <td>₹${(card.creditLimit - card.totalOutstanding).toLocaleString()}</td>
        <td>
          <div class="payment-status status-${card.paymentStatus}">
            ${card.paymentStatus.toUpperCase()}
          </div>
        </td>
        <td>
          <div class="action-buttons">
            <button class="icon-btn edit-btn" onclick="startEditCard(${i})">
              <i class="fas fa-pencil-alt"></i>
            </button>
            <button class="icon-btn delete-btn" onclick="deleteCreditCard(${i})">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </td>
      </tr>`)
    .join('');

  if (document.getElementById('analytics').classList.contains('active')) {
    const categories = getCategoryTotals();
    document.getElementById('categorySummary').innerHTML = Object.entries(categories)
      .map(([cat, total]) => `
        <tr>
          <td>${cat}</td>
          <td>₹${total.toLocaleString()}</td>
        </tr>`)
      .join('');
    updateChart(categories);
  }
}

function getFilteredTransactions() {
  const startDate = document.getElementById('filterStartDate').value;
  const endDate = document.getElementById('filterEndDate').value;
  const searchQuery = document.getElementById('searchQuery').value.trim().toLowerCase();
  const account = document.getElementById('filterAccount').value;
  const category = document.getElementById('filterCategory').value;
  const typeFilter = document.getElementById('filterType').value;
  
  return transactions.filter(t => {
    const dateMatch = (!startDate || t.date >= startDate) && (!endDate || t.date <= endDate);
    const searchMatch = !searchQuery || t.description.toLowerCase().includes(searchQuery);
    const accountMatch = !account || t.account === account;
    const categoryMatch = !category || t.category === category;
    const typeMatch = !typeFilter || t.type === typeFilter;
    return dateMatch && searchMatch && accountMatch && categoryMatch && typeMatch;
  });
}

function getCategoryTotals() {
  return getFilteredTransactions()
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});
}

function updateCreditCardSelect() {
  const select = document.getElementById('paymentCard');
  select.innerHTML = '<option value="">Select Card</option>' + 
    creditCards.map(c => `<option>${c.name}</option>`).join('');
}

function updatePaymentBankAccountSelect() {
  const select = document.getElementById('paymentBankAccount');
  if (!select) return;
  select.innerHTML = '<option value="">Select Bank Account</option>' +
    '<optgroup label="Bank Accounts">' +
    bankAccounts.map(acc => `<option>${acc}</option>`).join('') +
    '</optgroup>';
}

function updateCreditAccountDropdown() {
  const select = document.getElementById('cardName');
  select.innerHTML = '<option value="">Select Card</option>' + 
    creditCards.map(card => `<option>${card.name}</option>`).join('');
}

function updateCreditCardOutstanding() {
  creditCards.forEach(card => {
    if (!card.currentStatementDate || !card.nextStatementDate) {
      const dates = calculateStatementDates(card.statementDay);
      card.currentStatementDate = dates.current;
      card.nextStatementDate = dates.next;
      let dueDate = new Date(card.currentStatementDate);
      dueDate.setDate(dueDate.getDate() + card.daysAfter);
      card.dueDate = toISODate(dueDate);
    }
    updatePaymentStatus(card, transactions);
  });
}

function updateAccountAndCategorySelects() {
  const type = document.getElementById('transactionType').value;
  let categories = [];
  
  switch(type) {
    case 'expense':
      categories = expenseCategories;
      break;
    case 'income':
      categories = incomeCategories;
      break;
    case 'reimbursement':
      categories = ['Payment'];
      break;
  }

  const accountSelect = document.getElementById('transactionAccount');
  accountSelect.innerHTML = `
    <option value="">Select Account</option>
    <optgroup label="Bank Accounts">
      ${bankAccounts.map(acc => `<option>${acc}</option>`).join('')}
    </optgroup>
    <optgroup label="Credit Accounts">
      ${creditAccounts.map(acc => `<option>${acc}</option>`).join('')}
    </optgroup>
  `;

  document.getElementById('filterAccount').innerHTML = `
    <option value="">All Accounts</option>
    <optgroup label="Bank Accounts">
      ${bankAccounts.map(acc => `<option>${acc}</option>`).join('')}
    </optgroup>
    <optgroup label="Credit Accounts">
      ${creditAccounts.map(acc => `<option>${acc}</option>`).join('')}
    </optgroup>
  `;

  document.getElementById('filterCategory').innerHTML = `
    <option value="">All Categories</option>
    ${[...expenseCategories, ...incomeCategories].map(cat => `<option>${cat}</option>`).join('')}
  `;

  document.getElementById('transactionCategory').innerHTML = `
    <option value="">Select Category</option>
    ${categories.map(cat => `<option>${cat}</option>`).join('')}
  `;

  updateCreditAccountDropdown();
  updateCreditCardSelect();
  updatePaymentBankAccountSelect();
}

// Initialization
function init() {
  showPage('transactions');
  document.getElementById('transactionDate').value = new Date().toISOString().split('T')[0];
  updateCreditAccountDropdown();
  updateAccountAndCategorySelects();
  updateDisplay();

  // Event Listeners
  document.getElementById('addTransactionBtn').addEventListener('click', addTransaction);
  document.getElementById('applyFilterBtn').addEventListener('click', updateDisplay);
  document.getElementById('saveCreditCardBtn').addEventListener('click', addCreditCard);
  document.getElementById('recordPaymentBtn').addEventListener('click', recordPayment);
  document.getElementById('exportDataBtn').addEventListener('click', exportData);
  document.getElementById('importFile').addEventListener('change', importData);
  
  document.getElementById('addBankAccountBtn').addEventListener('click', addBankAccount);
  document.getElementById('addCreditAccountBtn').addEventListener('click', addCreditAccount);
  document.getElementById('addExpenseCategoryBtn').addEventListener('click', addExpenseCategory);
  document.getElementById('addIncomeCategoryBtn').addEventListener('click', addIncomeCategory);
  
  document.getElementById('transactionType').addEventListener('change', updateAccountAndCategorySelects);
}

document.addEventListener('DOMContentLoaded', init);
